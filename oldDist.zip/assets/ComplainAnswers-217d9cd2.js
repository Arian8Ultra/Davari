import{j as s}from"./index-f84a2a8c.js";const n=()=>s.jsx("div",{children:"ComplainAnswers"});export{n as default};
