import{j as s}from"./index-a472cd62.js";const n=()=>s.jsx("div",{children:"ComplainAnswers"});export{n as default};
