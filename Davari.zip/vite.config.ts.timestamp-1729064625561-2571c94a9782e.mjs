// vite.config.ts
import { defineConfig } from "file:///G:/Projects/Arbitration.FrontEnd/node_modules/vite/dist/node/index.js";
import react from "file:///G:/Projects/Arbitration.FrontEnd/node_modules/@vitejs/plugin-react-swc/index.mjs";
import { env } from "process";
import { fileURLToPath } from "url";
import { VitePWA } from "file:///G:/Projects/Arbitration.FrontEnd/node_modules/vite-plugin-pwa/dist/index.js";
var __vite_injected_original_import_meta_url = "file:///G:/Projects/Arbitration.FrontEnd/vite.config.ts";
var target = env.ASPNETCORE_HTTPS_PORT ? `https://localhost:${env.ASPNETCORE_HTTPS_PORT}` : env.ASPNETCORE_URLS ? env.ASPNETCORE_URLS.split(";")[0] : "https://localhost:7261";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      injectRegister: "auto",
      strategies: "generateSW"
    })
  ],
  envDir: "./env",
  server: {
    proxy: {
      "^/graphql": {
        target,
        secure: false
      }
    },
    port: 5173
  },
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", __vite_injected_original_import_meta_url))
    }
  },
  build: {
    cssMinify: true,
    manifest: true,
    minify: "terser",
    emptyOutDir: true,
    cssCodeSplit: true,
    sourcemap: true,
    chunkSizeWarningLimit: 1e3,
    terserOptions: {
      sourceMap: true,
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ["console.log", "console.info", "console.debug"],
        dead_code: true,
        unused: true,
        loops: true
      }
    }
    // rollupOptions: {
    //   watch: {
    //     include: ['src/**', 'node_modules/**'],
    //     exclude: ['node_modules/**/node_modules/**']
    //   }
    // },
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJHOlxcXFxQcm9qZWN0c1xcXFxBcmJpdHJhdGlvbi5Gcm9udEVuZFwiO2NvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9maWxlbmFtZSA9IFwiRzpcXFxcUHJvamVjdHNcXFxcQXJiaXRyYXRpb24uRnJvbnRFbmRcXFxcdml0ZS5jb25maWcudHNcIjtjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfaW1wb3J0X21ldGFfdXJsID0gXCJmaWxlOi8vL0c6L1Byb2plY3RzL0FyYml0cmF0aW9uLkZyb250RW5kL3ZpdGUuY29uZmlnLnRzXCI7aW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSBcInZpdGVcIjtcclxuaW1wb3J0IHJlYWN0IGZyb20gXCJAdml0ZWpzL3BsdWdpbi1yZWFjdC1zd2NcIjtcclxuaW1wb3J0IHsgZW52IH0gZnJvbSBcInByb2Nlc3NcIjtcclxuaW1wb3J0IHsgZmlsZVVSTFRvUGF0aCB9IGZyb20gXCJ1cmxcIjtcclxuaW1wb3J0IHsgVml0ZVBXQSB9IGZyb20gXCJ2aXRlLXBsdWdpbi1wd2FcIjtcclxuXHJcbmNvbnN0IHRhcmdldCA9IGVudi5BU1BORVRDT1JFX0hUVFBTX1BPUlRcclxuICA/IGBodHRwczovL2xvY2FsaG9zdDoke2Vudi5BU1BORVRDT1JFX0hUVFBTX1BPUlR9YFxyXG4gIDogZW52LkFTUE5FVENPUkVfVVJMU1xyXG4gID8gZW52LkFTUE5FVENPUkVfVVJMUy5zcGxpdChcIjtcIilbMF1cclxuICA6IFwiaHR0cHM6Ly9sb2NhbGhvc3Q6NzI2MVwiO1xyXG5cclxuLy8gaHR0cHM6Ly92aXRlanMuZGV2L2NvbmZpZy9cclxuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29uZmlnKHtcclxuICBwbHVnaW5zOiBbXHJcbiAgICByZWFjdCgpLFxyXG4gICAgVml0ZVBXQSh7IHJlZ2lzdGVyVHlwZTogXCJhdXRvVXBkYXRlXCIsIGluamVjdFJlZ2lzdGVyOiBcImF1dG9cIiAsXHJcbiAgICBzdHJhdGVnaWVzOiAnZ2VuZXJhdGVTVycsXHJcblxyXG4gICAgfSksXHJcbiAgXSxcclxuICBlbnZEaXI6IFwiLi9lbnZcIixcclxuICBzZXJ2ZXI6IHtcclxuICAgIHByb3h5OiB7XHJcbiAgICAgIFwiXi9ncmFwaHFsXCI6IHtcclxuICAgICAgICB0YXJnZXQsXHJcbiAgICAgICAgc2VjdXJlOiBmYWxzZSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBwb3J0OiA1MTczLFxyXG4gIH0sXHJcbiAgcmVzb2x2ZToge1xyXG4gICAgYWxpYXM6IHtcclxuICAgICAgXCJAXCI6IGZpbGVVUkxUb1BhdGgobmV3IFVSTChcIi4vc3JjXCIsIGltcG9ydC5tZXRhLnVybCkpLFxyXG4gICAgfSxcclxuICB9LFxyXG4gIGJ1aWxkOiB7XHJcbiAgICBjc3NNaW5pZnk6IHRydWUsXHJcbiAgICBtYW5pZmVzdDogdHJ1ZSxcclxuICAgIG1pbmlmeTogXCJ0ZXJzZXJcIixcclxuICAgIGVtcHR5T3V0RGlyOiB0cnVlLFxyXG4gICAgY3NzQ29kZVNwbGl0OiB0cnVlLFxyXG4gICAgc291cmNlbWFwOiB0cnVlLFxyXG4gICAgY2h1bmtTaXplV2FybmluZ0xpbWl0OiAxMDAwLFxyXG4gICAgdGVyc2VyT3B0aW9uczoge1xyXG4gICAgICBzb3VyY2VNYXA6IHRydWUsXHJcbiAgICAgIGNvbXByZXNzOiB7XHJcbiAgICAgICAgZHJvcF9jb25zb2xlOiB0cnVlLFxyXG4gICAgICAgIGRyb3BfZGVidWdnZXI6IHRydWUsXHJcbiAgICAgICAgcHVyZV9mdW5jczogW1wiY29uc29sZS5sb2dcIiwgXCJjb25zb2xlLmluZm9cIiwgXCJjb25zb2xlLmRlYnVnXCJdLFxyXG4gICAgICAgIGRlYWRfY29kZTogdHJ1ZSxcclxuICAgICAgICB1bnVzZWQ6IHRydWUsXHJcbiAgICAgICAgbG9vcHM6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHJvbGx1cE9wdGlvbnM6IHtcclxuICAgIC8vICAgd2F0Y2g6IHtcclxuICAgIC8vICAgICBpbmNsdWRlOiBbJ3NyYy8qKicsICdub2RlX21vZHVsZXMvKionXSxcclxuICAgIC8vICAgICBleGNsdWRlOiBbJ25vZGVfbW9kdWxlcy8qKi9ub2RlX21vZHVsZXMvKionXVxyXG4gICAgLy8gICB9XHJcbiAgICAvLyB9LFxyXG4gIH0sXHJcbn0pO1xyXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQXdSLFNBQVMsb0JBQW9CO0FBQ3JULE9BQU8sV0FBVztBQUNsQixTQUFTLFdBQVc7QUFDcEIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxlQUFlO0FBSnFKLElBQU0sMkNBQTJDO0FBTTlOLElBQU0sU0FBUyxJQUFJLHdCQUNmLHFCQUFxQixJQUFJLHFCQUFxQixLQUM5QyxJQUFJLGtCQUNKLElBQUksZ0JBQWdCLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDaEM7QUFHSixJQUFPLHNCQUFRLGFBQWE7QUFBQSxFQUMxQixTQUFTO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsTUFBRSxjQUFjO0FBQUEsTUFBYyxnQkFBZ0I7QUFBQSxNQUN0RCxZQUFZO0FBQUEsSUFFWixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBQ0EsUUFBUTtBQUFBLEVBQ1IsUUFBUTtBQUFBLElBQ04sT0FBTztBQUFBLE1BQ0wsYUFBYTtBQUFBLFFBQ1g7QUFBQSxRQUNBLFFBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUFBLElBQ0EsTUFBTTtBQUFBLEVBQ1I7QUFBQSxFQUNBLFNBQVM7QUFBQSxJQUNQLE9BQU87QUFBQSxNQUNMLEtBQUssY0FBYyxJQUFJLElBQUksU0FBUyx3Q0FBZSxDQUFDO0FBQUEsSUFDdEQ7QUFBQSxFQUNGO0FBQUEsRUFDQSxPQUFPO0FBQUEsSUFDTCxXQUFXO0FBQUEsSUFDWCxVQUFVO0FBQUEsSUFDVixRQUFRO0FBQUEsSUFDUixhQUFhO0FBQUEsSUFDYixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCx1QkFBdUI7QUFBQSxJQUN2QixlQUFlO0FBQUEsTUFDYixXQUFXO0FBQUEsTUFDWCxVQUFVO0FBQUEsUUFDUixjQUFjO0FBQUEsUUFDZCxlQUFlO0FBQUEsUUFDZixZQUFZLENBQUMsZUFBZSxnQkFBZ0IsZUFBZTtBQUFBLFFBQzNELFdBQVc7QUFBQSxRQUNYLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUY7QUFDRixDQUFDOyIsCiAgIm5hbWVzIjogW10KfQo=
