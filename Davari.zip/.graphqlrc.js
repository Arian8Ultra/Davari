// export const schema = 'http://172.17.139.22/graphql/';
export const schema = 'http://172.16.21.147:7030/graphql/';
