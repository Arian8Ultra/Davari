/* eslint-disable @typescript-eslint/ban-types */
declare module "dastine" {
  function e(t: any): any;
  function addDastineEventListener(evt: string, func: Function): void;
  function generateRandomString(): string;
  class Dastine {
    constructor();
  }
}
