/* eslint-disable @typescript-eslint/ban-ts-comment */
import { Box, Button, CssBaseline } from "@mui/material";
import React from "react";
import { Outlet } from "react-router-dom";
import sazmanImage from "../assets/Sazman.jpeg";
import { background } from "../theme/color";
import pboLogo from "../assets/PboLogo.png";
import judge from "../assets/LOGO.png";
import logo from "../assets/DavariLogoBlack.png";

import { FaBalanceScale } from "react-icons/fa";
import { MdOutlineContactSupport } from "react-icons/md";

const LoginLayout = () => {
  return (
    <Box sx={{ display: "flex", position: "relative" }}>
      <CssBaseline />
      <Box
        width={"100%"}
        height={"100dvh"}
        sx={{
          background: `url(${sazmanImage})`,
          boxSizing: "border-box",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          backgroundPositionX: "center",
        }}
      >
        <Box
          width={"100%"}
          height={"100%"}
          sx={{
            backdropFilter: "blur(5px) brightness(0.8)",
          }}
        >
          <img
            src={pboLogo}
            alt="logo"
            style={{
              position: "absolute",
              // top: "50%",
              // left: "65%",
              top: "3%",
              left: "50%",
              // width: "20%",
              width: "15%",
              transform: "translate(-50%, 5%)",
              // transform: "translate(-50%, -50%)",
              filter:
                "drop-shadow(0px 0px 5px rgba(0,0,0,0.1)) contrast(1.5) saturate(0) brightness(0)",
              // filter:
              //   "drop-shadow(0px 0px 5px rgba(0,0,0,0.5)) contrast(1.5) saturate(0) brightness(10)",
            }}
          />
          <Box
            display={"flex"}
            flexDirection={"column"}
            justifyContent={"center"}
            alignItems={"center"}
            sx={{
              backgroundColor: background,
              transform: "translate(50%, -50%)",
              top: "50%",
              right: "50%",
              position: "absolute",
              borderRadius: "15px",
              transition: "all 0.2s ease-in-out",
            }}
            width={{
              xs: "100%",
              sm: "100%",
              md: "50%",
              lg: "40%",
              xl: "30%",
            }}
            height={"max-content"}
            padding={5}
          >
            <Box
              display={"flex"}
              justifyContent={"center"}
              alignItems={"center"}
              flexDirection={"column"}
              padding={1}
              borderRadius={"1rem"}
              marginBottom={"1rem"}
              width={"100%"}
              gap={2}
              sx={{
                fontSize: "1.35rem",
              }}
            >
              <img
                src={logo}
                height={90}
                // smooth the 
                style={{
                  // borderRadius: "50%",
                  // border: "2px solid #353535",
                  userSelect: "none",
                }}
              />
              سامانه هوشمند داوری شورای عالی فنی
            </Box>

            <Outlet />
          </Box>
        </Box>
      </Box>
      <Button
        className="flex absolute bg-primary-500 outline-secondary-500 bottom-5 right-5 p-3 rounded-full gap-4 items-center ring-0 border-none text-secondary-600 hover:w-fit duration-300 ease-in-out cursor-pointer justify-center hover:shadow-2xl z-50 hover:bg-primary-200"
        href="/login/tracking"
        target="_blank"
        rel="noreferrer"
      >
        <MdOutlineContactSupport size={30} />
        <div className="text ">مشاهده وضعیت</div>
      </Button>

      <a
        // @ts-ignore
        referrerpolicy="origin"
        target="_blank"
        href="https://trustseal.enamad.ir/?id=514566&Code=cpV5uuCvq34c5pPdADTItCLtOCgwcJtS"
        className="aspect-square w-16 h-16 absolute left-4 bottom-4"
      >
        <img
          // @ts-ignore
          referrerpolicy="origin"
          src="https://trustseal.enamad.ir/logo.aspx?id=514566&Code=cpV5uuCvq34c5pPdADTItCLtOCgwcJtS"
          alt=""
          className="cursor-pointer"
          code="cpV5uuCvq34c5pPdADTItCLtOCgwcJtS"
        />
      </a>
    </Box>
  );
};

export default LoginLayout;
