export interface DepartmentsHierarchyWithSubdepartmentsRootObject {
  Department_Code: number;
  Department_Name: string;
  Parent_Department_Code: number;
  Parent_Department_Name: string;
  sub_departments?: DepartmentsHierarchyWithSubdepartmentsRootObject[];
}

export interface DepartmentsHierarchyRootObject {
  Department_Code: number;
  Department_Name: string;
  Parent_Department_Code: number;
  Parent_Department_Name: string;
}
