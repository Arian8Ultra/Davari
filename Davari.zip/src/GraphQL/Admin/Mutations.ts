import { gql } from "@apollo/client";

export const UpdateMainSettings = gql`
  mutation UpdateMainSettings($input: MainSettingInput!) {
    mainSetting_updateMainSetting(input: $input) {
      status {
        code
        value
      }
      result {
        firstPaymentPeriod
        article139OfTheConstitutionCanonNum
        article139OfTheConstitutionCanonClause
        article139OfTheConstitutionCanonDate
        newMinistersCouncilMembersCanonNum
        newMinistersCouncilMembersCanonDate
        newMinistersCouncilMembersApprovementCanonDate
        expertAndAmountAssignmentCanonNum
        expertAndAmountAssignmentCanonDate
        firstPaymentPercentage
        moreThanPurchasingPowerIslamicFinancialBondsCanonNum
        secondPaymentPeriod
        paymentOfClaimsApprovedByTheEmployerCanonNum
        paymentOfClaimsForCompletedWorksInExcessOf125PercentOfTheInitialContractAmountCanonNum
        unpredictedDamagesForLatePaymentOfClaimsCanonNum
        uploadDocumentDeadlineDuration
        id
        isDeleted
        councilPaymentPeriod
        correctionRequestPeriod
        disputeResolutionArticleCircularDate
        disputeResolutionArticleCircularNum
        ministersCouncilCanonDate
        ministersCouncilCanonNum
        accuserResponsePeriod
        accusedResponsePeriod
        correctionRequestPeriod
        councilPaymentPeriod
      }
    }
  }
`;
