import { gql } from "@apollo/client";

export const GetMainSetting = gql`
  query GetMainSetting {
    mainSetting_getMainSetting {
      result {
          firstPaymentPeriod
          article139OfTheConstitutionCanonNum
          article139OfTheConstitutionCanonClause
          article139OfTheConstitutionCanonDate
          newMinistersCouncilMembersCanonNum
          newMinistersCouncilMembersCanonDate
          newMinistersCouncilMembersApprovementCanonDate
          expertAndAmountAssignmentCanonNum
          expertAndAmountAssignmentCanonDate
          firstPaymentPercentage
          moreThanPurchasingPowerIslamicFinancialBondsCanonNum
          secondPaymentPeriod
          paymentOfClaimsApprovedByTheEmployerCanonNum
          paymentOfClaimsForCompletedWorksInExcessOf125PercentOfTheInitialContractAmountCanonNum
          unpredictedDamagesForLatePaymentOfClaimsCanonNum
          uploadDocumentDeadlineDuration
          id
          # isDeleted
          expertPeriodToAnswerAccuserAccusedPoints
          expertReportCircularDate
          expertReportCircularNumber
          certificateAccreditationCircularDate
          certificateAccreditationCircularNumber
          nonfeasibleArgumentDecreeDate
          nonfeasibleArgumentCircularDate
          nonfeasibleArgumentCircularNumber
          siteUrl
          councilPaymentPeriod
          correctionRequestPeriod
          disputeResolutionArticleCircularDate
          disputeResolutionArticleCircularNum
          ministersCouncilCanonDate
          ministersCouncilCanonNum
          accuserResponsePeriod
          accusedResponsePeriod
          correctionRequestPeriod
          councilPaymentPeriod
      }
      status{
        code
        value
      }
    }
  }
`;
