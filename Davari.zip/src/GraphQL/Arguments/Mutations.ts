import { gql } from "@apollo/client";

export const AddNonFeasibleArgument = gql`
  mutation AddNonFeasibleArgument(
    $input: ComplaintNonFeasibleArgumentInput!
    $order: Int! = 1
  ) {
    complaintNonFeasibleArgument_addComplaintNonFeasibleArgument(
      order: $order
      input: $input
    ) {
      result {
        userId
        complaintId
        summary
        description
        financialSituation
        id
      }
      status {
        code
        value
      }
    }
  }
`;

export const UpdateNonFeasibleArgument = gql`
  mutation UpdateNonFeasibleArgument(
    $input: ComplaintNonFeasibleArgumentInput!
  ) {
    complaintNonFeasibleArgument_updateComplaintNonFeasibleArgument(
      input: $input
    ) {
      result {
        userId
        complaintId
        summary
        description
        financialSituation
        id
      }
      status {
        code
        value
      }
    }
  }
`;

export const DeleteNonFeasibleArgument = gql`
  mutation DeleteNonFeasibleArgument($input: Int!) {
    complaintNonFeasibleArgument_deleteComplaintNonFeasibleArgument(
      entityId: $input
    ) {
      result {
        userId
        complaintId
        summary
        description
        financialSituation
        id
      }
      status {
        code
        value
      }
    }
  }
`;
