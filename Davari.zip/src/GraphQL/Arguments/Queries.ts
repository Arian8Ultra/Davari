import { gql } from "@apollo/client";

export const GetNonFeasibleArguments = gql`
  query GetNonFeasibleArguments(
    $filer: ComplaintNonFeasibleArgumentFilterInput
    $order: [ComplaintNonFeasibleArgumentSortInput!]
  ) {
    complaintNonFeasibleArgument_getComplaintNonFeasibleArguments {
      result(where: $filer, order: $order) {
        items {
          userId
          complaintId
          summary
          description
          financialSituation
          id
          isDeleted
          createdDate
          userId
          financialStatusFileName
          financialStatus
          argumentCode
        }
        pageInfo {
          hasNextPage
          hasPreviousPage
        }
        totalCount
      }
      status
    }
  }
`;


export const GenerateNonFeasibleArgumentLetter = gql`
mutation GenerateNonFeasibleArgumentLetter ($input:NonFeasibleArgumentLetterDtoInput!){
  test_generateNonFeasibleArgumentLetter(input: $input)
}`