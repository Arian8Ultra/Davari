/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  Dashboard,
  SpaceDashboardOutlined
} from "@mui/icons-material";
import {
  BsGearWideConnected,
  BsPeopleFill,
  BsPersonCircle,
  BsTextRight
} from "react-icons/bs";
import { CgFileDocument, CgNotes } from "react-icons/cg";
import { FaBalanceScale, FaHome, FaSms } from "react-icons/fa";
import { Titles } from "./Titles";

export const SideBarMenu = [
  {
    primary: Titles.home,
    to: "/home",
    icon: <FaHome />,
    hasLink: true,
    hasCollapse: false,
    children: [],
    accessNeeded: ["NORMAL", "SENIOR_USER", "EXPERT", "SUPER_ADMIN"],
    mailRoom: true,
    justMailRoom: false,
  },
  {
    primary: Titles.complaints,
    to: "/complaints",
    icon: <FaBalanceScale />,
    hasLink: true,
    hasCollapse: false,
    children: [],
    accessNeeded: ["SENIOR_USER", "SUPER_ADMIN", "EXPERT"],
    mailRoom: false,
    justMailRoom: false,
  },
  // {
  //   primary: Titles.contracts,
  //   to: "/contracts",
  //   icon: <VscFile />,
  //   hasLink: true,
  //   hasCollapse: false,
  //   children: [],
  // },
  {
    primary: Titles.expertPortal,
    to: "/expertPortal",
    icon: <SpaceDashboardOutlined />,
    hasLink: true,
    hasCollapse: false,
    accessNeeded: ["JURY_EXPERT"],
    mailRoom: false,
    justMailRoom: false,
  },
  {
    primary: Titles.portal,
    to: "/portal",
    icon: <SpaceDashboardOutlined />,
    hasLink: true,
    hasCollapse: false,
    accessNeeded: ["MAIL_ROOM"],
    mailRoom: true,
    justMailRoom: true,
  },
  {
    primary: Titles.dashboard,
    to: "/dashboard",
    icon: <Dashboard />,
    hasLink: true,
    hasCollapse: false,
    mailRoom: true,
    justMailRoom: true,
    accessNeeded: ["MAIL_ROOM"],
  },
  {
    primary: Titles.log,
    to: "/admin/log",
    icon: <CgNotes />,
    hasLink: true,
    hasCollapse: false,
    mailRoom: true,
    justMailRoom: true,
    accessNeeded: ["MAIL_ROOM"],
  },
  {
    primary: Titles.adminPanel,
    to: "",
    icon: <BsPersonCircle />,
    hasLink: false,
    hasCollapse: true,
    accessNeeded: ["SUPER_ADMIN", "SENIOR_USER"],
    mailRoom: true,
    justMailRoom: false,
    children: [
      {
        primary: Titles.userManagement,
        to: "/admin/usermanagement",
        icon: <BsPeopleFill />,
        hasLink: true,
        hasCollapse: false,
        justDastgah: true,
        mailRoom: true,
        justMailRoom: false,
        accessNeeded: ["SUPER_ADMIN", "SENIOR_USER"],
      },
      {
        primary: Titles.dashboard,
        to: "/dashboard",
        icon: <Dashboard />,
        hasLink: true,
        hasCollapse: false,
        mailRoom: true,
        justMailRoom: true,
        accessNeeded: ["SUPER_ADMIN", "MAIL_ROOM"],
      },
      {
        primary: Titles.log,
        to: "/admin/log",
        icon: <CgNotes />,
        hasLink: true,
        hasCollapse: false,
        mailRoom: true,
        justMailRoom: true,
        accessNeeded: ["SUPER_ADMIN","MAIL_ROOM"],
      },
      {
        primary: Titles.letters,
        to: "/admin/letters",
        icon: <CgFileDocument />,
        hasLink: true,
        hasCollapse: false,
        mailRoom: true,
        justMailRoom: true,
        accessNeeded: ["SUPER_ADMIN"],
      },
      {
        primary: Titles.message,
        to: "/admin/messages",
        icon: <FaSms />,
        hasLink: true,
        hasCollapse: false,
        // mailRoom: true,
        // justMailRoom: true,
        accessNeeded: ["SUPER_ADMIN"],
      },
      {
        primary: Titles.generalSettingsManagement,
        to: "/admin/settings",
        icon: <BsGearWideConnected />,
        hasLink: true,
        hasCollapse: false,
        accessNeeded: ["SUPER_ADMIN"],
      },
      {
        primary: Titles.stateManagement,
        to: "/admin/stateManagement",
        icon: <BsTextRight />,
        hasLink: true,
        hasCollapse: false,
        accessNeeded: ["SUPER_ADMIN"],
      },
    ],
  },
];

// Side bar type
export type SideBarLinkType = {
  primary: string;
  to: string;
  icon?: JSX.Element;
  hasLink?: boolean;
  hasCollapse?: boolean;
  children?: SideBarLinkType[];
  justDastgah?: boolean;
  accessNeeded?:
    | [
        "NORMAL",
        "SENIOR_USER",
        "EXPERT",
        "SUPER_ADMIN",
        "MAIL_ROOM",
        "JURY_EXPERT"
      ]
    | string[];
  mailRoom?: boolean;
  justMailRoom?: boolean;
};
