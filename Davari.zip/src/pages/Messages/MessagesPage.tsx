/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import React from "react";
import { useNavigate } from "react-router-dom";
import { useGetSmsBodiesQuery } from "../../../generated-types";
import CTable from "../../components/CustomTable/CTable";

const MessagesPage = () => {
  const [take, setTake] = React.useState(10);
  const [page, setPage] = React.useState(1);
  const { data } = useGetSmsBodiesQuery({
    variables: {
      skip: (page - 1) * take,
      take: take,
    },
  });
  const navigate = useNavigate();
  return (
    <div className="flex flex-col gap-3 w-full p-2">
      <CTable
        page={page}
        setPage={setPage}
        setRecordsPerPage={setTake}
        recordsPerPage={take}
        totalRecords={data?.SMSBody_getSMSBodies?.result?.totalCount}
        tableHeader={
          // <thead>
          <tr>
            <th className="p-4 text-start">شناسه</th>
            <th className="p-4 text-start">عنوان</th>
            <th className="p-4 text-end">تاریخ آخرین تغییرات</th>
          </tr>
          // </thead>
        }
        colNum={3}
      >
        {data?.SMSBody_getSMSBodies?.result?.items?.map((letter) => (
          <tr
            key={letter.id}
            onClick={() => navigate(`${letter.id}`)}
            className="cursor-pointer hover:bg-primary-100 duration-300"
          >
            <td className="p-4 text-start">{letter.id}</td>
            <td className="p-4 text-start">{letter.persianTitle}</td>
            <td className="p-4 text-end">
              {new Date(letter.lastModifiedDate as string || letter?.createdDate as string).toLocaleDateString(
                "fa-IR",
                {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                }
              )}
            </td>
          </tr>
        ))}
      </CTable>
    </div>
  );
};

export default MessagesPage;
