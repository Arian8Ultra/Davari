/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  useGetLetterBodyQuery,
  useGetSmsBodiesQuery,
  useGetSmsBodyQuery,
  useUpdateLetterBodyMutation,
  useUpdateSmsBodyMutation,
} from "../../../generated-types";
import { TextareaAutosize } from "@mui/material";
import { useAlertStore } from "../../Context/AlertStore";

const MessagePage = () => {
  const [letterContent, setLetterContent] = React.useState("");
  const { letterId } = useParams();
  const navigate = useNavigate();
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();
  const { data } = useGetSmsBodyQuery({
    fetchPolicy: "network-only",
    variables: {
      entityId: parseInt(letterId as string),
    },
    onCompleted(data) {
      setLetterContent(
        data.SMSBody_getSMSBody?.result?.content || ""
      );
    },
  });

  const [updateLetterBody] = useUpdateSmsBodyMutation({
    variables: {
      input: {
        id: parseInt(letterId as string),
        content: letterContent,
        sMSType: data?.SMSBody_getSMSBody?.result?.sMSType,
        persianTitle: data?.SMSBody_getSMSBody?.result?.persianTitle,
      },
    },
    onCompleted(data, clientOptions) {
        if(data?.SMSBody_updateSMSBody?.status?.code === 1){
            setAlertType("success");
            setAlertMessage("تغییرات با موفقیت ذخیره شد");
            setAlertOpen(true);
            navigate("/admin/messages");
        }else{
            setAlertType("error");
            setAlertMessage("خطا در ذخیره تغییرات");
            setAlertOpen(true);
        }
    },
  });
  return (
    <div className="flex flex-col gap-2 p-5">
      <h1 className="text-xl font-bold">
        عنوان: {data?.SMSBody_getSMSBody?.result?.persianTitle}
      </h1>
      <div className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold">متن پیام</h2>
        <TextareaAutosize
          className="p-5 bg-white-100 rounded-md text-black-100"
          value={letterContent}
          onChange={(e) => setLetterContent(e.target.value)}
        />
        <p className="text-red-50">
            * از تغییر عبارات داخل آکولادها {`'{  }'`} خودداری کنید. این عبارات برای جایگذاری مقادیر دینامیک در نامه استفاده می‌شوند.
        </p>
        <button
          className="p-3 bg-primary-500 text-secondary-700 font-bold border-none outline-none w-fit place-self-end rounded-full cursor-pointer hover:bg-primary-300"
          onClick={() => void updateLetterBody()}
        >
          ذخیره تغییرات
        </button>
      </div>
    </div>
  );
};

export default MessagePage;
