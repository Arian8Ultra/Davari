/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-misused-promises */
import {
  Box,
  Button,
  LinearProgress,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
import { useState } from "react";
import {
  useGetComplaintsWithFilterQuery,
  useUpdateComplaintFullMutation,
} from "../../../../generated-types";
import { ComplaintState } from "../../../gql/graphql";

declare const DastineConfig: any;
declare const Dastine: any;

const Test = () => {
  const [updateComplaint] = useUpdateComplaintFullMutation();
  const [id, setId] = useState<string>();
  const [stateId, setStateId] = useState<string>();
  const [textInput, setTextInput] = useState<string>("");
  const [issuer, setIssuer] = useState("");
  const [keyUsages, setKeyUsages] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [digest, setDigest] = useState("");

  const SelectCertificate = () => {
    setLoading(true);
    if (Dastine.isInstalled) {
      try {
        Dastine.SelectCertificateFromTokenByUI(issuer, keyUsages, (e: any) => {
          setResult(e.data.Result);
          console.log(e);
          setLoading(false);
        });
      } catch (error) {
        alert(error);
      }
    } else {
      alert(Dastine.errorMessage);
    }
  };

  const GetSelectedCertificate = () => {
    setLoading(true);
    try {
      Dastine.GetSelectedCertificate((e: any) => {
        console.log(e);
        setLoading(false);
        if (e.error) {
          alert(e.error);
        } else {
          setResult(e.data.Result);
        }
      });
    } catch (error) {
      alert(error);
    }
  };

  const SignData = (digest: Base64URLString) => {
    try {
      Dastine.Sign(digest, "SHA256", (e: any) => {
        console.log(e);
        if (e.error) {
          alert(e.error);
        } else {
          setResult(e.data.Result);
        }
      });
    } catch (error) {
      alert(error);
    }
  };

  const complaintStates = JSON.parse(
    localStorage.getItem("complaintStates") || "[]"
  ) as ComplaintState[];
  const { data: complaints } = useGetComplaintsWithFilterQuery({
    variables: {
      take: 1000,
    },
  });
  return (
    <div>
      <Typography variant={"body2"}>Update State</Typography>
      <Box
        display={"flex"}
        // justifyContent={"center"}
        alignItems={"center"}
        my={3}
      >
        <TextField
          label={"Complaint ID"}
          value={id}
          fullWidth
          onChange={(e) => setId(e.target.value)}
          select
        >
          {complaints?.complaint_getComplaints.result?.items?.map(
            (complaint) => (
              <MenuItem key={complaint.id} value={complaint.id}>
                {complaint.contract?.contractSubjectByAccuser}
                {"  "}
                {complaint.id}
              </MenuItem>
            )
          )}
        </TextField>
        <TextField
          label={"Complaint State"}
          value={stateId}
          onChange={(e) => setStateId(e.target.value)}
          select
          fullWidth
        >
          {complaintStates.map((state) => (
            <MenuItem key={state.id} value={state.id}>
              {state.persianName}
            </MenuItem>
          ))}
        </TextField>
        <Button
          onClick={() =>
            updateComplaint({
              variables: {
                input: {
                  id: parseInt(id || "0") || 0,
                  complaintStateId: parseInt(stateId || "0"),
                },
              },
              onCompleted(data, clientOptions) {
                alert("Updated");
              },
            })
          }
        >
          Update
        </Button>
      </Box>

      <div className="flex gap-5 flex-wrap w-[50dvw]">
        {loading && <LinearProgress className="w-10" />}
        <button
          onClick={() => {
            SelectCertificate();
          }}
        >
          SelectCertificateFromTokenByUI
        </button>
        <button
          onClick={() => {
            GetSelectedCertificate();
          }}
        >
          GetSelectedCertificate
        </button>

        <div className="text break-words w-1/2">{result || ""}</div>
      </div>

      <div className="flex my-2 mx-2 p-5">
        <button
          onClick={() => {
            SignData(digest);
          }}
        >
          Sign
        </button>

        <TextField
          onChange={(e) => {
            setDigest(e.target.value);
          }}
          value={digest}
          label="digest"
        />
      </div>
    </div>
  );
};

export default Test;
