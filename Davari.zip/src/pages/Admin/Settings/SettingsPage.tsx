/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unused-vars */
import React from "react";
import { useForm, Resolver, SubmitHandler } from "react-hook-form";
import { MainSetting } from "../../../gql/graphql";
import {
  useGetMainSettingQuery,
  useUpdateMainSettingsMutation,
} from "../../../../generated-types";
import FaTextField from "../../../components/FaComponents/FaTextField";
import { set } from "date-fns-jalali";
import { DatePicker } from "@mui/x-date-pickers";
import { Button } from "@mui/material";
import { useAlertStore } from "../../../Context/AlertStore";
import { MainSettings, t } from "../../../functions/Translations";

const SettingsPage = () => {
  const formMethods = useForm<MainSetting>({ defaultValues: {} });
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();

  const {
    handleSubmit,
    formState: { errors },
    getValues,
    watch,
    setValue,
    setError,
    clearErrors,
  } = formMethods;

  const [tempSettings, setTempSettings] = React.useState<MainSetting | object>(
    {}
  );

  const { data } = useGetMainSettingQuery({
    onCompleted(data) {
      setTempSettings(data.mainSetting_getMainSetting.result as MainSetting);
      Object.keys(data.mainSetting_getMainSetting.result as MainSetting).map(
        (key) => {
          setValue(
            key as keyof MainSetting,
            // @ts-ignore
            data.mainSetting_getMainSetting.result[key]
          );
        }
      );
    },
  });

  const [UpdateMainSettings] = useUpdateMainSettingsMutation();

  const handleType = (key: keyof MainSetting) => {
    if (key.includes("Num")) return "number";
    if (key.includes("Duration")) return "number";
    return "text";
  };
  const onSubmit: SubmitHandler<MainSetting> = async (data) => {
    await UpdateMainSettings({
      variables: {
        input: {
          ...data,
        },
      },
      onCompleted(data, clientOptions) {
        setAlertMessage("تنظیمات با موفقیت ذخیره شد");
        setAlertType("success");
        setAlertOpen(true);
      },
      onError(error, clientOptions) {
        setAlertMessage("مشکلی در ذخیره سازی تنظیمات به وجود آمده است");
        setAlertType("error");
        setAlertOpen(true);
      },
    });
  };
  return (
    <form action="" onSubmit={handleSubmit(onSubmit)}>
      <div className="grid grid-cols-2  gap-5 p-5 rounded-2xl bg-white-100">
        {/* create inputs by keys of tempSettings */}
        {Object.keys(tempSettings)
          .filter((a) => a != "id" && a!="__typename")
          .map((key) =>
            key.includes("Date") ? (
              <DatePicker
                key={key}
                label={t(key  as MainSettings)}
                name={key}
                value={new Date(getValues(key as keyof MainSetting) as string) || undefined}
                onChange={(e) => {
                  setValue(key as keyof MainSetting, e);
                }}
              />
            ) : (
              <FaTextField
                key={key}
                label={t(key as MainSettings)}
                name={t(key  as MainSettings)}
                type={handleType(key as keyof MainSetting)}
                value={getValues(key as keyof MainSetting) as string}
                InputLabelProps={{
                  shrink: watch(key as keyof MainSetting) ? true : false,
                }}
                onChange={(e) => {
                  setValue(key as keyof MainSetting, e.target.value);
                }}
              />
            )
          )}

        <div className="col-span-full grid-cols-2 grid gap-5">
          <div className=""></div>
          <Button
            variant="contained"
            type="submit"
            className="bg-primary-600 text-secondary-600 font-bold text-[16px]"
          >
            ذخیره
          </Button>
        </div>
      </div>
    </form>
  );
};

export default SettingsPage;
