/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { TableRow } from "@mui/material";
import React from "react";
import * as XLSX from "xlsx";
import {
  useGetEventHistoriesLazyQuery,
  useGetEventHistoriesQuery,
} from "../../../../generated-types";
import CTable from "../../../components/CustomTable/CTable";
import { SortEnumType } from "../../../gql/graphql";

const LogPage = () => {
  const [page, setPage] = React.useState(1);
  const [take, setTake] = React.useState(10);
  const [loading, setLoading] = React.useState(false);
  const { data } = useGetEventHistoriesQuery({
    variables: {
      order: [
        {
          createdDate: SortEnumType.Desc,
        },
      ],
      skip: (page - 1) * take,
      take: take,
    },
  });

  const [GetEventHistories] = useGetEventHistoriesLazyQuery({
    variables: {
      order: [
        {
          createdDate: SortEnumType.Desc,
        },
      ],
      skip: 0,
      take: 100000000,
    },
  });

  const exportToExcel = async () => {
    await GetEventHistories({
      onCompleted(data) {
        setLoading(false);
        const ws = XLSX.utils.json_to_sheet(
          data?.eventHistory_getEventHistories?.result?.items || []
        );
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
        XLSX.writeFile(wb, "eventHistory.xlsx");
      },
    });
  };

  return (
    <div className="flex flex-col gap-4 w-full">
      <div className="flex w-full justify-end">
        <button
          className="bg-success100 border-hidden hover:shadow-lg cursor-pointer  text-white-50 px-4 py-2 rounded-md"
          onClick={() => {
            setLoading(true);
            void exportToExcel();
          }}
        >
          {loading ? "در حال دریافت..." : "دریافت اکسل"}
          {/* دانلود اکسل */}
        </button>
      </div>

      <CTable
        page={page}
        setPage={setPage}
        recordsPerPage={take}
        setRecordsPerPage={setTake}
        totalRecords={
          data?.eventHistory_getEventHistories?.result?.totalCount || 0
        }
        tableHeader={
          <TableRow
            sx={{
              th: {
                padding: "10px",
              },
              "& td": {
                padding: "10px",
              },
            }}
          >
            <td>توضیحات</td>
            <td>آی پی</td>
            <td>توسط</td>
            <td>شماره درخواست</td>
            <td>شناسه قرارداد</td>
            <td>تاریخ و ساعت</td>
            {/* <td>کد رهگیری</td> */}
          </TableRow>
        }
      >
        {data?.eventHistory_getEventHistories?.result?.items?.map((item) => (
          <TableRow
            sx={{
              borderRadius: "1rem",
              overflow: "hidden",
              whiteSpace: "nowrap",
              textOverflow: "ellipsis",
              "&:hover": {
                backgroundColor: "rgba(100,150,150,0.4)",
                cursor: "pointer",
              },
              "& td": {
                padding: "10px",
              },
            }}
          >
            <td>{item.event}</td>
            <td>{item.iPAddress}</td>
            <td>{item.user?.fullName}</td>
            <td>{item.complaintId}</td>
            <td>{item.complaint?.contract?.contractNumberByAccuser}</td>
            <td>
              {new Date(item.createdDate).toLocaleDateString("fa-IR", {
                year: "numeric",
                month: "long",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
              })}
            </td>
          </TableRow>
        ))}
      </CTable>
    </div>
  );
};

export default LogPage;
