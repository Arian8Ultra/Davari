/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { ListRounded, PeopleOutline } from "@mui/icons-material";
import { Box, Button, Switch, Tab, Tabs, Tooltip } from "@mui/material";
import { useRef, useState } from "react";
import { BsGrid, BsList } from "react-icons/bs";
import { A11y, Navigation, Pagination, Scrollbar } from "swiper/modules";
import { Swiper, SwiperRef, SwiperSlide } from "swiper/react";
import { useUserStore } from "../../Context/UserStore";
import ComplaintsList from "../../components/Complaints/ComplaintsList";
import NewComplaintList from "../../components/Complaints/NewComplaintList";
import { primary, secondary, secondaryDark } from "../../theme/color";

import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
const Protal = () => {
  const user = useUserStore((state) => state.user);
  const [listView, setListView] = useState<boolean>(false);
  const [tab, setTab] = useState<number>(0);
  const scrollContainer = useRef<SwiperRef>(null);

  return (
    <>
      <Box
        position={"relative"}
        display={"flex"}
        my={2}
        mt={-5}
        sx={{
          justifyContent: "flex-end",
          gap: 2,
          width: "100%",
        }}
      >
        <Tooltip
          title={"نغییر نوع نمایش"}
          // slotProps={{
          //   tooltip:{
          //     sx:{
          //       background:'white',
          //       color:"black",
          //       boxShadow:theme.shadows[1],
          //       padding:2
          //     }
          //   }
          // }}
        >
          <div className="flex gap-2 items-center">
            <BsGrid />
            <Switch
              checked={listView}
              onChange={(e) => {
                setListView(e.target.checked);
              }}
            />
            <BsList />
          </div>
        </Tooltip>
        <Button
          variant="contained"
          color="primary"
          hidden={
            !user?.userRoles?.find((role) => role.roleType === "SENIOR_USER")
          }
          sx={{
            background: primary,
            color: secondaryDark,
            boxShadow: "none",
            "&:hover": {
              background: secondary,
              color: primary,
            },
          }}
          href="/portal/council_List"
        >
          ایجاد لیست دولت
          <ListRounded sx={{ ml: 1 }} />
        </Button>
        <Button
          variant="contained"
          color="primary"
          sx={{
            background: primary,
            color: secondaryDark,
            boxShadow: "none",
            "&:hover": {
              background: secondary,
              color: primary,
            },
          }}
          href="/portal/determining_List"
        >
          تعیین کارشناس پرونده
          <PeopleOutline sx={{ ml: 1 }} />
        </Button>
      </Box>

      {user?.userRoles?.find((role) => role.roleType === "SENIOR_USER") && (
        <div className="flex w-full mx-auto">
          <div className="flex gap-2 p-3 bg-gray-10 w-fit rounded-2xl my-3">
            <Tabs
            variant="scrollable"
            scrollButtons="auto"
              value={tab}
              onChange={(e, v) => {
                setTab(v as number);
                scrollContainer.current?.swiper.slideTo(v as number);
                scrollContainer.current?.swiper.activeIndex;
              }}
            >
              <Tab label="درخواست های نیازمند اقدام" value={0} />
              <Tab label="تاریخچه درخواست ها" value={1} />
            </Tabs>
          </div>
        </div>
      )}

      <Swiper
        slidesPerView={1}
        className="w-max max-w-[80dvw]"
        ref={scrollContainer}
        allowTouchMove={false}
        allowSlideNext={false}
        allowSlidePrev={false}
        modules={[Navigation, Pagination, Scrollbar, A11y]}
      >
        <SwiperSlide className="bg-gray-10 rounded-2xl">
          {user?.userRoles?.find((role) => role.roleType === "SENIOR_USER") &&
            (listView ? (
              <div className="flex w-full gap-3 flex-col rounded-xl p-3">
                <NewComplaintList
                  type="chief"
                  userId={user.id}
                  departmentId={user.parentId}
                  justNeeded
                />
              </div>
            ) : (
              <ComplaintsList
                type="chief"
                userId={user.id}
                departmentId={user.parentId}
                justNeeded
              />
            ))}
          {user?.userRoles?.find((role) => role.roleType === "EXPERT") &&
            (listView ? (
              <div className="flex w-full gap-3 flex-col rounded-xl p-3">
                <NewComplaintList
                  type="mainRoomExpert"
                  userId={user.id}
                  departmentId={user.parentId}
                  justNeeded
                />
              </div>
            ) : (
              <ComplaintsList
                type="mainRoomExpert"
                userId={user.id}
                departmentId={user.parentId}
                justNeeded
              />
            ))}
        </SwiperSlide>
        <SwiperSlide className="bg-gray-10 rounded-2xl">
          {user?.userRoles?.find(
            (role) =>
              role.roleType === "SENIOR_USER" || role.roleType == "SUPER_ADMIN"
          ) && (
            <div className="my-0">
              {listView ? (
                <div className="flex w-full gap-3 flex-col rounded-xl p-3">
                  {/* <h2 className="font-normal">تمامی درخواست ها</h2> */}
                  <NewComplaintList
                    type="chief"
                    userId={user.id}
                    departmentId={user.parentId}
                  />
                </div>
              ) : (
                <ComplaintsList
                  type="chief"
                  userId={user.id}
                  departmentId={user.parentId}
                />
              )}
            </div>
          )}
        </SwiperSlide>
      </Swiper>
      {/* {user?.userRoles?.find((role) => role.roleType === "SENIOR_USER") &&
        (listView ? (
          <NewComplaintList
            type="chief"
            userId={user.id}
            departmentId={user.parentId}
          />
        ) : (
          <ComplaintsList
            type="chief"
            userId={user.id}
            departmentId={user.parentId}
          />
        ))} */}
    </>
  );
};

export default Protal;
