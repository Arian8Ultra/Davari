/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { useMutation } from "@apollo/client";
import {
  Cancel,
  CancelRounded,
  CheckBox,
  CheckBoxRounded,
  CheckRounded,
} from "@mui/icons-material";
import {
  Box,
  Button,
  Checkbox,
  Switch,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ToWords } from "to-words";
import { API_FILE_DOWNLOAD } from "../../../config";
import {
  useGet_Arbitration_Terms_FormQuery,
  useGetAllOganizationUsersQuery,
  useGetContractQuery,
  useGetTestFetchLetterQuery,
  useSendArbitrationApprovedSmsMutation,
  useSendArbitrationRejectionLetterMutation,
  useSendArbitrationRejectionSmsMutation,
  useSmsComplaintCodeMutation,
  useUpdateArbitrationTermsFormMutation,
} from "../../../generated-types";
import { useUserStore } from "../../Context/UserStore";
import { UPDATE_CONTRACT_BY_EXPERT } from "../../GraphQL/Contracts/Mutations";
import BackButton from "../../components/BackButton";
import { getComplaintStateWithEnum } from "../../functions/ComplaintStatesFunc";
import { convertToPersianDigitsWithComma } from "../../functions/Functions";
import {
  ComplaintStateStatus,
  UpdateComplaintFullDocument,
} from "../../gql/graphql";
import {
  Green,
  GreenLight,
  primary,
  Red,
  RedLight,
  secondary,
} from "../../theme/color";

const ContractDetailsPage = () => {
  const { contractId, complaintId } = useParams<{
    contractId: string;
    complaintId: string;
  }>();
  const { user } = useUserStore();
  // const [contract, setContract] = useState<ContractSmall>();
  const [arbitrationTermsFormAccuser, setArbitrationTermsFormAccuser] =
    useState<{
      firstCondition: string;
      firstConditionFileName: string;
      secondCondition: string;
      secondConditionFileName: string;
      thirdCondition: string;
      thirdConditionFileName: string;
      fourthCondition: string;
      fourthConditionFileName: string;
      filledBy: "ACCUSER" | "ACCUSED";
    }>();
  const [arbitrationTermsFormAccused, setArbitrationTermsFormAccused] =
    useState<{
      firstCondition: string;
      firstConditionFileName: string;
      secondCondition: string;
      secondConditionFileName: string;
      thirdCondition: string;
      thirdConditionFileName: string;
      fourthCondition: string;
      fourthConditionFileName: string;
      filledBy: "ACCUSER" | "ACCUSED";
    }>();
  const navigate = useNavigate();
  const [isApproved] = useState<boolean>(false);
  type BaseIndexPeriodType = {
    isQuarter: boolean;
    quarter: string;
    month: string;
    year: string;
  };

  const [SendArbitrationApprovedSMS] = useSendArbitrationApprovedSmsMutation({
    variables: {
      complaintId: parseInt(complaintId || ""),
    },
  });
  const { data } = useGetContractQuery({
    variables: {
      id: contractId ? parseInt(contractId) : 0,
    },
    onCompleted(data) {
      console.log("Contract", data.contract_getContracts.result?.items?.[0]);

      // const contract = data.contract_getContracts.result
      //   ?.items?.[0] as ContractSmall;
      // setContract(contract);
    },
  });

  const [SMSComplaintCode] = useSmsComplaintCodeMutation({
    variables: {
      id: parseInt(complaintId || "") || 0,
    },
  });

  const [accepts, setAccepts] = useState([
    { accept: false, id: 1 },
    { accept: false, id: 2 },
    { accept: false, id: 3 },
    { accept: false, id: 4 },
  ]);

  const [UpdateArbitrationTermsForm] = useUpdateArbitrationTermsFormMutation({
    variables: {
      input: {
        firstConditionAcceptedByExpert: accepts[0].accept,
        secondConditionAcceptedByExpert: accepts[1].accept,
        thirdConditionAcceptedByExpert: accepts[2].accept,
        fourthConditionAcceptedByExpert: accepts[3].accept,
      },
    },
  });

  const contract = useMemo(() => {
    return data?.contract_getContracts.result?.items?.[0];
  }, [data]);

  const { data: arbitrationTermsData } = useGet_Arbitration_Terms_FormQuery({
    variables: {
      id: complaintId ? parseInt(complaintId) : 0,
    },
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });
  //   GET_ARBITRATION_TERMS_FORM_BY_COMPLAINT_ID,
  //   "arbitrationTermsForm_getArbitrationTermsForms",
  //   {
  //     id: complaintId ? parseInt(complaintId) : undefined,
  //   },
  //   {
  //     onCompleted(data) {
  //       console.log("GET_ARBITRATION_TERMS_FORM_BY_COMPLAINT_ID", data);
  //     },
  //   }
  // );

  console.log(
    "GET_ARBITRATION_TERMS_FORM_BY_COMPLAINT_ID",
    arbitrationTermsData
  );

  useEffect(() => {
    setArbitrationTermsFormAccused({
      filledBy: "ACCUSED",
      firstCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.firstCondition || "",
      firstConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.firstConditionFileName || "",
      fourthCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.fourthCondition || "",
      fourthConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.fourthConditionFileName || "",
      secondCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.secondCondition || "",
      secondConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.secondConditionFileName || "",
      thirdCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.thirdCondition || "",
      thirdConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSED"
        )?.thirdConditionFinalBillFileName || "",
    });
    setArbitrationTermsFormAccuser({
      filledBy: "ACCUSER",
      firstCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.firstCondition || "",
      firstConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.firstConditionFileName || "",
      fourthCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.fourthCondition || "",
      fourthConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.fourthConditionFileName || "",
      secondCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.secondCondition || "",
      secondConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.secondConditionFileName || "",
      thirdCondition:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.thirdCondition || "",
      thirdConditionFileName:
        arbitrationTermsData?.arbitrationTermsForm_getArbitrationTermsForms?.result?.items?.find(
          (item) => item.filledBy === "ACCUSER"
        )?.thirdConditionFinalBillFileName || "",
    });
  }, [arbitrationTermsData]);

  const toWords = new ToWords({
    localeCode: "fa-IR",
  });
  const { data: departmentsData } = useGetAllOganizationUsersQuery({
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });

  const firstConditionItems = ["عمرانی (تملک دارایی سرمایه ای)", "غیرعمرانی"];
  const secondConditionItems = [
    "در ماده حل اختلاف قرارداد، داوری شورای عالی فنی درج شده است.",
    "طرفین پس از عقد قرارداد، بر داوری شورا تراضی نموده اند.",
    "فاقد تراضی روی داوری شورا در حین قرارداد یا پس از آن.",
  ];

  const thirdConditionItems = [
    "صورتحساب نهایی توسط پیمانکار امضا نشده است.",
    "صورتحساب نهایی بدون امضای پیمانکار، به پیمانکار ابلاغ شده است؛ اما پیمانکار ظرف مهلت مقرر در قرارداد به آن اعتراض نموده است.",
    "صورتحساب نهایی توسط پیمانکار امضا شده است اما صرفا دعاوی مربوط به آزادسازی ضمانتنامه ها مورد درخواست است.",
    "هیچ یک از موارد فوق.",
  ];

  const fourthConditionItems = [
    "رای قطعی در خصوص دعاوی مورد درخواست توسط مراجع قضایی و شورا صادر نشده است.",
    "رای قطعی در خصوص دعاوی مورد درخواست توسط مراجع قضایی صادر شده است.",
    "رای قطعی در خصوص دعاوی مورد درخواست توسط شورا صادر شده است.",
    "قرار عدم صلاحیت (استماع) توسط مراجع قضایی صادر شده است.",
  ];

  const [updateByExpert] = useMutation(UPDATE_CONTRACT_BY_EXPERT, {
    variables: {
      isExecutive: isApproved,
      id: contractId ? parseInt(contractId) : undefined,
    },
  });

  const [updateCompaint] = useMutation(UpdateComplaintFullDocument, {
    onCompleted(data) {
      console.log(data);
      alert("ثبت شد");
    },
  });

  const [sendSms] = useSmsComplaintCodeMutation({
    variables: {
      id: complaintId ? parseInt(complaintId) : 0,
    },
  });

  const { data: fetchLetter } = useGetTestFetchLetterQuery({
    variables: {
      letterId: "1",
    },
  });

  // const { data: complaintData } = useGetComplaintQuery({
  //   variables: {
  //     id: parseInt(complaintId || ""),
  //   },
  // });

  // const [GenerateProjectNotConstructiveLetter] =
  //   useGenerateProjectNotConstructiveLetterMutation({
  //     variables: {
  //       input: {
  //         complaintId: parseInt(complaintId || ""),
  //         letterDate: new Date().toISOString(),
  //         letterNum: "123123213sadas",
  //         userId: user.id,
  //       },
  //     },
  //   });

  const [SendArbitrationRejectionSMS] = useSendArbitrationRejectionSmsMutation({
    variables: {
      complaintId: parseInt(complaintId || ""),
    },
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });

  const [GenerateArbitrationRejectionLetter] =
    useSendArbitrationRejectionLetterMutation({
      variables: {
        complaintId: parseInt(complaintId || ""),
        clauses: [
          !accepts[0].accept
            ? arbitrationTermsFormAccuser?.firstCondition || ""
            : "",
          !accepts[1].accept
            ? arbitrationTermsFormAccuser?.secondCondition || ""
            : "",
          !accepts[2].accept
            ? arbitrationTermsFormAccuser?.thirdCondition || ""
            : "",
          !accepts[3].accept
            ? arbitrationTermsFormAccuser?.fourthCondition || ""
            : "",
        ],
      },
    });

  return (
    <>
      <BackButton to="/complaints" />
      <Box
        display={"grid"}
        gridTemplateColumns={"repeat(12, 1fr)"}
        alignItems={"center"}
        justifyContent={"center"}
        gap={2}
        width={"66%"}
        marginX={"auto"}
        // padding={"2rem"}
        // paddingTop={"0"}
        border={`2px solid ${secondary}`}
        borderRadius={"0.5rem"}
        position={"relative"}
        marginY={"3rem"}
        padding={"-1px"}
        // paddingX={"25%"}
      >
        <TableContainer
          sx={{
            gridColumn: "1 / span 12",
            m: 0,
            // outline: "2px solid #000",
            // change the table head background color
            borderRadius: "0.5rem",
            // border:'none',
            "& .MuiTableCell-head": {
              backgroundColor: secondary,
              color: primary,
              outline: `1px solid ${primary}`,
            },
            // give each cell border
            "& .MuiTableCell-root": {
              border: `1px solid ${secondary}`,
            },

            // change the color of first column
            "& .MuiTableCell-body:first-child": {
              // backgroundColor: secondary,
              // outline: `1px solid ${primary}`,
              borderRight: `3px solid ${secondary}`,
              // color: primary,
            },
          }}
        >
          <Table>
            <TableHead>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "20%",
                    minHeight: "max-content",
                  }}
                >
                  عنوان
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "40%",
                  }}
                >
                  خواهان
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "40%",
                  }}
                >
                  خوانده
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  عنوان قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractSubjectByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractSubjectByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  شناسه قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractNumberByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractNumberByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  تاریخ انعقاد قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractDateByAccuser
                    ? new Date(
                        contract.contractDateByAccuser
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractDateByAccused
                    ? new Date(
                        contract.contractDateByAccused
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  مبلغ اوليه/ حق‌الزحمه قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {convertToPersianDigitsWithComma(
                    contract?.initialBudgetByAccuser || "-"
                  )}{" "}
                  - {toWords.convert(contract?.initialBudgetByAccuser || 0)}{" "}
                  {contract?.currencyByAccuser}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {convertToPersianDigitsWithComma(
                    contract?.initialBudgetByAccused || "-"
                  )}{" "}
                  - {toWords.convert(contract?.initialBudgetByAccused || 0)}{" "}
                  {contract?.currencyByAccused}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  مدت اوليه قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.initialTimePeriodByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.initialTimePeriodByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  طرفین قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {departmentsData?.user_getUsers?.result?.items?.find(
                    (item) =>
                      contract?.accuserDepartmentUserId &&
                      item.id === contract?.accuserDepartmentUserId
                  )?.fullName || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {departmentsData?.user_getUsers?.result?.items?.find(
                    (item) =>
                      contract?.accusedDepartmentUserId &&
                      item.id === contract?.accusedDepartmentUserId
                  )?.fullName || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل موافقتنامه
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.agreementFileNameByAccuser ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.agreementFileNameByAccuser &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.agreementFileNameByAccuser}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.agreementFileNameByAccused ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.agreementFileNameByAccused &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.agreementFileNameByAccused}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل شرایط عمومی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.generalConditionsFileNameByAccuser ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.generalConditionsFileNameByAccuser &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.generalConditionsFileNameByAccuser}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.generalConditionsFileNameByAccused ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.generalConditionsFileNameByAccused &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.generalConditionsFileNameByAccused}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل شرایط خصوصی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.privateTermsFileNameByAccuser ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.privateTermsFileNameByAccuser &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.privateTermsFileNameByAccuser}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.privateTermsFileNameByAccused ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.privateTermsFileNameByAccused &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.privateTermsFileNameByAccused}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  محل ثبت شرکت
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accuserNationality || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accusedNationality || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نمایندگان(وکلا)( از طرف خواهان)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accuserRelatedPeopleByAccuser &&
                    JSON.parse(contract?.accuserRelatedPeopleByAccuser).map(
                      (
                        item: {
                          name: string;
                          phone: string;
                          position: string;
                          nationalCode: string;
                        },
                        index: React.Key | null | undefined
                      ) => (
                        <div key={index} className="flex flex-col gap-2">
                          <div className="text">
                            نام و نام خانوادگی: {item.name}
                          </div>
                          <div className="text">شماره تماس: {item.phone}</div>
                          <div className="text">
                            کد ملی: {item.nationalCode}
                          </div>
                        </div>
                      )
                    )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accuserRelatedPeopleByAccused &&
                    JSON.parse(contract?.accuserRelatedPeopleByAccused)?.map?.(
                      (
                        item: {
                          name: string;
                          phone: string;
                          position: string;
                          nationalCode: string;
                        },
                        index: React.Key | null | undefined
                      ) => (
                        <div key={index} className="flex flex-col gap-2">
                          <div className="text">
                            نام و نام خانوادگی: {item.name}
                          </div>
                          <div className="text">شماره تماس: {item.phone}</div>
                          <div className="text">
                            کد ملی: {item.nationalCode}
                          </div>
                        </div>
                      )
                    )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نمایندگان(وکلا)( از طرف خوانده)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accusedRelatedPeopleByAccuser
                    ? JSON.parse(
                        contract?.accusedRelatedPeopleByAccuser
                      )?.map?.(
                        (
                          item: {
                            name: string;
                            phone: string;
                          },
                          index: React.Key | null | undefined
                        ) => (
                          <Box key={index} display={"flex"}>
                            {item.name}
                            {item.phone}
                          </Box>
                        )
                      )
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accusedRelatedPeopleByAccused
                    ? JSON.parse(
                        contract?.accusedRelatedPeopleByAccused
                      )?.map?.(
                        (
                          item: {
                            name: string;
                            phone: string;
                          },
                          index: React.Key | null | undefined
                        ) => (
                          <Box key={index} display={"flex"}>
                            {item.name}
                            {item.phone}
                          </Box>
                        )
                      )
                    : "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  ضريب پيشنهادی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.recommendedCoefficientByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.recommendedCoefficientByAccused || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  تعدیل
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.doesContainAdjustmentByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.doesContainAdjustmentByAccused || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نوع دوره شاخص مبنا
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.baseIndexPeriodByAccuser
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccuser
                        ) as BaseIndexPeriodType
                      ).isQuarter
                      ? "سه ماهه"
                      : "ماهانه"
                    : "-"}
                  {contract?.baseIndexPeriodByAccuser
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccuser
                        ) as BaseIndexPeriodType
                      ).month ||
                      (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccuser
                        ) as BaseIndexPeriodType
                      ).quarter
                    : "-"}{" "}
                  {contract?.baseIndexPeriodByAccuser
                    ? JSON.parse(contract?.baseIndexPeriodByAccuser).year
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.baseIndexPeriodByAccused
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccused
                        ) as BaseIndexPeriodType
                      ).isQuarter
                      ? "سه ماهه"
                      : "ماهانه"
                    : "-"}{" "}
                  {" -"}
                  {contract?.baseIndexPeriodByAccused
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccused
                        ) as BaseIndexPeriodType
                      ).month ||
                      (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccused
                        ) as BaseIndexPeriodType
                      ).quarter
                    : "-"}{" "}
                  {contract?.baseIndexPeriodByAccuser
                    ? JSON.parse(contract?.baseIndexPeriodByAccuser).year
                    : "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  تاريخ شروع كار
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.operationStartDateByAccuser
                    ? new Date(
                        contract.operationStartDateByAccuser
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.operationStartDateByAccused
                    ? new Date(
                        contract.operationStartDateByAccused
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل تاريخ شروع كار
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.operationStartDateByAccuserFileName ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.operationStartDateByAccuserFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.operationStartDateByAccuserFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.operationStartDateByAccusedFileName ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.operationStartDateByAccusedFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.operationStartDateByAccusedFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.physicalProgressInArbitrationDateByAccused !=
                      contract?.physicalProgressInArbitrationDateByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  پيشرفت فيزيكي كار در تاريخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.physicalProgressInArbitrationDateByAccused !=
                      contract?.physicalProgressInArbitrationDateByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.physicalProgressInArbitrationDateByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.physicalProgressInArbitrationDateByAccused !=
                      contract?.physicalProgressInArbitrationDateByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.physicalProgressInArbitrationDateByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.financialProgressInArbitrationDateByAccused !=
                      contract?.financialProgressInArbitrationDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  پيشرفت ریالی كار در تاريخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.financialProgressInArbitrationDateByAccused !=
                      contract?.financialProgressInArbitrationDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.financialProgressInArbitrationDateByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.financialProgressInArbitrationDateByAccused !=
                      contract?.financialProgressInArbitrationDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.financialProgressInArbitrationDateByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.contractStatusAndDateInArbitrationByAccuser !=
                      contract?.contractStatusAndDateInArbitrationByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  وضعیت قرارداد در تاریخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccuser?.includes(
                    "ابلاغ خاتمه"
                  )
                    ? "ابلاغ خاتمه"
                    : contract?.contractStatusAndDateInArbitrationByAccuser?.includes(
                        "ابلاغ فسخ"
                      )
                    ? "ابلاغ فسخ"
                    : contract?.contractStatusAndDateInArbitrationByAccuser?.includes(
                        "جاری"
                      )
                    ? "جاری"
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.contractStatusAndDateInArbitrationByAccuser !=
                      contract?.contractStatusAndDateInArbitrationByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccused?.includes(
                    "ابلاغ خاتمه"
                  )
                    ? "ابلاغ خاتمه"
                    : contract?.contractStatusAndDateInArbitrationByAccused?.includes(
                        "ابلاغ فسخ"
                      )
                    ? "ابلاغ فسخ"
                    : contract?.contractStatusAndDateInArbitrationByAccused?.includes(
                        "جاری"
                      )
                    ? "جاری"
                    : "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل وضعیت قرارداد در تاریخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccuserFirstFileName ? (
                    // a button to donwload the file
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.contractStatusAndDateInArbitrationByAccuserFirstFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.contractStatusAndDateInArbitrationByAccuserFirstFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccusedFirstFileName ? (
                    // a button to donwload the file
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.contractStatusAndDateInArbitrationByAccusedFirstFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.contractStatusAndDateInArbitrationByAccusedFirstFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.supervisionDepartmentByAccused !=
                      contract?.supervisionDepartmentByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  دستگاه نظارت (مهندس مشاور)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.supervisionDepartmentByAccused !=
                      contract?.supervisionDepartmentByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.supervisionDepartmentByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.supervisionDepartmentByAccused !=
                      contract?.supervisionDepartmentByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.supervisionDepartmentByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.authorizedDelaysByAccused !=
                      contract?.authorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  تاخیرات مجاز
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.authorizedDelaysByAccused !=
                      contract?.authorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.authorizedDelaysByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.authorizedDelaysByAccused !=
                      contract?.authorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.authorizedDelaysByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.unauthorizedDelaysByAccused !=
                      contract?.unauthorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  تاخیرات غیر مجاز
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.unauthorizedDelaysByAccused !=
                      contract?.unauthorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.unauthorizedDelaysByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.unauthorizedDelaysByAccused !=
                      contract?.unauthorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.unauthorizedDelaysByAccused || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor: secondary,
                    color: primary,
                  }}
                  colSpan={3}
                >
                  سامانه قرارداد ها
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.fourthCondition !=
                      arbitrationTermsFormAccused?.fourthCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  محل تامین اعتبار
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.fourthCondition !=
                      arbitrationTermsFormAccused?.fourthCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.sourceOfFundingTitle}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor: secondary,
                    color: primary,
                  }}
                  colSpan={3}
                >
                  نامه امور
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  شماره پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.letterNum || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فرستنده پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.senderFullName ||
                    "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  ارجحیت نامه{" "}
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.priorityName || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  خلاصه پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.summary || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  توضیحات پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.comment || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  تاریخ تهیه
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.draftDate || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  تاریخ ارسال
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.sendDate || "-"}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>

          <div className="flex h-20 w-full"></div>

          <Table>
            <TableHead className="rounded-t-lg overflow-hidden">
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "20%",
                    minHeight: "max-content",
                  }}
                >
                  تایید/ رد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "20%",
                    minHeight: "max-content",
                  }}
                >
                  عنوان
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "40%",
                  }}
                >
                  خواهان
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "40%",
                  }}
                >
                  خوانده
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor: secondary,
                    color: primary,
                  }}
                  colSpan={4}
                >
                  احراز شرایط داوری
                </TableCell>
              </TableRow>
              <TableRow className="">
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <div className="flex flex-col gap-3 items-center justify-center">
                    <div className="flex gap-3 items-center">
                      <Switch
                        checked={accepts[0].accept}
                        onChange={(e) => {
                          setAccepts((prev) => {
                            return prev.map((item) => {
                              if (item.id === 1) {
                                return {
                                  ...item,
                                  accept: e.target.checked,
                                };
                              }
                              return item;
                            });
                          });
                        }}
                      />
                      {accepts[0].accept ? "تایید" : "رد"}
                    </div>
                    <div className="flex gap-2">
                      {user?.userRoles?.some(
                        (role) => role.roleType === "SENIOR_USER"
                      ) ? (
                        arbitrationTermsData
                          ?.arbitrationTermsForm_getArbitrationTermsForms
                          ?.result?.items?.[0]
                          ?.firstConditionAcceptedByExpert ? (
                          <>
                            <CheckRounded
                              sx={{
                                color: Green,
                              }}
                            />
                            <div className="text">تایید شده توسط کارشناس</div>
                          </>
                        ) : (
                          <>
                            <CancelRounded
                              sx={{
                                color: Red,
                              }}
                            />
                            <div className="text">رد شده توسط کارشناس</div>
                          </>
                        )
                      ) : null}
                    </div>
                  </div>
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  شرط اول (عمرانی بودن محل اعتبار طرح)
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "",
                  }}
                >
                  <Checkbox
                    checked={
                      firstConditionItems[0] ===
                      arbitrationTermsFormAccuser?.firstCondition
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccuser?.firstCondition}
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "",
                  }}
                >
                  <Checkbox
                    checked={
                      firstConditionItems[0] ===
                      arbitrationTermsFormAccused?.firstCondition
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccused?.firstCondition}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <div className="flex flex-col gap-3 items-center justify-center">
                    <div className="flex gap-3 items-center">
                      <Switch
                        checked={accepts[1].accept}
                        onChange={(e) => {
                          setAccepts((prev) => {
                            return prev.map((item) => {
                              if (item.id === 2) {
                                return {
                                  ...item,
                                  accept: e.target.checked,
                                };
                              }
                              return item;
                            });
                          });
                        }}
                      />
                      {accepts[1].accept ? "تایید" : "رد"}
                    </div>
                    <div className="flex gap-2">
                      {user?.userRoles?.some(
                        (role) => role.roleType === "SENIOR_USER"
                      ) ? (
                        arbitrationTermsData
                          ?.arbitrationTermsForm_getArbitrationTermsForms
                          ?.result?.items?.[0]
                          ?.secondConditionAcceptedByExpert ? (
                          <>
                            <CheckRounded
                              sx={{
                                color: Green,
                              }}
                            />
                            <div className="text">تایید شده توسط کارشناس</div>
                          </>
                        ) : (
                          <>
                            <CancelRounded
                              sx={{
                                color: Red,
                              }}
                            />
                            <div className="text">رد شده توسط کارشناس</div>
                          </>
                        )
                      ) : null}
                    </div>
                  </div>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor:
                      arbitrationTermsFormAccuser?.secondCondition !=
                      arbitrationTermsFormAccused?.secondCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  شرط دوم (تراضی بر داوری شورا)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.secondCondition !=
                      arbitrationTermsFormAccused?.secondCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <Checkbox
                    checked={
                      secondConditionItems[0] ===
                        arbitrationTermsFormAccuser?.secondCondition ||
                      secondConditionItems[1] ===
                        arbitrationTermsFormAccuser?.secondCondition ||
                      false
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccuser?.secondCondition}
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor:
                      arbitrationTermsFormAccuser?.secondCondition !=
                      arbitrationTermsFormAccused?.secondCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <Checkbox
                    checked={
                      secondConditionItems[0] ===
                        arbitrationTermsFormAccused?.secondCondition ||
                      secondConditionItems[1] ===
                        arbitrationTermsFormAccused?.secondCondition ||
                      false
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccused?.secondCondition}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <div className="flex flex-col gap-3 items-center justify-center">
                    <div className="flex gap-3 items-center">
                      <Switch
                        checked={accepts[2].accept}
                        onChange={(e) => {
                          setAccepts((prev) => {
                            return prev.map((item) => {
                              if (item.id === 3) {
                                return {
                                  ...item,
                                  accept: e.target.checked,
                                };
                              }
                              return item;
                            });
                          });
                        }}
                      />
                      {accepts[2].accept ? "تایید" : "رد"}
                    </div>
                    <div className="flex gap-2">
                      {user?.userRoles?.some(
                        (role) => role.roleType === "SENIOR_USER"
                      ) ? (
                        arbitrationTermsData
                          ?.arbitrationTermsForm_getArbitrationTermsForms
                          ?.result?.items?.[0]
                          ?.thirdConditionAcceptedByExpert ? (
                          <>
                            <CheckRounded
                              sx={{
                                color: Green,
                              }}
                            />
                            <div className="text">تایید شده توسط کارشناس</div>
                          </>
                        ) : (
                          <>
                            <CancelRounded
                              sx={{
                                color: Red,
                              }}
                            />
                            <div className="text">رد شده توسط کارشناس</div>
                          </>
                        )
                      ) : null}
                    </div>
                  </div>
                </TableCell>
                <TableCell
                  sx={{
                    backgroundColor:
                      arbitrationTermsFormAccuser?.thirdCondition !=
                      arbitrationTermsFormAccused?.thirdCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  شرط سوم (عدم تسویه حساب)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.thirdCondition !=
                      arbitrationTermsFormAccused?.thirdCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <Checkbox
                    checked={
                      thirdConditionItems[0] ===
                        arbitrationTermsFormAccuser?.thirdCondition ||
                      thirdConditionItems[1] ===
                        arbitrationTermsFormAccuser?.thirdCondition ||
                      thirdConditionItems[2] ===
                        arbitrationTermsFormAccuser?.thirdCondition ||
                      false
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccuser?.thirdCondition}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.thirdCondition !=
                      arbitrationTermsFormAccused?.thirdCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <Checkbox
                    checked={
                      thirdConditionItems[0] ===
                        arbitrationTermsFormAccused?.thirdCondition ||
                      thirdConditionItems[1] ===
                        arbitrationTermsFormAccused?.thirdCondition ||
                      thirdConditionItems[2] ===
                        arbitrationTermsFormAccused?.thirdCondition ||
                      false
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccused?.thirdCondition}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.firstCondition !=
                      arbitrationTermsFormAccused?.firstCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <div className="flex flex-col gap-3 items-center justify-center">
                    <div className="flex gap-3 items-center">
                      <Switch
                        checked={accepts[3].accept}
                        onChange={(e) => {
                          setAccepts((prev) => {
                            return prev.map((item) => {
                              if (item.id === 4) {
                                return {
                                  ...item,
                                  accept: e.target.checked,
                                };
                              }
                              return item;
                            });
                          });
                        }}
                      />
                      {accepts[3].accept ? "تایید" : "رد"}
                    </div>
                    <div className="flex gap-2">
                      {user?.userRoles?.some(
                        (role) => role.roleType === "SENIOR_USER"
                      ) ? (
                        arbitrationTermsData
                          ?.arbitrationTermsForm_getArbitrationTermsForms
                          ?.result?.items?.[0]
                          ?.fourthConditionAcceptedByExpert ? (
                          <>
                            <CheckRounded
                              sx={{
                                color: Green,
                              }}
                            />
                            <div className="text">تایید شده توسط کارشناس</div>
                          </>
                        ) : (
                          <>
                            <CancelRounded
                              sx={{
                                color: Red,
                              }}
                            />
                            <div className="text">رد شده توسط کارشناس</div>
                          </>
                        )
                      ) : null}
                    </div>
                  </div>
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.fourthCondition !=
                      arbitrationTermsFormAccused?.fourthCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  شرط چهارم (عدم طرح در مراجع قضایی یا داوری)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.fourthCondition !=
                      arbitrationTermsFormAccused?.fourthCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <Checkbox
                    checked={
                      fourthConditionItems[0] ===
                        arbitrationTermsFormAccuser?.fourthCondition ||
                      fourthConditionItems[3] ===
                        arbitrationTermsFormAccuser?.fourthCondition ||
                      false
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccuser?.fourthCondition}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      arbitrationTermsFormAccuser?.fourthCondition !=
                      arbitrationTermsFormAccused?.fourthCondition
                        ? RedLight
                        : "transparent",
                  }}
                >
                  <Checkbox
                    checked={
                      fourthConditionItems[0] ===
                        arbitrationTermsFormAccused?.fourthCondition ||
                      fourthConditionItems[3] ===
                        arbitrationTermsFormAccused?.fourthCondition ||
                      false
                    }
                    onChange={(e) => {
                      console.log(e.target.checked);
                    }}
                    disableRipple
                    disableTouchRipple
                    disableFocusRipple
                    icon={
                      <CancelRounded
                        sx={{
                          color: Red,
                        }}
                      />
                    }
                    checkedIcon={
                      <CheckBoxRounded
                        sx={{
                          color: Green,
                        }}
                      />
                    }
                    sx={{
                      cursor: "default",
                    }}
                  />
                  {arbitrationTermsFormAccused?.fourthCondition}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {/* نظر کلی */}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نظر کلی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {/* check four conditions */}
                  {(fourthConditionItems[0] ===
                    arbitrationTermsFormAccuser?.fourthCondition ||
                    fourthConditionItems[3] ===
                      arbitrationTermsFormAccuser?.fourthCondition) &&
                  (thirdConditionItems[0] ===
                    arbitrationTermsFormAccuser?.thirdCondition ||
                    thirdConditionItems[1] ===
                      arbitrationTermsFormAccuser?.thirdCondition ||
                    thirdConditionItems[2] ===
                      arbitrationTermsFormAccuser?.thirdCondition) &&
                  (secondConditionItems[0] ===
                    arbitrationTermsFormAccuser?.secondCondition ||
                    secondConditionItems[1] ===
                      arbitrationTermsFormAccuser?.secondCondition) &&
                  firstConditionItems[0] ===
                    arbitrationTermsFormAccuser?.firstCondition ? (
                    <div className="text">حائز شرایط داوری ✅</div>
                  ) : (
                    <div className="text">حائز شرایط داوری نیست ❌</div>
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {(fourthConditionItems[0] ===
                    arbitrationTermsFormAccused?.fourthCondition ||
                    fourthConditionItems[3] ===
                      arbitrationTermsFormAccused?.fourthCondition) &&
                  (thirdConditionItems[0] ===
                    arbitrationTermsFormAccused?.thirdCondition ||
                    thirdConditionItems[1] ===
                      arbitrationTermsFormAccused?.thirdCondition ||
                    thirdConditionItems[2] ===
                      arbitrationTermsFormAccused?.thirdCondition) &&
                  (secondConditionItems[0] ===
                    arbitrationTermsFormAccused?.secondCondition ||
                    secondConditionItems[1] ===
                      arbitrationTermsFormAccused?.secondCondition) &&
                  firstConditionItems[0] ===
                    arbitrationTermsFormAccused?.firstCondition ? (
                    <div className="text">حائز شرایط داوری ✅</div>
                  ) : (
                    <div className="text">حائز شرایط داوری نیست ❌</div>
                  )}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      {/* {user?.userRoles?.some((role) => role.roleType === "SENIOR_USER") ? (
        <div className="text flex gap-5 mx-auto w-fit">
          <div className="text">
            نظر کارشناس دبیرخانه در مورد احراز شرایط داوری
          </div>
          {!complaintData?.complaint_getComplaint?.result?.complaintState?.persianName.includes(
            "فاقد"
          ) ? (
            <div className="text">حائز شرایط داوری ✅</div>
          ) : (
            <div className="text">حائز شرایط داوری نیست ❌</div>
          )}
        </div>
      ) : (
        ""
      )} */}

      <Box
        gridColumn={"span 12"}
        display={"grid"}
        gridTemplateColumns={"auto auto"}
        justifyContent={"end"}
        alignItems={"center"}
        gap={"2rem"}
        my={"2rem"}
        mx={"auto"}
        width={"66%"}
      >
        {accepts?.some((item) => item.accept === false) && (
          <Button
            variant="outlined"
            color="error"
            sx={{
              color: Red,
              width: "max-content",
              justifySelf: "end",
              "&:hover": {
                backgroundColor: RedLight,
                color: Red,
              },
            }}
            endIcon={<Cancel />}
            onClick={() => {
              const agree = confirm(
                "آیا از عدم احراز شرایط داوری اطمینان دارید؟"
              );
              if (agree)
                if (
                  user.userRoles?.some(
                    (role) => role.roleType === "SENIOR_USER"
                  )
                )
                  void updateCompaint({
                    variables: {
                      input: {
                        id: complaintId ? parseInt(complaintId) : 0,
                        complaintStateId: getComplaintStateWithEnum(
                          ComplaintStateStatus.NotAcceptedForBeingConstructive
                        ).id,
                        isApprovedByChief: false,
                      },
                    },
                    onCompleted() {
                      void UpdateArbitrationTermsForm({
                        variables: {
                          input: {
                            id: arbitrationTermsData
                              ?.arbitrationTermsForm_getArbitrationTermsForms
                              ?.result?.items?.[0].id,
                            firstConditionAcceptedByChief: accepts[0].accept,
                            secondConditionAcceptedByChief: accepts[1].accept,
                            thirdConditionAcceptedByChief: accepts[2].accept,
                            fourthConditionAcceptedByChief: accepts[3].accept,
                          },
                        },
                        onCompleted(data) {
                          void GenerateArbitrationRejectionLetter();
                          void SendArbitrationRejectionSMS();
                          console.log(data);
                          alert("ثبت شد");
                          navigate("/portal");
                        },
                        onError(error) {
                          alert("خطا در ثبت اطلاعات" + String(error.message));
                        },
                      });
                    },
                  });
                else
                  void updateByExpert({
                    variables: {
                      isExecutive: false,
                      id: contractId ? parseInt(contractId) : undefined,
                    },
                    onCompleted() {
                      void UpdateArbitrationTermsForm({
                        variables: {
                          input: {
                            id: arbitrationTermsData
                              ?.arbitrationTermsForm_getArbitrationTermsForms
                              ?.result?.items?.[0].id,
                            firstConditionAcceptedByExpert: accepts[0].accept,
                            secondConditionAcceptedByExpert: accepts[1].accept,
                            thirdConditionAcceptedByExpert: accepts[2].accept,
                            fourthConditionAcceptedByExpert: accepts[3].accept,
                          },
                        },
                        onCompleted() {
                          void updateCompaint({
                            variables: {
                              input: {
                                complaintStateId: getComplaintStateWithEnum(
                                  ComplaintStateStatus.NotAcceptedForBeingConstructiveWaitingForMailroomChiefToConfirm
                                ).id,
                                id: complaintId ? parseInt(complaintId) : 0,
                              },
                            },
                            onCompleted(data) {
                              console.log(data);
                              alert("ثبت شد");
                              navigate("/portal");
                            },
                          });
                        },
                        onError(error) {
                          alert("خطا در ثبت اطلاعات" + String(error.message));
                        },
                      });
                    },
                  });
            }}
          >
            عدم احراز شرایط داوری
          </Button>
        )}

        {!accepts?.some((item) => item.accept === false) && (
          <Button
            variant="outlined"
            color="success"
            hidden={accepts?.some((item) => item.accept === false)}
            sx={{
              color: Green,
              width: "max-content",
              "&:hover": {
                backgroundColor: GreenLight,
                color: Green,
              },
            }}
            endIcon={<CheckBox />}
            onClick={() => {
              const ok = confirm(
                "آیا از تایید احراز شرایط داوری اطمینان دارید؟"
              );
              if (ok)
                if (
                  user.userRoles?.some(
                    (role) => role.roleType === "SENIOR_USER"
                  )
                ) {
                  void updateCompaint({
                    variables: {
                      input: {
                        id: complaintId ? parseInt(complaintId) : 0,
                        complaintStateId: getComplaintStateWithEnum(
                          ComplaintStateStatus.WaitingForComplaintToEnterCouncilList
                        ).id,
                        isApprovedByChief: true,
                      },
                    },
                    onCompleted() {
                      void UpdateArbitrationTermsForm({
                        variables: {
                          input: {
                            id: arbitrationTermsData
                              ?.arbitrationTermsForm_getArbitrationTermsForms
                              ?.result?.items?.[0].id,
                            firstConditionAcceptedByChief: accepts[0].accept,
                            secondConditionAcceptedByChief: accepts[1].accept,
                            thirdConditionAcceptedByChief: accepts[2].accept,
                            fourthConditionAcceptedByChief: accepts[3].accept,
                          },
                        },
                        onCompleted(data) {
                          console.log(data);
                          alert("ثبت شد");
                          navigate("/portal");
                        },
                        onError(error) {
                          alert("خطا در ثبت اطلاعات" + String(error.message));
                        },
                      });
                    },
                  });
                } else
                  void updateByExpert({
                    variables: {
                      isExecutive: true,
                      id: contractId ? parseInt(contractId) : undefined,
                    },
                    onCompleted() {
                      void UpdateArbitrationTermsForm({
                        variables: {
                          input: {
                            id: arbitrationTermsData
                              ?.arbitrationTermsForm_getArbitrationTermsForms
                              ?.result?.items?.[0].id,
                            firstConditionAcceptedByExpert: accepts[0].accept,
                            secondConditionAcceptedByExpert: accepts[1].accept,
                            thirdConditionAcceptedByExpert: accepts[2].accept,
                            fourthConditionAcceptedByExpert: accepts[3].accept,
                          },
                        },
                        onCompleted(data) {
                          console.log(data);
                          void SMSComplaintCode();
                          void updateCompaint({
                            variables: {
                              input: {
                                complaintStateId: getComplaintStateWithEnum(
                                  ComplaintStateStatus.AcceptedForBeingConstructiveWaitingForMailroomChiefToConfirm
                                ).id,
                                id: complaintId ? parseInt(complaintId) : 0,
                                isApprovedByChief: true,
                              },
                            },
                            onCompleted(data) {
                              console.log(data);
                              void sendSms({
                                onCompleted(data) {
                                  console.log(data);
                                  void SendArbitrationApprovedSMS({
                                    onCompleted() {
                                      alert("ثبت شد");
                                      navigate("/portal");
                                    },
                                  });
                                },
                              });
                            },
                          });
                        },
                      });
                    },
                  });
            }}
          >
            احراز شرایط داوری
          </Button>
        )}
      </Box>
    </>
  );
};

export default ContractDetailsPage;
