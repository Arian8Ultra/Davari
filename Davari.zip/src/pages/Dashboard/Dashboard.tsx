/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable prefer-const */
import { BarChart } from "@mui/x-charts/BarChart";
import { LineChart } from "@mui/x-charts/LineChart";
import { useMemo, useState } from "react";
import {
  useGetComplaintsWithFilterQuery,
  useGetVerdictStatisticsQuery,
} from "../../../generated-types";
import { PieChart } from "@mui/x-charts/PieChart";
import { CacheProvider } from "@emotion/react";
import createCache from "@emotion/cache";
import { convertToPersianDigits, getFaMonth } from "../../functions/Functions";
import ApprovedComplaintsChart from "../../components/Dashboard/ApprovedComplaintsChart";
import DeniedComplaintsChart from "../../components/Dashboard/DeniedComplaintsChart";
import StateCountChart from "../../components/Dashboard/StateCountChart";
import ExpertCountChart from "../../components/Dashboard/ExpertCountChart";

const Dashboard = () => {
  const cacheLtr = createCache({
    key: "muiltr",
  });
  const [yAxis, setYAxis] = useState<number[]>([]);
  const [xAxis, setXAxis] = useState<string[]>([]);
  const [yAxisState, setYAxisState] = useState<number[]>([]);
  const [xAxisState, setXAxisState] = useState<string[]>([]);
  const [mode, setMode] = useState<"daily" | "monthly" | "yearly">("daily");
  const today = useMemo(() => new Date(), []);

  const { data } = useGetComplaintsWithFilterQuery({
    variables: {
      take: 1000,
    },
    onCompleted(data) {
      const dates = data?.complaint_getComplaints.result?.items?.map((a) =>
        new Date((a.createdDate as string) || new Date()).toLocaleDateString(
          "fa-IR"
        )
      );
      setXAxis(dates || []);

      let counts = new Array(dates?.length).fill(1);

      dates?.map((d, index) => {
        counts[index] = data?.complaint_getComplaints?.result?.items?.filter(
          (b) =>
            new Date(b.createdDate || new Date()).toLocaleDateString("fa-IR") ==
            d
        ).length;
      });

      setYAxis(counts);

      const states = data.complaint_getComplaints?.result?.items?.map(
        (a) => a.complaintState?.persianName
      );

      setXAxisState((states as string[]) || []);

      let stateCounts = new Array(states?.length).fill(1);

      states?.map((s, index) => {
        // if(s?.includes("در "))
        stateCounts[index] =
          data?.complaint_getComplaints?.result?.items?.filter(
            (b) => b.complaintState?.persianName == s
          ).length;
      });

      setYAxisState(stateCounts);
    },
  });

  const { data: verdictData } = useGetVerdictStatisticsQuery({
    variables: {
      // set end date to now
      endDate: today,
      // set start date to 30 days ago
      startDate: new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000),
    },
    onCompleted(data) {
      console.log(data);
    },
  });

  const seriesY = () => {
    switch (mode) {
      case "daily":
        return verdictData?.dashboard_getDailyVerdictCount?.result?.map(
          (item) => item?.count || 0
        );
      case "monthly":
        return verdictData?.dashboard_getMonthlyVerdictCount?.result?.map(
          (item) => item?.count || 0
        );
      case "yearly":
        return verdictData?.dashboard_getYearlyVerdictCount?.result?.map(
          (item) => item?.count || 0
        );
    }
  };
  const seriesX = () => {
    switch (mode) {
      case "daily":
        return verdictData?.dashboard_getDailyVerdictCount?.result?.map(
          (item) => new Date(item?.date).toLocaleDateString("fa-IR")
        );
      case "monthly":
        return verdictData?.dashboard_getMonthlyVerdictCount?.result?.map(
          (item) => getFaMonth(((item?.monthNum || 0) + 8) % 12)
        );
      case "yearly":
        return verdictData?.dashboard_getYearlyVerdictCount?.result?.map(
          (item) => convertToPersianDigits((item?.yearNum || 622) - 621)
        );
    }
  };

  return (
    <div className=" gap-5 grid md:grid-cols-2 w-full ltr">
      <StateCountChart />
      <div className="flex flex-col bg-white-50 shadow-xl outline-1 outline outline-gray-40 rounded-2xl">
        <div className="flex items-center justify-start border-b p-5 border-gray-40 text-medium_16">
          تعداد رای های صادر شده
        </div>

        <div className="flex flex-col items-center justify-center p-5 ">
          <div className="grid grid-cols-3 w-fit shadow-xl rounded-full gap-0">
            <button
              onClick={() => setMode("daily")}
              className={`${
                mode === "daily"
                  ? "bg-black-100 text-white-50"
                  : " bg-white-100 text-black-100"
              } rounded-full px-6 py-2 text-bold_16 ease-linear duration-200 whitespace-nowrap overflow-hidden text-ellipsis border-0 cursor-pointer hover:shadow-lg`}
            >
              روزانه
            </button>
            <button
              onClick={() => setMode("monthly")}
              className={`${
                mode === "monthly"
                  ? "bg-black-100 text-white-50"
                  : " bg-white-100 text-black-100"
              } rounded-full px-6 py-2 text-bold_16 ease-linear duration-200 whitespace-nowrap overflow-hidden text-ellipsis border-0 cursor-pointer hover:shadow-lg`}
            >
              ماهانه
            </button>
            <button
              onClick={() => setMode("yearly")}
              className={`${
                mode === "yearly"
                  ? "bg-black-100 text-white-50"
                  : " bg-white-100 text-black-100"
              } rounded-full px-6 py-2 text-bold_16 ease-linear duration-200 whitespace-nowrap overflow-hidden text-ellipsis border-0 cursor-pointer hover:shadow-lg`}
            >
              سالانه
            </button>
          </div>
          <div className="w-full aspect-[20/9]">
            {/* <CacheProvider value={cacheLtr}> */}
            <LineChart
              xAxis={[
                {
                  data: seriesX() || ["همه"],
                  scaleType: "point",
                },
              ]}
              series={[
                {
                  label: "تعداد رای های صادر شده",
                  data: seriesY() || [0],
                  connectNulls: true,
                  showMark: true,
                },
              ]}
              sx={{
                direction: "ltr",
                overflow: "visible",
              }}
            />
            {/* </CacheProvider> */}
          </div>
        </div>
      </div>

      <ApprovedComplaintsChart />
      <DeniedComplaintsChart />
      <ExpertCountChart />
    </div>
  );
};

export default Dashboard;
