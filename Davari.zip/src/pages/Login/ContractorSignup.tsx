/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { useMutation } from "@apollo/client";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Checkbox,
} from "@mui/material";
import { useState } from "react";
import { useForm } from "react-hook-form";
import OtpInput from "react-otp-input";
import {
  useCheckOrgUserMutation,
  useConfirmCompanyDataMutation,
  useConfirmPhoneNumberMutation,
  useSendCodeMutation,
  useUserSignUpMutation,
  useValidatePhoneNumberMutation,
} from "../../../generated-types";
import BackButton from "../../components/BackButton";
import FaTextField from "../../components/FaComponents/FaTextField";
import FileBox from "../../components/FileBox";
import { UserSignUpDocument, UserType } from "../../gql/graphql";
import { confirmPhoneNumeber, generatePassword } from "./SignUp/gql/mutations";
import { DatePicker } from "@mui/x-date-pickers";
import NewModal from "../../components/Modals";
import departments from "../../assets/departments_hierarchy_with_subdepartments.json";
import DepartmentAccordion from "../../components/Login/DepartmentAccordion";
import { DepartmentsHierarchyWithSubdepartmentsRootObject } from "../../assets/types";

const ContractorSignupPage = () => {
  const [CodeIsSent, setCodeIsSent] = useState(false);
  const [userType, setUserType] = useState<"organization" | "individual">(
    "individual"
  );
  const [organizationModal, setOrganizationModal] = useState<{
    open: boolean;
    code?: number;
    search?: string;
    department?: DepartmentsHierarchyWithSubdepartmentsRootObject;
  }>({ open: false, code: undefined });
  const [otp, setOtp] = useState<string>("");
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
    watch,
  } = useForm<{
    companyNationalCode: string;
    ceoNationalCode: string;
    phoneNumber: string;
    confirmCode: string;
  }>({
    defaultValues: {
      companyNationalCode: "",
      ceoNationalCode: "",
      phoneNumber: "",
      confirmCode: "",
    },
  });
  const [checkPhoneNumber, { error, loading }] = useValidatePhoneNumberMutation(
    {
      variables: {
        nationalCode: watch("ceoNationalCode"),
        phoneNumber: watch("phoneNumber"),
      },
    }
  );

  const [CheckOrgUser] = useCheckOrgUserMutation({
    variables: {
      input: {
        nationalCode: watch("ceoNationalCode"),
        orgNationalCode: watch("companyNationalCode"),
      },
    },
  });

  const [confirmPhoneNumeber] = useConfirmPhoneNumberMutation({
    variables: {
      phoneNumber: watch("phoneNumber"),
      verificationCode: watch("confirmCode"),
    },
  });
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmCEO, { data: ceoData }] = useConfirmCompanyDataMutation({
    variables: {
      input: {
        cEONationalCode: watch("ceoNationalCode"),
        cEOPhoneNumber: watch("phoneNumber"),
        companyNationalCode: watch("companyNationalCode"),
      },
    },
    onCompleted(data, clientOptions) {
      console.log(data);

      if (data.user_confirmCompanyData?.status.code == 1) {
        void sendCodeMutation({
          variables: {
            phoneNumber: watch("phoneNumber"),
          },
        });
      } else {
        if (data.user_confirmCompanyData?.status.code == 153) {
          alert("شماره تلفن و کد ملی با هم مقایرت ندارند");
        }
      }
    },
    onError(error, clientOptions) {
      console.log(error.graphQLErrors);
    },
  });

  const [sendCodeMutation] = useSendCodeMutation({
    variables: {
      phoneNumber: watch("phoneNumber"),
    },
    onCompleted(data, clientOptions) {
      setCodeIsSent(true);
    },
  });

  const [generatePasswordMutation] = useMutation(generatePassword);

  const [userSignUp] = useUserSignUpMutation({
    onCompleted(data, clientOptions) {
      console.log("userSignUp", data);
      if (data?.user_signUp?.status?.code == 1) {
        setUserName(data?.user_signUp?.result?.userName || "");
        alert("ثبتنام کاربر صورت پذیرفت");
      }
    },
  });

  const onSubmit = (data: {
    companyNationalCode: string;
    ceoNationalCode: string;
    phoneNumber: string;
    confirmCode: string;
  }) => {
    if (CodeIsSent) {
      try {
        void generatePasswordMutation({
          onCompleted(gd, clientOptions) {
            console.log("generatePasswordMutation", gd);
            setPassword(gd.test_generatePassword as string);
            void confirmPhoneNumeber({
              onCompleted(data, clientOptions) {
                console.log("checkPhoneNumber", data);
                if (data.user_confirmPhoneNumber?.code === 1) {
                  void userSignUp({
                    variables: {
                      fullName: `${
                        ceoData?.user_confirmCompanyData?.result?.firstNameFA ||
                        ""
                      } ${
                        ceoData?.user_confirmCompanyData?.result?.lastNameFA ||
                        ""
                      }`,
                      phoneNumber: watch("phoneNumber"),
                      nationalCode: watch("ceoNationalCode"),
                      password: gd.test_generatePassword,
                      confirmPassword: gd.test_generatePassword,
                      isJury: false,
                      userName: watch("companyNationalCode"),
                      email: "",
                      userType: UserType.ContractorOrConsultant,
                      birthDate:
                        ceoData?.user_confirmCompanyData?.result?.birthDateSh,
                    },
                  });
                }
              },
            });
          },
        });
      } catch (error) {
        console.log(error);
      }
    } else {
      try {
        void sendCodeMutation();
        setCodeIsSent(true);
      } catch (error) {
        console.log(error);
      }
    }
  };

  return (
    <form
      className="grid grid-cols-2 gap-5 w-full"
      onSubmit={handleSubmit(onSubmit)}
    >
      <div className="col-span-full flex justify-center absolute top-0 right-0">
        <BackButton />
      </div>

      <div className="col-span-full flex justify-center items-center">
        <div className="grid grid-cols-2 items-center justify-center rounded-full outline outline-1 outline-primary-500 *:duration-300">
          <div
            className={`rounded-full ${
              userType == "individual"
                ? "bg-primary-500 font-bold"
                : "bg-white-100 text-secondary-400"
            } p-2 cursor-pointer`}
            onClick={() => setUserType("individual")}
          >
            <div className="text w-full text-center"> ثبت‌نام شرکت</div>
          </div>
          <div
            className={`rounded-full ${
              userType == "organization"
                ? "bg-primary-500 font-bold"
                : "bg-white-100 text-secondary-400"
            } p-2 cursor-pointer`}
            onClick={() => setUserType("organization")}
          >
            <div className="text w-full text-center">ثبت‌نام دستگاه اجرایی</div>
          </div>
        </div>
      </div>

      {userType == "organization" && (
        <>
          <NewModal
            title="انتخاب دستگاه اجرایی"
            open={organizationModal.open}
            onClose={() => setOrganizationModal({ open: false })}
            background="white"
            isCloseable={true}
          >
            <div className="flex flex-col gap-2 w-full">
              <FaTextField
                label="جستجو"
                placeholder="جستجو"
                type="text"
                onChange={(e) =>
                  setOrganizationModal({
                    ...organizationModal,
                    search: e.target.value,
                  })
                }
                value={organizationModal.search}
                sx={{
                  "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                    borderRadius: "15px",
                  },
                }}
              />
              {departments
                ?.filter((department) => {
                  if (organizationModal.search && organizationModal.search != "") {
                    return (
                      department.Department_Name.includes(
                        organizationModal.search
                      ) ||
                      department.Department_Code ==
                        Number(organizationModal.search) ||
                      department.sub_departments.some((sub) =>
                        sub.Department_Name.includes(
                          organizationModal.search || ""
                        )
                      )
                    );
                  }
                  return true;
                })
                .map((department) => {
                  return (
                    <DepartmentAccordion
                      department={department}
                      onSelect={(department) => {
                        setOrganizationModal({
                          open: false,
                          code: department.Department_Code,
                          department: department,
                        });
                        setValue(
                          "companyNationalCode",
                          String(department.Department_Code)
                        );
                      }}
                      key={department.Department_Code}
                    />
                  );
                })}
            </div>
          </NewModal>

          <button
            className="col-span-full w-full rounded-lg border-gray-40 bg-transparent text-gray-50 py-2 cursor-pointer hover:shadow-sm"
            onClick={(e) => {
              e.preventDefault();
              setOrganizationModal({ open: true });
            }}
          >
            {organizationModal.department?.Department_Name ||
              "انتخاب دستگاه اجرایی"}
          </button>
          <FaTextField
            label="کد ملی بالاترین مقام"
            placeholder="کد ملی بالاترین مقام"
            type="text"
            inputProps={{
              ...register("ceoNationalCode", {
                required: "کد ملی بالاترین مقام اجباری است",
              }),
            }}
            sx={{
              "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                borderRadius: "15px",
              },
            }}
          />
          <DatePicker
            label="تاریخ تولد بالاترین مقام"
            sx={{
              "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                borderRadius: "15px",
              },
            }}
          />
          <FaTextField
            label="شماره همراه بالاترین مقام"
            placeholder="شماره همراه بالاترین مقام"
            type="text"
            inputProps={{
              ...register("phoneNumber", {
                required: "شماره همراه بالاترین مقام اجباری است",
              }),
            }}
            className="col-span-full"
            sx={{
              "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                borderRadius: "15px",
              },
            }}
          />

          {CodeIsSent && (
            <div className="flex justify-between items-center col-span-full">
              <div className="text">کد ارسالی</div>
              <OtpInput
                onChange={(t) => {
                  console.log(t);

                  setValue("confirmCode", t);
                }}
                value={watch("confirmCode")}
                inputType="text"
                numInputs={6}
                // renderSeparator={<span>•</span>}
                // inputType="number"
                containerStyle={{
                  direction: "ltr",
                }}
                shouldAutoFocus={true}
                inputStyle={{
                  outline: "1px solid rgba(0,0,0,0.2)",
                  width: "50px",
                  height: "50px",
                  borderRadius: "1rem",
                  margin: "0 1px",
                  background: "transparent",
                  border: "none",
                  //   outlineWidth:"none",
                  color: "black",
                }}
                placeholder="-"
                renderInput={(props) => (
                  <input
                    {...props}
                    className="text-black-100 placeholder:text-gray-55"
                  />
                )}
              />
            </div>
          )}

          {!CodeIsSent && (
            <button
              className="rounded-full col-span-full p-3 bg-primary-500 cursor-pointer hover:shadow-xl outline-none ring-0 border-0"
              onClick={(e) => {
                e.preventDefault();
                void CheckOrgUser({
                  onCompleted(data, clientOptions) {
                    if (data.user_checkOrgUser?.code == 1) {
                      void sendCodeMutation({
                        variables: {
                          phoneNumber: watch("phoneNumber"),
                        },
                      });
                    }
                  },
                });
                // void confirmCEO();
              }}
            >
              ارسال کد ثبت‌نام
            </button>
          )}

          {CodeIsSent && (
            <button
              type="submit"
              className="rounded-full col-span-full p-3 bg-primary-500 cursor-pointer hover:shadow-xl outline-none ring-0 border-0"
              disabled={!userName}
            >
              ثبت‌نام
            </button>
          )}

          {userName && (
            <div className="flex flex-col gap-4">
              <div className="text">نام کاربری: {userName}</div>
              <div className="text">رمزعبور : {password}</div>
            </div>
          )}
        </>
      )}

      {userType == "individual" && (
        <>
          <FaTextField
            label="شناسه ملی شرکت"
            placeholder="شناسه ملی شرکت"
            type="text"
            sx={{
              "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                borderRadius: "15px",
              },
            }}
            inputProps={{
              ...register("companyNationalCode", {
                required: "شناسه ملی شرکت اجباری است",
              }),
            }}
            className="col-span-full"
          />
          <FaTextField
            label="کد ملی مدیر عامل"
            placeholder="کد ملی مدیر عامل"
            type="text"
            inputProps={{
              ...register("ceoNationalCode", {
                required: "کد ملی مدیر عامل اجباری است",
              }),
            }}
            sx={{
              "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                borderRadius: "15px",
              },
            }}
          />
          <FaTextField
            label="شماره همراه مدیر عامل"
            placeholder="شماره همراه مدیر عامل"
            type="text"
            inputProps={{
              ...register("phoneNumber", {
                required: "شماره همراه مدیر عامل اجباری است",
              }),
            }}
            sx={{
              "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
                borderRadius: "15px",
              },
            }}
          />

          {/* اینجانب دارای اختیار طرح درخواست داوری میباشم */}

          <div className="flex items-center col-span-full">
            <Checkbox />
            <div className="text text-sm">
              اینجانب، به استناد وکالت‌نامه/ اساسنامه/ مشارکت‌نامه شرکت، دارای
              اختیار طرح درخواست داوری می‌باشم.{" "}
            </div>
          </div>

          <div className="flex items-center w-full justify-between gap-4 col-span-full ">
            <div className="text whitespace-nowrap">
              {" "}
              وکالت‌نامه/اساسنامه شرکت :
            </div>
            <FileBox title="" className="w-full rounded-xl" row />
          </div>

          {CodeIsSent && (
            <div className="flex justify-between items-center col-span-full">
              <div className="text">کد ارسالی</div>
              <OtpInput
                onChange={(t) => {
                  console.log(t);

                  setValue("confirmCode", t);
                }}
                value={watch("confirmCode")}
                inputType="text"
                numInputs={6}
                // renderSeparator={<span>•</span>}
                // inputType="number"
                containerStyle={{
                  direction: "ltr",
                }}
                shouldAutoFocus={true}
                inputStyle={{
                  outline: "1px solid rgba(0,0,0,0.2)",
                  width: "50px",
                  height: "50px",
                  borderRadius: "1rem",
                  margin: "0 5px",
                  background: "transparent",
                  border: "none",
                  //   outlineWidth:"none",
                  color: "black",
                }}
                renderInput={(props) => (
                  <input
                    {...props}
                    className="text-black-100 placeholder:text-gray-55"
                  />
                )}
              />
            </div>
          )}

          {!CodeIsSent && (
            <button
              className="rounded-full col-span-full p-3 bg-primary-500 cursor-pointer hover:shadow-xl outline-none ring-0 border-0"
              onClick={(e) => {
                e.preventDefault();
                void confirmCEO();
              }}
            >
              ارسال کد ثبت‌نام
            </button>
          )}

          {CodeIsSent && (
            <button
              type="submit"
              className="rounded-full col-span-full p-3 bg-primary-500 cursor-pointer hover:shadow-xl outline-none ring-0 border-0"
              disabled={!userName}
            >
              ثبت‌نام
            </button>
          )}

          {userName && (
            <div className="flex flex-col gap-4">
              <div className="text">نام کاربری: {userName}</div>
              <div className="text">رمزعبور : {password}</div>
            </div>
          )}
        </>
      )}

      {/* <SignUpForm /> */}
    </form>
  );
};

export default ContractorSignupPage;
