/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { useLazyQuery } from "@apollo/client";
import {
  Button,
  IconButton,
  InputAdornment,
  LinearProgress,
  TextField,
  Typography,
} from "@mui/material";
import { red } from "@mui/material/colors";
import React, { useEffect, useState } from "react";
import { BsEye, BsEyeSlash } from "react-icons/bs";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useGetUserWithFilterQuery } from "../../../generated-types";
import { useUserStore } from "../../Context/UserStore";
import { MutationWrapper } from "../../GraphQL/MutationWrapper";
import { UserLogin } from "../../GraphQL/Users/Mutations";
import { TokenCheckDocument } from "../../gql/graphql";
import { AccessesEnum } from "../../static/Accesses";
import { primary, primaryLight, secondary } from "../../theme/color";

const SignIn = () => {
  let [searchParams, setSearchParams] = useSearchParams();
  const oldPath = searchParams.get("path");
  const user = useUserStore((state) => state.user);
  const setJury = useUserStore((state) => state.setJury);
  const setUser = useUserStore((state) => state.setUser);
  const setIsMailRoom = useUserStore((state) => state.setIsMailRoom);
  const setAccesses = useUserStore((state) => state.setAccesses);
  const token = useUserStore((state) => state.token);
  const logedOut = useUserStore((state) => state.logedOut);
  const [userName, setUserName] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [phone, setPhone] = React.useState<number>();
  const [showPassword, setShowPassword] = React.useState(false);
  const navigate = useNavigate();
  const [loginError, setLoginError] = useState<{
    message: string;
    code: number;
  }>();

  const {
    handleMutation,
    loading: loadingMutation,
    error,
  } = MutationWrapper(UserLogin, "user_signIn");

  useEffect(() => {
    console.log("token" + token);
    if (token && token !== "") {
      console.log("oldPath", oldPath);
      if (oldPath && oldPath !== "" && !logedOut) {
        // navigate(oldPath);
        window.location.href = oldPath;
      } else {
        window.location.href = "/";
      }
    }
  }, [logedOut, navigate, oldPath, token]);

  const [TokenCheck] = useLazyQuery(TokenCheckDocument, {
    onCompleted(data) {
      console.log("tokenCheck", data.user_isTokenValid);
    },
    // fetchPolicy: "network-only",
    nextFetchPolicy: "network-only",
    pollInterval: 1000,
  });

  const { data: users } = useGetUserWithFilterQuery({
    variables: {
      filter: {
        parent: {
          userName: {
            eq: "Dadgostari",
          },
        },
      },
    },
    onCompleted(data) {
      console.log("users", data);
    },
  });

  console.log(import.meta.env.VITE_GRAPHQL_URL);

  useEffect(() => {
    if (token && token !== "") {
      void TokenCheck({
        onCompleted(data) {
          console.log("tokenCheck", data.user_isTokenValid);
          if (data?.user_isTokenValid) {
            if (oldPath && oldPath !== "" && !logedOut) {
              // navigate(oldPath);
              window.location.href = oldPath;
            } else {
              // navigate("/");
              window.location.href = "/";
            }
          }
        },
        onError(error) {
          console.log(error);
        },
      });
    }
  }, [TokenCheck, token, oldPath, navigate, logedOut]);

  return (
    <>
      <Typography
        variant="body1"
        sx={{
          marginTop: "1rem",
          paddingBottom: "1rem",
        }}
        className="text-sm text-secondary-400"
      >
        برای ورود به سامانه نام کاربری و رمز عبور خود را وارد نمایید
      </Typography>

      {}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          // void userLogin();
          void handleMutation({
            variables: {
              userName: userName,
              password: password,
            },
          }).then((data) => {
            console.log(data);
            if (data instanceof Error) {
              setLoginError({
                message: data.message,
                code: data.name === "Error" ? 500 : 400,
              });
            } else {
              const expireDate = new Date(data.expireDate);
              setUser(data.user, data.token, expireDate);
              localStorage.setItem("token", data.token);
              setLoginError(undefined);
              setIsMailRoom(
                data.user.parentId === "e7a85297-91d4-4f27-a4b2-ff394fe71dd3"
              );
              if (
                data.user.parentId === "e7a85297-91d4-4f27-a4b2-ff394fe71dd3"
              ) {
                setAccesses([
                  AccessesEnum.PORTAL,
                  AccessesEnum.ADMIN_PANEL_USERS,
                  AccessesEnum.ADMIN_PANEL,
                ]);
              }
              setJury(
                users?.user_getUsers.result?.items?.find(
                  (a) => a.id === data.user.id
                )
                  ? true
                  : false
              );

              if (
                users?.user_getUsers.result?.items?.find(
                  (a) => a.id === data.user.id
                )
                  ? true
                  : false
              ) {
                setAccesses([AccessesEnum.EXPERTS_PORTAL, AccessesEnum.HOME]);
              }
            }
          });
        }}
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
        }}
      >
        <TextField
          label="نام کاربری"
          variant="outlined"
          autoComplete="username"
          onChange={(e) => setUserName(e.target.value)}
          // helperText={loginError?.message}
          error={loginError ? true : false}
          value={userName}
          InputProps={{
            sx: {
              borderRadius: "15px",
            },
          }}
          sx={{
            width: "80%",
            "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
              borderRadius: "15px",
            },
          }}
        />
        <TextField
          label="رمز عبور"
          variant="outlined"
          autoComplete="password"
          type={showPassword ? "text" : "password"}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton onClick={() => setShowPassword(!showPassword)}>
                  {!showPassword ? <BsEye /> : <BsEyeSlash />}
                </IconButton>
              </InputAdornment>
            ),
            sx: {
              borderRadius: "15px",
            },
          }}
          onChange={(e) => setPassword(e.target.value)}
          helperText={loginError?.message}
          error={loginError ? true : false}
          value={password}
          sx={{
            width: "80%",
            marginTop: "1rem",
            "& .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline": {
              borderRadius: "15px",
            },
          }}
        />

        <div className="grid grid-cols-1 items-center justify-center w-[80%] mt-4 gap-2">
          <Button
            variant="contained"
            fullWidth
            sx={{
              backgroundColor: error?.message ? red[500] : primary,
              color: "white",
              borderRadius: "3rem",
              boxShadow: "none",
              padding: "0.5rem",
              "&:hover": {
                backgroundColor: primaryLight,
                color: secondary,
              },
            }}
            type="submit"
          >
            {loadingMutation ? (
              <LinearProgress variant="indeterminate" color="secondary" />
            ) : (
              ""
            )}
            ورود
          </Button>
        </div>
      </form>

      {/* <Typography
        sx={{
          marginY: "0.2rem",
        }}
      >
        یا
      </Typography> */}

      <div className="flex flex-wrap gap-1 mt-1 w-[80%]">
        <Button
          variant="text"
          // sx={{
          //   marginTop: "0.1rem",
          //   color: primary,
          //   borderRadius: "15px",
          //   padding: "0.5rem",
          //   textShadow: 2,
          // }}
          className="text-center text-primary-500 flex-auto"
          href="/login/otp"
          onClick={(e) => {
            e.preventDefault();
            navigate("/login/otp");
          }}
        >
          ورود از طریق رمز یکبار مصرف
        </Button>
        <Button
          variant="text"
          // sx={{
          //   marginTop: "0.1rem",
          //   color: primary,
          //   borderRadius: "15px",
          //   padding: "0.5rem",
          //   textShadow: 2,
          // }}
          className="text-center text-primary-500 flex-auto"
          href="/login/forgotPassword"
        >
          فراموشی رمز عبور
        </Button>
        <Button
          variant="text"
          // sx={{
          //   marginTop: "0.1rem",
          //   color: primary,
          //   borderRadius: "15px",
          //   padding: "0.5rem",
          //   width: "fit-content",
          //   textShadow: 2,
          // }}
          href="/login/contractor_signup"
          className="text-center flex-auto text-primary-500"
        >
          ثبت‌نام شرکت ها/ دستگاه های اجرایی
        </Button>
      </div>

      {error?.message && (
        <Typography
          variant="body1"
          sx={{
            marginTop: "1rem",
            paddingBottom: "1rem",
            color: red[500],
          }}
        >
          {error?.message}
        </Typography>
      )}
      {/* <a
        // @ts-ignore
        referrerpolicy="origin"
        target="_blank"
        href="https://trustseal.enamad.ir/?id=514566&Code=cpV5uuCvq34c5pPdADTItCLtOCgwcJtS"
        className="aspect-square w-14 h-14"
      >
        <img
          // @ts-ignore
          referrerpolicy="origin"
          src="https://trustseal.enamad.ir/logo.aspx?id=514566&Code=cpV5uuCvq34c5pPdADTItCLtOCgwcJtS"
          alt=""
          className="cursor-pointer"
          code="cpV5uuCvq34c5pPdADTItCLtOCgwcJtS"
        />
      </a> */}
    </>
  );
};

export default SignIn;
