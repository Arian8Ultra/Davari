/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import { useMutation, useQuery } from "@apollo/client";
import { Add, CancelRounded } from "@mui/icons-material";
import {
  Alert,
  Box,
  Button,
  Checkbox,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  IconButton,
  List,
  MenuItem,
  Radio,
  RadioGroup,
  TextField,
  Typography,
  colors,
} from "@mui/material";
import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useUserStore } from "../../../Context/UserStore";
import { UPDATE_COMPLAINT } from "../../../GraphQL/Complaints/Mutations";
import {
  ContractSmall,
  UPDATE_CONTRACT_BY_ACCUSED,
} from "../../../GraphQL/Contracts/Mutations";
import { GET_CONTRACT } from "../../../GraphQL/Contracts/Queries";
import BackButton from "../../../components/BackButton";
import FaTextField from "../../../components/FaComponents/FaTextField";
import FaTypography from "../../../components/FaComponents/FaTypography";
import FileBox from "../../../components/FileBox";
import countries from "../../../static/Countries";
import states from "../../../static/states.json";
import {
  Green,
  GreenLight,
  primary,
  secondary,
  secondaryDark,
} from "../../../theme/color";
import { GET_ALL_ORGANIZATION_USERS } from "../../../GraphQL/Users/Queries";
import DateButton from "../../../components/DateButton";
import fehrestbaha from "../../../static/fehrestbaha.json";
import TimeLine from "../../../components/TimeLine";
import { DatePicker } from "@mui/x-date-pickers";
import { UpdateComplaintDocument } from "../../../../generated-types";
import { getComplaintStateWithEnum } from "../../../functions/ComplaintStatesFunc";
import { ComplaintStateStatus } from "../../../gql/graphql";
import { NumericFormat } from "react-number-format";

const UpdateContractPage = () => {
  const user = useUserStore((state) => state.user);
  const { complaintId, contractId } = useParams();
  const [stage, setStage] = useState(1);
  const [Employer, setEmployer] = React.useState<string>();
  const [Employee, setEmployee] = React.useState<string>();
  const [Currency, setCurrency] = useState<string>("ریال");

  const [tempPeopleFromAccuser, SetTempPeopleFromAccuser] = useState<{
    name?: string;
    phoneNumber?: string;
    position?: string;
  }>();
  const [tempPeopleFromAccused, SetTempPeopleFromAccused] = useState<{
    name?: string;
    phoneNumber?: string;
    position?: string;
  }>();
  const [RelatedPeopleByAccusser, setRelatedPeopleByAccusser] = React.useState<
    {
      name?: string;
      phone?: string;
      position?: string;
    }[]
  >([]);
  const [RelatedPeopleByAccusserError, setRelatedPeopleByAccusserError] =
    React.useState({
      error: false as boolean,
      text: "" as string,
    });

  const [RelatedPeopleByAccussed, setRelatedPeopleByAccussed] = React.useState<
    {
      name?: string;
      phone?: string;
      position?: string;
    }[]
  >([]);
  const [RelatedPeopleByAccussedError, setRelatedPeopleByAccussedError] =
    React.useState({
      error: false as boolean,
      text: "" as string,
    });
  const [Nationality, setNationality] = React.useState<string>();
  const [NationalityError, setNationalityError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [AccusedNationality, setAccusedNationality] = React.useState("");
  const [AccusedNationalityError, setAccusedNationalityError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [contratDetails, setContratDetails] = React.useState<{
    contratTypes: string[];
    other: boolean;
    CircularTitle?: string;
    CircularNumber?: string;
    CircularDate?: Date;
  }>({
    contratTypes: [""],
    CircularDate: undefined,
    CircularNumber: undefined,
    CircularTitle: undefined,
    other: false,
  });
  const [contratDetailsError, setContratDetailsError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [ContractSubject, setContractSubject] = React.useState<string>();
  const [ContractSubjectError, setContractSubjectError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [ContractNumber, setContractNumber] = React.useState<string>();
  const [ContractNumberError, setContractNumberError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [ContractDate, setContractDate] = React.useState<Date>();
  const [ContractDateError, setContractDateError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [InitialBudget, setInitialBudget] = React.useState<number>();
  const [InitialBudgetError, setInitialBudgetError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [InitialTimePeriod, setInitialTimePeriod] = React.useState<number>();
  const [InitialTimePeriodError, setInitialTimePeriodError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [PriceListOfBasicUnitOfField, setPriceListOfBasicUnitOfField] =
    React.useState<
      [
        {
          year: string;
          price: string;
        }
      ]
    >();
  const [
    PriceListOfBasicUnitOfFieldError,
    setPriceListOfBasicUnitOfFieldError,
  ] = React.useState([
    {
      error: false as boolean,
      text: "" as string,
    },
  ]);

  const [
    IsSpecialPriceListAttachedToContract,
    setIsSpecialPriceListAttachedToContract,
  ] = React.useState<string>();

  const [RecommendedCoefficient, setRecommendedCoefficient] =
    React.useState<number>();
  const [AssigningType, setAssigningType] = React.useState<string>();
  const [AssigningTypeError, setAssigningTypeError] = React.useState([
    {
      error: false as boolean,
      text: "" as string,
    },
  ]);
  const [DoesContainAdjustment, setDoesContainAdjustment] =
    React.useState<boolean>(true);
  const [DoesContainAdjustmentEror] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [Adjustment, setAdjustment] = useState<{
    number: number;
    date: Date;
  }>();
  const [AdjustmentError, setAdjustmentError] = useState({
    error: false as boolean,
    text: "" as string,
  });
  const [BaseIndexPeriod, setBaseIndexPeriod] = React.useState<{
    isQuarter: boolean;
    quarter: string;
    month: string;
    year: string;
  }>();
  const [BaseIndexPeriodError, setBaseIndexPeriodError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [OperationStartDateAccuser, setOperationStartDateAccuser] =
    React.useState<string>();
  const [OperationStartDateAccuserError, setOperationStartDateAccuserError] =
    React.useState({ error: false as boolean, text: "" as string });
  const [OperationStartDate, setOperationStartDate] = React.useState<Date>();
  const [OperationStartDateError, setOperationStartDateError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [
    PhysicalProgressInArbitrationDate,
    setPhysicalProgressInArbitrationDate,
  ] = React.useState<number>();
  const [
    PhysicalProgressInArbitrationDateError,
    setPhysicalProgressInArbitrationDateError,
  ] = React.useState({ error: false as boolean, text: "" as string });
  const [
    FinancialProgressInArbitrationDateAccuser,
    setFinancialProgressInArbitrationDateAccuser,
  ] = React.useState<number>();
  const [
    FinancialProgressInArbitrationDateAccuserError,
    setFinancialProgressInArbitrationDateAccuserError,
  ] = React.useState({ error: false as boolean, text: "" as string });
  const [ContractStatusInArbitration, setContractStatusInArbitration] =
    React.useState<{
      title: string;
      temp: Date | null;
      final: Date | null;
    }>({
      title: "",
      temp: null,
      final: null,
    });

  const [TemporaryDelivery, setTemporaryDelivery] = useState<{
    checked: boolean;
    date: Date;
  }>();
  const [FinalDelivery, setFinalDelivery] = useState<{
    checked: boolean;
    date: Date;
  }>();
  const [
    ContractStatusInArbitrationError,
    setContractStatusInArbitrationError,
  ] = React.useState<[{ error: boolean; text: string }]>();
  const [ContractStatusInArbitrationDate, setContractStatusInArbitrationDate] =
    React.useState<string>();
  const [
    ContractStatusInArbitrationDateError,
    setContractStatusInArbitrationDateError,
  ] = React.useState({ error: false as boolean, text: "" as string });
  const [SupervisionDepartment, setSupervisionDepartment] =
    React.useState<string>();
  const [SupervisionDepartmentError, setSupervisionDepartmentError] =
    React.useState({ error: false as boolean, text: "" as string });
  const [AuthorizedDelays, setAuthorizedDelays] = React.useState<number>();
  const [AuthorizedDelaysError, setAuthorizedDelaysError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [UnauthorizedDelays, setUnauthorizedDelays] = React.useState<number>();
  const [UnauthorizedDelaysError, setUnauthorizedDelaysError] = React.useState({
    error: false as boolean,
    text: "" as string,
  });
  const [AccusedDepartmentId, setAccusedDepartmentId] =
    React.useState<string>();
  React.useState({ error: false as boolean, text: "" as string });
  const [AccuserDepartmentId, setAccuserDepartmentId] =
    React.useState<string>();
  const [AccusedDepartmentIdError, setAccusedDepartmentIdError] =
    React.useState<{ error: boolean; text: string }>();
  const [FileNames, setFileNames] = useState<string[]>();
  const [Files, SetFiles] = useState<File[]>();

  const [departments, setDepartments] = React.useState<
    {
      label: string;
      id: string;
      type: "INDIVIDUAL" | "ORGANIZATION" | "CONTRACTOR_OR_CONSULTANT";
    }[]
  >([]);
  useQuery(GET_ALL_ORGANIZATION_USERS, {
    onCompleted(data) {
      console.log(data);
      // remove department that id is e7a85297-91d4-4f27-a4b2-ff394fe71dd3
      setDepartments(
        data?.user_getUsers?.result?.items?.map(
          (item: {
            id: number;
            fullName: string;
            userType:
              | "INDIVIDUAL"
              | "ORGANIZATION"
              | "CONTRACTOR_OR_CONSULTANT";
          }) => ({
            label: item.fullName,
            id: item.id,
            type: item.userType,
          })
        )
      );
    },
    onError(error) {
      console.log(error);
    },
  });

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  const handleErrors = () => {
    if (RelatedPeopleByAccussed && RelatedPeopleByAccussed.length <= 0) {
      setRelatedPeopleByAccussedError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }
    if (Nationality && Nationality.length <= 0) {
      setNationalityError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }
    if (AccusedNationality.length <= 0) {
      setAccusedNationalityError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }
    if (contratDetails && contratDetails?.contratTypes?.length <= 0) {
      setContratDetailsError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }
    if (ContractSubject && ContractSubject.length <= 0) {
      setContractSubjectError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }
    if (!ContractDate) {
      setContractDateError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!InitialBudget) {
      setInitialBudgetError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!InitialTimePeriod) {
      setInitialTimePeriodError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    PriceListOfBasicUnitOfField &&
      PriceListOfBasicUnitOfField.forEach((item, index) => {
        if (item.year.length <= 0 || item.price.length <= 0) {
          const newPriceListOfBasicUnitOfFieldError = [
            ...PriceListOfBasicUnitOfFieldError,
          ];
          newPriceListOfBasicUnitOfFieldError[index] = {
            error: true,
            text: "مقدار فیلد نباید خالی باشد",
          };
          setPriceListOfBasicUnitOfFieldError(
            newPriceListOfBasicUnitOfFieldError
          );
        }
      });

    if (AssigningType && AssigningType.length <= 0) {
      setAssigningTypeError([
        {
          error: true,
          text: "مقدار فیلد نباید خالی باشد",
        },
      ]);
    }

    if (BaseIndexPeriod && !BaseIndexPeriod.month) {
      setBaseIndexPeriodError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (BaseIndexPeriod && BaseIndexPeriod.year.length <= 0) {
      setBaseIndexPeriodError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (OperationStartDateAccuser && OperationStartDateAccuser.length <= 0) {
      setOperationStartDateAccuserError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!OperationStartDate) {
      setOperationStartDateError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!PhysicalProgressInArbitrationDate) {
      setPhysicalProgressInArbitrationDateError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!FinancialProgressInArbitrationDateAccuser) {
      setFinancialProgressInArbitrationDateAccuserError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (
      ContractStatusInArbitration &&
      ContractStatusInArbitration.title.length <= 0
    ) {
      setContractStatusInArbitrationError([
        {
          error: true,
          text: "مقدار فیلد نباید خالی باشد",
        },
      ]);
    }

    if (
      ContractStatusInArbitrationDate &&
      ContractStatusInArbitrationDate.length <= 0
    ) {
      setContractStatusInArbitrationDateError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (SupervisionDepartment && SupervisionDepartment.length <= 0) {
      setSupervisionDepartmentError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!AuthorizedDelays) {
      setAuthorizedDelaysError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (!UnauthorizedDelays) {
      setUnauthorizedDelaysError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    if (AccusedDepartmentId) {
      setAccusedDepartmentIdError({
        error: true,
        text: "مقدار فیلد نباید خالی باشد",
      });
    }

    return (
      RelatedPeopleByAccussedError.error ||
      AccusedNationalityError.error ||
      contratDetailsError.error ||
      ContractSubjectError.error ||
      ContractDateError.error ||
      InitialBudgetError.error ||
      InitialTimePeriodError.error ||
      PriceListOfBasicUnitOfFieldError.some((item) => item.error) ||
      AssigningTypeError.some((item) => item.error) ||
      DoesContainAdjustmentEror.error ||
      BaseIndexPeriodError.error ||
      OperationStartDateAccuserError.error ||
      OperationStartDateError.error ||
      PhysicalProgressInArbitrationDateError.error ||
      FinancialProgressInArbitrationDateAccuserError.error ||
      ContractStatusInArbitrationError?.some((item) => item.error) ||
      ContractStatusInArbitrationDateError.error ||
      SupervisionDepartmentError.error ||
      AuthorizedDelaysError.error ||
      UnauthorizedDelaysError.error ||
      AccusedDepartmentIdError?.error
    );
  };

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  const contract_details_items = [
    {
      id: 1,
      title:
        "موافقتنامه و شرایط عمومی و شرایط خصوصی پیمان‌ها- نشریه شماره ۴۳۱۱ – بخشنامه شماره ۸۴۲/۵۴-۱۰۸۸/۱۰۲ مورخ ۱۳۷۸/۰۳/۰۳",
      children: [
        {
          id: 2,
          title:
            "انعقاد قرارداد اجرای کارهای ساختمانی به صورت سرجمع- بخشنامه شماره ۹۶/۱۲۹۹۱۸۸ مورخ ۱۳۹۶/۰۵/۰۴",
        },
        {
          id: 3,
          title:
            "انعقاد قرارداد اجرای کارهای ساختمانی به صورت سرجمع- بخشنامه شماره ۱۰۰/۶۴۰۵ مورخ ۱۳۸۹/۰۲/۰۴",
        },
        {
          id: 4,
          title:
            "انعقاد قرارداد بر اساس فهرست بهای تجمیع شده راه، باند فرودگاه و زیرسازی راه آهن – شماره ۶۵۶۳۷/۱۰۰ مورخ ۱۳۹۱/۰۸/۱۴",
        },
      ],
    },
    {
      id: 5,
      title:
        "موافقتنامه و شرایط عمومی همسان قراردادهای خدمات مشاوره - نشریه شماره ۴۳۱۸- بخشنامه شماره ۱۰۵/۸۴۲-۵۴/۲۴۶۰- مورخ ۱۳۷۹/۰۴/۲۹",
    },
    {
      id: 6,
      title:
        "موافقتنامه و شرایط عمومی همسان قراردادهای خدمات مشاوره پژوهشی - نشریه شماره ۳۴۱۹- بخشنامه شماره ۲۷۵۳/۵۴-۱۶۷۰/۱۰۲ مورخ ۱۳۷۹/۰۵/۲۴",
    },
    {
      id: 7,
      title:
        "موافقتنامه و شرایط عمومی همسان قراردادهای خدمات مدیریت طرح- نشریه شماره ۲۴۱۲۱ مورخ ۱۳۸۰/۰۱/۲۸",
    },
    {
      id: 8,
      title:
        "موافقتنامه، پیوست‌ها، شرایط عمومی و شرایط خصوصی پیمان‌های تامین کالا و تجهیزات، ساختمان و نصب به صورت توام (PC)، برای کارهای صنعتی مورخ ۱۸/۱۲/۱۳۸۳",
    },
    {
      id: 9,
      title:
        "قرارداد همسان طرح و ساخت (EPC غیر صنعتی)- 85428/101 مورخ ۱۵/۰۵/۱۳۸۴",
    },
    {
      id: 10,
      title:
        "موافقت‌نامه مشارکت عمومی- خصوصی (PPP) بخشنامه شماره ۹۳/۱۷۲۸۰۴-مورخ ۲۶/۱۲/۱۳۹۳",
    },
    {
      id: 10,
      title:
        "موافقتنامه ساخت، بهره‌برداری، واگذاری (BOT)- نشریه شماره ۴۶۹ مورخ ۲۴/۱۰/۱۳۸۷",
    },
  ];
  //
  //
  //
  //
  //
  //
  //
  //
  // @ts-ignore
  const [createContractMutation, { data, loading }] = useMutation(
    UPDATE_CONTRACT_BY_ACCUSED,
    {
      variables: {
        AccuserRelatedPeople: JSON.stringify(RelatedPeopleByAccusser),
        AccusedRelatedPeople: JSON.stringify(RelatedPeopleByAccussed),
        AccuserNationality: Nationality,
        ContractType: contratDetails.contratTypes,
        CircularNumber: contratDetails.CircularNumber,
        CircularDate: contratDetails.CircularDate,
        ContractSubject: ContractSubject,
        // ContractNumber: ContractNumber,
        ContractDate: ContractDate,
        InitialBudget: InitialBudget,
        InitialTimePeriod: InitialTimePeriod,
        PriceListOfBasicUnitOfField: JSON.stringify(
          PriceListOfBasicUnitOfField
        ),
        IsSpecialPriceListAttachedToContract: String(
          IsSpecialPriceListAttachedToContract
        ),
        RecommendedCoefficient: RecommendedCoefficient,
        CoefficientType:
          RecommendedCoefficient && RecommendedCoefficient > 1
            ? "پلوس"
            : "مینوس",
        AssigningType: AssigningType,
        DoesContainAdjustment: String(DoesContainAdjustment),
        BaseIndexPeriod: JSON.stringify(BaseIndexPeriod),
        OperationStartDateAccuser: OperationStartDateAccuser,
        PhysicalProgressInArbitrationDateAccuser:
          PhysicalProgressInArbitrationDate,
        FinancialProgressInArbitrationDateAccuser:
          FinancialProgressInArbitrationDateAccuser,
        ContractStatusInArbitration: JSON.stringify(
          ContractStatusInArbitration
        ),
        SupervisionDepartment: SupervisionDepartment,
        AuthorizedDelaysAccuser: AuthorizedDelays,
        UnauthorizedDelaysAccuser: UnauthorizedDelays || undefined,
        id: contractId ? parseInt(contractId) : 0,
        Currency: Currency,
      },
    }
  );

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  useQuery(GET_CONTRACT, {
    variables: {
      id: contractId ? parseInt(contractId) : 0,
    },
    onCompleted(data) {
      console.log("GET_CONTRACT", data);
      const contract = data.contract_getContracts.result
        .items[0] as ContractSmall;
      console.log(contract);
      setContratDetails({
        ...contratDetails,
        contratTypes: contract.contractTypeByAccuser || [""],
        CircularNumber: contract.circularNumberByAccuser || undefined,
        CircularDate: contract.circularDateByAccuser || undefined,
        CircularTitle: contract.contractSubjectByAccuser || undefined,
        other:
          contract.circularDateByAccuser ||
          contract.circularNumberByAccuser ||
          contract.contractSubjectByAccuser
            ? true
            : false,
      });
      setContractSubject(contract.contractSubjectByAccuser);
      setAccusedDepartmentId(contract.accusedDepartmentUserId);
      setAccuserDepartmentId(contract.accuserDepartmentUserId);
      setContractNumber(contract.contractNumberByAccuser);
      setContractDate(contract.contractDateByAccuser);
      setInitialBudget(contract.initialBudgetByAccuser);
      setInitialTimePeriod(contract.initialTimePeriodByAccuser || undefined);
      setPriceListOfBasicUnitOfField(
        JSON.parse(contract.priceListOfBasicUnitOfFieldByAccuser || "")
      );
      setIsSpecialPriceListAttachedToContract(
        contract.isSpecialPriceListAttachedToContractByAccuser
      );
      contract.accuserRelatedPeopleByAccuser &&
        setRelatedPeopleByAccusser(
          JSON.parse(contract.accuserRelatedPeopleByAccuser)
        );
      contract.accusedRelatedPeopleByAccuser &&
        setRelatedPeopleByAccussed(
          JSON.parse(contract.accusedRelatedPeopleByAccuser)
        );
      setRecommendedCoefficient(contract.recommendedCoefficientByAccuser);
      setNationality(contract.accuserNationality);
      setAssigningType(contract.assigningTypeByAccuser);
      setDoesContainAdjustment(
        contract.doesContainAdjustmentByAccuser == "true"
      );
      setBaseIndexPeriod(JSON.parse(contract.baseIndexPeriodByAccuser || ""));
      setOperationStartDate(contract.operationStartDateByAccuser || new Date());
      setFinancialProgressInArbitrationDateAccuser(
        contract.financialProgressInArbitrationDateByAccuser
      );
      setContractStatusInArbitration(
        JSON.parse(contract.contractStatusAndDateInArbitrationByAccuser || "")
      );
      setSupervisionDepartment(contract.supervisionDepartmentByAccuser);
      setContractNumber(contractId);
      setAssigningType(contract.assigningTypeByAccuser);
      setAuthorizedDelays(
        contract.authorizedDelaysByAccuser
          ? contract.authorizedDelaysByAccuser
          : undefined
      );
      setUnauthorizedDelays(contract.unauthorizedDelaysByAccuser);
      setContractNumber(contract.contractNumberByAccuser);
    },
  });

  //
  //
  //
  //
  //
  //
  //

  const navigate = useNavigate();
  const [updateCompaint] = useMutation(UpdateComplaintDocument, {
    variables: {
      id: complaintId ? parseInt(complaintId) : 0,
      complaintStateId: getComplaintStateWithEnum(
        ComplaintStateStatus.WaitingForAccusedToRegisterArbitrationTerms
      ).id,
    },
    onCompleted(data) {
      console.log("state", states.AccusedCompletedContract);
      console.log(data);
      alert("ثبت شد");
      navigate(`/complaints/${contractId}/${complaintId}/tablesPage`);
    },
  });
  //
  //
  //
  //
  //
  //
  //
  //

  return (
    <>
      <Box position={"relative"} width={"100%"}>
        <BackButton to="/complaints" />
        <TimeLine stage={stage} />
        <Box
          display={"grid"}
          gridTemplateColumns={"repeat(6, 1fr)"}
          alignItems={"center"}
          justifyContent={"center"}
          gap={2}
          padding={"2rem"}
          paddingTop={"0"}
          border={`2px solid ${stage == 1 ? secondary : primary}`}
          borderRadius={"1rem"}
          position={"relative"}
          marginY={"3rem"}
          width={{
            xs: "100%",
            sm: "100%",
            md: "80%",
            lg: "70%",
            xl: "66%",
          }}
          sx={{
            background: colors.grey[50],
            display: stage == 1 ? "grid" : "none",
          }}
          marginX={"auto"}
        >
          <Box
            gridColumn={"span 6"}
            borderRadius={"1rem"}
            sx={{
              position: "absolute",
              top: "0",
              left: "50%",
              transform: "translateY(-50%) translateX(-50%)",
              background: primary,
              padding: "0.5rem 1rem",
              userSelect: "none",
              width: "max-content",
              zIndex: 1000,
            }}
          >
            <FaTypography variant="h6" textAlign={"center"}>
              اطلاعات قرارداد
            </FaTypography>
          </Box>
          <FaTextField
            label="عنوان قرارداد: "
            variant="outlined"
            sx={{
              gridColumn: "span 6",
              mt: "50px",
            }}
            value={ContractSubject}
            focused={ContractSubject ? true : false}
            onChange={(e) => {
              setContractSubject(e.target.value);
            }}
            error={ContractSubjectError.error}
            helperText={ContractSubjectError.text}
          />
          <div
            style={{
              gridColumn: "span 6",
            }}
          />
          <TextField
            label="شناسه قرارداد : "
            variant="outlined"
            sx={{
              gridColumn: "span 3",
            }}
            value={ContractNumber}
            // type="number"
            focused={ContractNumber ? true : false}
            onChange={(e) => {
              setContractNumber(String(e.target.value));
            }}
            error={ContractNumberError.error}
            helperText={ContractNumberError.text}
          />
          <DateButton
            date={ContractDate}
            setDate={setContractDate}
            sx={{
              gridColumn: "span 3",
            }}
            label="تاریخ انعقاد قرارداد"
          />
          <div
            style={{
              gridColumn: "span 6",
            }}
          />
          <TextField
            label="کارفرما"
            sx={{
              width: "100%",
              gridColumn: "span 3",
            }}
            value={
              departments.find((d) => {
                return d.id === AccuserDepartmentId;
              })?.type === "ORGANIZATION"
                ? departments.find((d) => {
                    return d.id === AccuserDepartmentId;
                  })!.label
                : departments.find((d) => {
                    return d.id === AccusedDepartmentId;
                  })?.type === "ORGANIZATION"
                ? departments.find((d) => {
                    return d.id === AccusedDepartmentId;
                  })!.label
                : ""
            }
            onChange={(e) => {
              setEmployer(e.target.value);
            }}
            disabled={true}
            //   disabled
          >
            {departments.map((item) => (
              <MenuItem value={item.id}>{item.label}</MenuItem>
            ))}
          </TextField>
          <TextField
            label="طرف قرارداد"
            sx={{
              width: "100%",
              gridColumn: "span 3",
            }}
            value={
              departments.find((d) => {
                return d.id === AccusedDepartmentId;
              })?.type === "CONTRACTOR_OR_CONSULTANT"
                ? departments.find((d) => {
                    return d.id === AccusedDepartmentId;
                  })!.label
                : departments.find((d) => {
                    return d.id === AccuserDepartmentId;
                  })?.type === "CONTRACTOR_OR_CONSULTANT"
                ? departments.find((d) => {
                    return d.id === AccuserDepartmentId;
                  })!.label
                : ""
            }
            disabled={true}
          >
            {departments.map((item) => (
              <MenuItem value={item.id}>{item.label}</MenuItem>
            ))}
          </TextField>
          <div
            style={{
              gridColumn: "span 6",
            }}
          />
          <FaTextField
            label="نوع ارز قرارداد"
            variant="outlined"
            // type="number"
            sx={{
              gridColumn: "span 1",
            }}
            value={Currency}
            onChange={(e) => {
              setCurrency(e.target.value);
            }}
            focused={Currency ? true : false}
            // defaultValue={"ریال"}
            select
          >
            <MenuItem value={"ریال"}>ریال</MenuItem>
            <MenuItem value={"دلار"}>دلار</MenuItem>
            <MenuItem value={"یورو"}>یورو</MenuItem>
          </FaTextField>
          <NumericFormat
            customInput={FaTextField}
            thousandSeparator
            label="مبلغ اوليه/ حق‌الزحمه قرارداد: "
            variant="outlined"
            // type="number"
            InputProps={{
              endAdornment: String(Currency),
            }}
            sx={{
              gridColumn: "span 2",
            }}
            value={InitialBudget}
            onValueChange={(e) => {
              setInitialBudget(e.floatValue);
            }}
            focused={InitialBudget ? true : false}
            error={InitialBudgetError.error}
            helperText={InitialBudgetError.text}
          />
          <FaTextField
            label="مدت اوليه قرارداد: "
            variant="outlined"
            focused={InitialTimePeriod ? true : false}
            type="text"
            InputProps={{
              endAdornment: "ماه",
            }}
            sx={{
              gridColumn: "span 3",
            }}
            value={InitialTimePeriod}
            onChange={(e) => {
              setInitialTimePeriod(parseInt(e.target.value));
            }}
            error={InitialTimePeriodError.error}
            helperText={InitialTimePeriodError.text}
          />
          <div
            style={{
              gridColumn: "span 6",
            }}
          />
          <NumericFormat
            customInput={FaTextField}
            thousandSeparator
            label="مبلغ اوليه/ حق‌الزحمه قرارداد: "
            variant="outlined"
            // type="number"
            InputProps={{
              endAdornment: "ریال",
            }}
            sx={{
              gridColumn: "span 3",
            }}
            value={InitialBudget}
            onValueChange={(e) => {
              setInitialBudget(e.floatValue);
            }}
            error={InitialBudgetError.error}
            helperText={InitialBudgetError.text}
          />
          <FaTextField
            label="مدت اوليه قرارداد: "
            variant="outlined"
            type="text"
            InputProps={{
              endAdornment: "ماه",
            }}
            sx={{
              gridColumn: "span 3",
            }}
            value={InitialTimePeriod}
            onChange={(e) => {
              setInitialTimePeriod(parseInt(e.target.value));
            }}
            error={InitialTimePeriodError.error}
            helperText={InitialTimePeriodError.text}
          />

          {/* check box ابلاغ افزایش / کاهش مبلغ => وقتی انتخاب کرد یه باکس به اسم مبلغ نهایی قرارداد اضاف بشه */}

          <div
            style={{
              gridColumn: "span 6",
            }}
          />

          <Button
            sx={{
              color: secondary,
              backgroundColor: primary,
              borderRadius: "0.5rem",
              gridColumn: "5/span 2",
              display: stage == 1 ? "flex" : "none",
            }}
            onClick={() => {
              setStage(2);
            }}
          >
            ثبت و ادامه
          </Button>
        </Box>
        <Box
          display={"grid"}
          gridTemplateColumns={"repeat(12, 1fr)"}
          alignItems={"center"}
          justifyContent={"center"}
          gap={2}
          rowGap={"2rem"}
          padding={"2rem"}
          paddingTop={"0"}
          border={`2px solid ${secondary}`}
          borderRadius={"1rem"}
          position={"relative"}
          marginY={"3rem"}
          width={{
            xs: "100%",
            sm: "100%",
            md: "80%",
            lg: "70%",
            xl: "66%",
          }}
          marginX={"auto"}
          sx={{
            opacity: stage == 2 ? "100%" : 0,
            height: stage == 2 ? "max-content" : 0,
            overflow: stage == 2 ? "unset" : "hidden",
            transition: "all 0.2s ease-in-out",
            background: colors.grey[50],
          }}
        >
          <Box
            gridColumn={"span 6"}
            borderRadius={"1rem"}
            sx={{
              position: "absolute",
              top: "0",
              left: "50%",
              transform: "translateY(-50%) translateX(-50%)",
              background: primary,
              padding: "0.5rem 1rem",
              userSelect: "none",
              width: "max-content",
              zIndex: 1000,
            }}
          >
            <FaTypography variant="h6" textAlign={"center"}>
              فرم تکمیلی اطلاعات قرارداد
            </FaTypography>
          </Box>

          {/* 


        1- طرفین قرارداد


    
    */}

          <Button
            sx={{
              color: secondary,
              backgroundColor: primary,
              borderRadius: "0.75rem",
              gridColumn: "span 2",
              display: stage == 2 ? "flex" : "none",
              position: "absolute",
              top: "0",
              left: "1%",
              transform: "translateY(-50%)",
              padding: "0.5rem 1rem",
              userSelect: "none",
              width: "max-content",
              zIndex: 1000,
            }}
            onClick={() => {
              setStage(1);
            }}
          >
            بازگشت به مرحله قبل
          </Button>
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
            sx={{
              mt: "50px",
            }}
          >
            طرفین قرارداد
          </FaTypography>

          <FaTextField
            label="نام  خواهان"
            sx={{
              width: "100%",
              gridColumn: "span 6",
            }}
            value={
              departments.find((item) => {
                return item.id === AccuserDepartmentId;
              })?.label
            }
            placeholder={
              departments.find((item) => {
                return item.id === AccuserDepartmentId;
              })?.label
            }
            focused
            //   disabled
          />
          <FaTextField
            label="نام خوانده"
            sx={{
              width: "100%",
              gridColumn: "span 6",
            }}
            value={
              departments.find(
                (item) => AccusedDepartmentId && item.id === AccusedDepartmentId
              )?.label
            }
            placeholder={
              departments.find(
                (item) => AccusedDepartmentId && item.id === AccusedDepartmentId
              )?.label
            }
            focused
            //   disabled
          />
          {/* <Autocomplete
        disablePortal
        options={departments.filter(
          (item: { id: string }) =>
            item.id !== "e7a85297-91d4-4f27-a4b2-ff394fe71dd3"
        )}
        sx={{
          width: "100%",
          gridColumn: "span 3",
        }}
        renderInput={(params) => (
          <FaTextField
            {...params}
            label="نام  خوانده"
            error={
              AccusedDepartmentIdError &&
              AccusedDepartmentIdError.error
            }
            helperText={
              AccusedDepartmentIdError &&
              AccusedDepartmentIdError.text
            }
            value={
              departments.find(
                (item) =>
                  AccusedDepartmentId && item.id === AccusedDepartmentId
              )?.label
            }
            placeholder={
              departments.find(
                (item) =>
                  AccusedDepartmentId && item.id === AccusedDepartmentId
              )?.label
            }
          />
        )}
        onChange={(_e, value) => {
          if (value) {
            console.log(value);
            setAccusedDepartmentId(value.id.toString());
            void getUser({
              variables: {
                id: value.id.toString(),
              },
              onCompleted(data) {
                console.log(data);
                if (
                  data?.user_getUserQueryable?.result?.items[0]
                    ?.parent
                ) {
                  handleParent(
                    data?.user_getUserQueryable?.result?.items[0]
                      ?.parent,
                    {
                      fullName:
                        data?.user_getUserQueryable?.result
                          ?.items[0]?.fullName,
                      id: data?.user_getUserQueryable?.result
                        .items[0]?.id,
                    }
                  );
                } else {
                  setTreeViewObject({
                    fullName:
                      data?.user_getUserQueryable?.result?.items[0]
                        ?.fullName,
                    id: data?.user_getUserQueryable?.result.items[0]
                      ?.id,
                  });
                }
              },
            });
          }
        }}
        value={departments.find(
          (item) =>
            AccusedDepartmentId && item.id === AccusedDepartmentId
        )}
      /> */}
          {/* {AccusedDepartmentId} */}
          {/* <TreeChart gridColumn={"span 12"} object={treeViewObject} /> */}

          {/* <Divider
        orientation="horizontal"
        sx={{
          gridColumn: "span 12",
        }}
      /> */}

          <div
            style={{
              gridColumn: "span 12",
            }}
          />

          {/* 


      2- محل ثبت شرکت

    
    */}
          {/* <div
        style={{
          gridColumn: "span 4",
        }}
      /> */}
          <FaTypography variant="h5" gridColumn={"span 6"} textAlign={"center"}>
            محل ثبت شرکت
          </FaTypography>
          <FaTextField
            label="محل ثبت شرکت : "
            variant="outlined"
            sx={{
              gridColumn: "span 6",
            }}
            select
            SelectProps={{
              MenuProps: {
                sx: {
                  maxHeight: "20rem",
                },
              },
            }}
            value={Nationality}
            onChange={(e) => {
              setNationality(e.target.value);
            }}
            error={NationalityError.error}
            helperText={NationalityError.text}
          >
            {countries.map((item, index) => (
              <MenuItem key={index} value={item.name_fa}>
                {item.name_fa}
              </MenuItem>
            ))}
          </FaTextField>

          {/* <div
        style={{
          gridColumn: "span 4",
        }}
      /> */}

          {/* 


    3- مشخصات خوانده (امضاکننده قرارداد)

  
  */}

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />

          <Box
            gridColumn={"span 6"}
            display={"flex"}
            flexDirection={"column"}
            justifyContent={"center"}
            alignItems={"center"}
            rowGap={2}
          >
            <FaTypography variant="body1" gridColumn={"span 12"}>
              اسامی و تلفن (ثابت و همراه) نمایندگان(وکلا) از طرف خوانده:
            </FaTypography>
            <Box
              display={"grid"}
              gridTemplateColumns={"1fr 1fr 1fr 50px"}
              gap={2}
              justifyContent={"center"}
              alignItems={"center"}
            >
              <FaTextField
                label="نام"
                variant="outlined"
                sx={{
                  gridColumn: "span 1",
                }}
                value={tempPeopleFromAccused?.name}
                onChange={(e) => {
                  SetTempPeopleFromAccused({
                    ...tempPeopleFromAccused,
                    name: e.target.value,
                  });
                }}
              />
              <FaTextField
                label="تلفن"
                variant="outlined"
                sx={{
                  gridColumn: "span 1",
                }}
                value={tempPeopleFromAccused?.phoneNumber}
                onChange={(e) => {
                  SetTempPeopleFromAccused({
                    ...tempPeopleFromAccused,
                    phoneNumber: e.target.value,
                  });
                }}
              />
              <FaTextField
                label="سمت"
                variant="outlined"
                sx={{
                  gridColumn: "span 1",
                }}
                value={tempPeopleFromAccused?.position}
                onChange={(e) => {
                  SetTempPeopleFromAccused({
                    ...tempPeopleFromAccused,
                    position: e.target.value,
                  });
                }}
              />
              <IconButton
                sx={{
                  alignSelf: "center",
                  aspectRatio: "1/1",
                }}
                onClick={() => {
                  setRelatedPeopleByAccussed([
                    ...RelatedPeopleByAccussed,
                    {
                      name: tempPeopleFromAccused?.name,
                      phone: tempPeopleFromAccused?.phoneNumber,
                      position: tempPeopleFromAccused?.position,
                    },
                  ]);
                  SetTempPeopleFromAccused({});
                }}
              >
                <Add />
              </IconButton>
              {RelatedPeopleByAccussed.map((person) => (
                <>
                  <Typography>{person.name}</Typography>
                  <Typography>{person.phone}</Typography>
                  <Typography>{person.position}</Typography>
                  <IconButton
                    sx={{
                      alignSelf: "center",
                      aspectRatio: "1/1",
                    }}
                    onClick={() => {
                      setRelatedPeopleByAccussed(
                        RelatedPeopleByAccussed.filter(
                          (item) => item.name !== person.name
                        )
                      );
                      SetTempPeopleFromAccuser({});
                    }}
                  >
                    <CancelRounded />
                  </IconButton>
                </>
              ))}
            </Box>
          </Box>
          {/* 
      <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4- مشخصات قرارداد

  
  */}

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            مشخصات قرارداد
          </FaTypography>
          <FaTypography
            variant="h6"
            gridColumn={"span 12"}
            textAlign={"justify"}
          >
            {
              "در این قسمت لازم است انواع قرارداد همسان سازمان برنامه و بودجه کشور که مورد استفاده قرار گرفته است، انتخاب شود:"
            }
          </FaTypography>
          <TextField
            onChange={(e) => {
              setContratDetails({
                ...contratDetails,
                contratTypes: [e.target.value],
              });
            }}
            select
            label={"نوع قرارداد"}
            sx={{
              gridColumn: "span 12",
              display: contratDetails.other ? "none" : "grid",
            }}
            SelectProps={{
              MenuProps: {
                sx: {
                  maxHeight: "20rem",
                },
              },
            }}
          >
            {contract_details_items.map((item, index) => (
              <MenuItem key={index} value={item.title}>
                {item.title}
              </MenuItem>
            ))}
          </TextField>
          {contract_details_items.find(
            (item) => item.title === contratDetails.contratTypes?.[0]
          )?.children && (
            <TextField
              label={"نوع قرارداد"}
              onChange={(e) => {
                setContratDetails({
                  ...contratDetails,
                  // @ts-ignore
                  contratTypes: [
                    ...contratDetails.contratTypes,
                    e.target.value,
                  ],
                });
              }}
              select
              sx={{
                gridColumn: "span 12",
                display: contratDetails.other ? "none" : "grid",
              }}
              SelectProps={{
                MenuProps: {
                  sx: {
                    maxHeight: "20rem",
                  },
                },
              }}
            >
              {contract_details_items
                .find((item) => item.title === contratDetails.contratTypes?.[0])
                ?.children?.map((item, index) => (
                  <MenuItem key={index} value={item.title}>
                    {item.title}
                  </MenuItem>
                ))}
            </TextField>
          )}
          <FormGroup
            sx={{
              gridColumn: "span 12",
              gap: "1rem",
            }}
          >
            <FormControlLabel
              control={<Checkbox />}
              label="   سایر "
              onChange={(e) => {
                // @ts-ignore
                setContratDetails({
                  ...contratDetails,
                  contratTypes: [""],
                  // @ts-ignore
                  other: e.target.checked,
                });
              }}
            />
          </FormGroup>
          <FaTextField
            label={"عنوان"}
            variant={"outlined"}
            sx={{
              gridColumn: "span 2",
              display:
                contratDetails && contratDetails.other ? "block" : "none",
            }}
            value={contratDetails && contratDetails.CircularTitle}
            onChange={(e) => {
              // @ts-ignore
              setContratDetails({
                ...contratDetails,
                CircularTitle: e.target.value,
              });
            }}
            error={contratDetailsError.error}
            helperText={contratDetailsError.text}
          />
          <FaTextField
            label={"شماره مجوز"}
            variant={"outlined"}
            sx={{
              gridColumn: "span 2",
              display:
                contratDetails && contratDetails.other ? "block" : "none",
            }}
            value={contratDetails && contratDetails.CircularNumber}
            onChange={(e) => {
              // @ts-ignore
              setContratDetails({
                ...contratDetails,
                CircularNumber: e.target.value,
              });
            }}
            error={contratDetailsError.error}
            helperText={contratDetailsError.text}
          />
          <DateButton
            date={contratDetails && contratDetails.CircularDate}
            setDate={(date) => {
              //@ts-ignore
              setContratDetails((prevState) => ({
                ...prevState,
                CircularDate: date,
              }));
            }}
            sx={{
              gridColumn: "span 2",
              display:
                contratDetails && contratDetails.other ? "block" : "none",
            }}
            label={"تاریخ مجوز"}
          />
          <div
            style={{
              gridColumn: "span 12",
            }}
          />

          {/* 


    4-1- موضوع قرارداد

  
  */}
          {/* <FaTypography variant="h5" gridColumn={"span 1"}>
        4-1-
      </FaTypography>

      <div
        style={{
          gridColumn: "span 12",
        }}
      />
      <Divider
        sx={{
          gridColumn: "span 6",
        }}
      />
      <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4-2

  
  */}
          {/* <FaTypography variant="h6" gridColumn={"span 12"}>
        4-2- قرارداد شماره و تاريخ:
      </FaTypography>
      <div
        style={{
          gridColumn: "span 12",
        }}
      />
      <Divider
        sx={{
          gridColumn: "span 6",
        }}
      />
      <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}
          {/* 


    4-3

  
  */}
          {/* <FaTypography variant="h6" gridColumn={"span 1"}>
        4-3-
      </FaTypography>

      <div
        style={{
          gridColumn: "span 12",
        }}
      />
      <Divider
        sx={{
          gridColumn: "span 6",
        }}
      />
      <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4-4

  
  */}
          {/* <FaTypography variant="h6" gridColumn={"span 1"}>
        4-4-
      </FaTypography>

      <div
        style={{
          gridColumn: "span 12",
        }}
      />
      <Divider
        sx={{
          gridColumn: "span 6",
        }}
      />
      <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4-5- فهرست‌هاي پايه منضم به پيمان و سال انتشار

  
  */}

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            فهرست‌هاي پايه منضم به پيمان و سال انتشار
          </FaTypography>

          {/* 


    4-5-1- فهرست بهاي واحد پايه رشته

  
  */}

          {PriceListOfBasicUnitOfField &&
            PriceListOfBasicUnitOfField.map((item, index) => (
              <Box
                key={index}
                gridColumn={{
                  xs: "span 12",
                  lg: "span 12",
                }}
                display={"grid"}
                gridTemplateColumns={"repeat(12,1fr)"}
              >
                <Box
                  gridColumn={{
                    xs: "span 12",
                    lg: "span 12",
                  }}
                  display={"grid"}
                  gridTemplateColumns={"repeat(2,1fr)"}
                  columnGap={"2rem"}
                  padding={"0rem 2rem"}
                  justifyContent={"center"}
                  alignItems={"center"}
                >
                  <FaTextField
                    label="سال"
                    variant="outlined"
                    autoComplete="name"
                    type="text"
                    sx={{
                      gridColumn: "span 1",
                    }}
                    value={item.year}
                    onChange={(e) => {
                      const newPeoples = [...PriceListOfBasicUnitOfField] as [
                        {
                          year: string;
                          price: string;
                        }
                      ];
                      newPeoples[index].year = e.target.value;
                      setPriceListOfBasicUnitOfField(newPeoples);
                      console.log(PriceListOfBasicUnitOfField);
                    }}
                    // select
                    // SelectProps={{
                    //   MenuProps: {
                    //     sx: {
                    //       maxHeight: "20rem",
                    //     },
                    //   },
                    // }}
                  >
                    {/* {[
                      "1370",
                      "1371",
                      "1372",
                      "1373",
                      "1374",
                      "1375",
                      "1376",
                      "1377",
                      "1378",
                      "1379",
                      "1380",
                      "1381",
                      "1382",
                      "1383",
                      "1384",
                      "1385",
                      "1386",
                      "1387",
                      "1388",
                      "1389",
                      "1390",
                      "1391",
                      "1392",
                      "1393",
                      "1394",
                      "1395",
                      "1396",
                      "1397",
                      "1398",
                      "1399",
                      "1400",
                      "1401",
                      "1402",
                      "1403",
                    ].map((y) => (
                      <MenuItem value={y}>{y}</MenuItem>
                    ))} */}
                  </FaTextField>
                  <TextField
                    label="فهرست بهاي واحد پايه رشته"
                    variant="outlined"
                    type="number"
                    autoComplete="phone"
                    sx={{
                      gridColumn: "span 1",
                    }}
                    value={item.price}
                    onChange={(e) => {
                      const newPeoples = [...PriceListOfBasicUnitOfField] as [
                        {
                          year: string;
                          price: string;
                        }
                      ];
                      newPeoples[index].price = e.target.value;
                      setPriceListOfBasicUnitOfField(newPeoples);
                      console.log(PriceListOfBasicUnitOfField);
                    }}
                    select
                    SelectProps={{
                      MenuProps: {
                        sx: {
                          maxHeight: "20rem",
                        },
                      },
                    }}
                  >
                    {fehrestbaha.map((item, index) => (
                      <MenuItem key={index} value={item}>
                        {item}
                      </MenuItem>
                    ))}
                  </TextField>
                </Box>
              </Box>
            ))}

          <IconButton
            sx={{
              gridColumn: "span 12",
              justifySelf: "center",
              backgroundColor: primary,
              color: "white",
              "&:hover": {
                backgroundColor: GreenLight,
                color: secondaryDark,
              },
              margin: "0rem 2rem",
            }}
            onClick={() => {
              // @ts-ignore
              setPriceListOfBasicUnitOfField([
                ...(PriceListOfBasicUnitOfField || []),
                {
                  year: "",
                  price: "",
                },
              ] as { year: string; price: string }[]);
            }}
          >
            <Add />
          </IconButton>

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          {/* <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4-6- فهرست بهاي خاص (غيرپايه) منضم به پيمان

  
  */}
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            فهرست بهاي خاص (غيرپايه) منضم به پيمان:
          </FaTypography>

          <RadioGroup
            defaultValue={IsSpecialPriceListAttachedToContract}
            name="radio-buttons-group"
            row
            sx={{
              gridColumn: "span 12",
              justifyContent: "center",
            }}
          >
            <FormControlLabel
              value={true}
              control={<Radio />}
              label="دارد"
              defaultChecked
              checked={IsSpecialPriceListAttachedToContract === "دارد"}
              onChange={() => {
                // @ts-ignore
                setIsSpecialPriceListAttachedToContract("دارد");
              }}
            />
            <FormControlLabel
              value={false}
              control={<Radio />}
              label="ندارد"
              checked={IsSpecialPriceListAttachedToContract === "ندارد"}
              onChange={() => {
                // @ts-ignore
                setIsSpecialPriceListAttachedToContract("ندارد");
              }}
            />
          </RadioGroup>

          <div
            style={{
              gridColumn: "span 12",
            }}
          />

          {/* 

          TODO :
          add use state to this shit


*/}
          <FaTextField
            label={"عنوان"}
            variant={"outlined"}
            fullWidth
            sx={{
              gridColumn: "span 4",
              display:
                IsSpecialPriceListAttachedToContract === "دارد"
                  ? "block"
                  : "none",
            }}
            value={contratDetails && contratDetails.CircularTitle}
            onChange={(e) => {
              setContratDetails((prevState) => {
                if (!prevState) return prevState;
                return {
                  ...prevState,
                  CircularTitle: e.target.value,
                };
              });
            }}
            error={contratDetailsError.error}
            helperText={contratDetailsError.text}
          />
          <FaTextField
            label={"شماره مجوز"}
            variant={"outlined"}
            fullWidth
            sx={{
              gridColumn: "span 4",
              display:
                IsSpecialPriceListAttachedToContract === "دارد"
                  ? "block"
                  : "none",
            }}
            value={contratDetails?.CircularNumber || ""}
            onChange={(e) => {
              setContratDetails((prevState) => {
                if (!prevState) return prevState;
                return {
                  ...prevState,
                  CircularNumber: e.target.value,
                  contratTypes: prevState.contratTypes || [],
                  other: prevState.other || false,
                  CircularTitle: prevState.CircularTitle || "",
                  CircularDate: prevState.CircularDate
                    ? new Date(prevState.CircularDate)
                    : new Date(),
                };
              });
            }}
            error={contratDetailsError.error}
            helperText={contratDetailsError.text}
          />
          <DateButton
            date={contratDetails && contratDetails.CircularDate}
            setDate={(date) => {
              //@ts-ignore
              setContratDetails((prevState) => ({
                ...prevState,
                CircularDate: date,
              }));
            }}
            sx={{
              gridColumn: "span 4",
              display:
                IsSpecialPriceListAttachedToContract === "دارد"
                  ? "block"
                  : "none",
            }}
            label={"تاریخ مجوز"}
          />

          {/* 

          TODO :
          add use state to this shit

    */}

          {/* <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}
          {/* <Divider
        sx={{
          gridColumn: "span 6",
        }}
      /> */}
          {/* <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4-7- "ضريب پيشنهادي

  
  */}

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          <FaTypography variant="h5" gridColumn={"span 3"} textAlign={"center"}>
            ضريب پيشنهادی
          </FaTypography>

          <TextField
            label="ضريب پيشنهادي: "
            sx={{
              gridColumn: "span 6",
            }}
            type="number"
            value={RecommendedCoefficient}
            onChange={(e) => {
              setRecommendedCoefficient(parseFloat(e.target.value));
            }}
          />

          <FaTypography variant="h6" gridColumn={"span 4"}>
            {RecommendedCoefficient
              ? RecommendedCoefficient > 1
                ? (RecommendedCoefficient * 100 - 100).toPrecision(2) + "% پلوس"
                : (100 - RecommendedCoefficient * 100).toPrecision(2) +
                  "% مینوس"
              : ""}
          </FaTypography>
          {/* <RadioGroup defaultValue={CoefficientType} row>
      <FormControlLabel
        value="درصدپلوس"
        control={<Radio />}
        label="درصدپلوس"
        defaultChecked
        checked={CoefficientType === "درصدپلوس"}
        onChange={(e) => {
          // @ts-ignore
          setCoefficientType(e.target.value);
        }}
      />
      <FormControlLabel
        value="مينوس"
        control={<Radio />}
        label="مينوس"
        checked={CoefficientType === "مينوس"}
        onChange={(e) => {
          // @ts-ignore
          setCoefficientType(e.target.value);
        }}
      />
    </RadioGroup> */}
          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />

          {/* 


    4-8- نحوه واگذاري كار

  
  */}

          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            نحوه واگذاري كار
          </FaTypography>

          <FormControl
            sx={{
              gridColumn: "span 12",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {/* <FormLabel id="demo-row-radio-buttons-group-label">
          نحوه واگذاري كار
        </FormLabel> */}
            <RadioGroup
              row
              aria-labelledby="demo-row-radio-buttons-group-label"
              name="row-radio-buttons-group"
            >
              <FormControlLabel
                value="مناقصه عمومی"
                checked={AssigningType === "مناقصه عمومی"}
                control={<Radio />}
                label="مناقصه عمومی"
                onChange={(e) => {
                  // @ts-ignore
                  setAssigningType(e.target.value);
                }}
              />
              <FormControlLabel
                value="مناقصه محدود"
                checked={AssigningType === "مناقصه محدود"}
                control={<Radio />}
                label="مناقصه محدود"
                onChange={(e) => {
                  // @ts-ignore
                  setAssigningType(e.target.value);
                }}
              />
              <FormControlLabel
                value="ترك مناقصه"
                checked={AssigningType === "ترك مناقصه"}
                control={<Radio />}
                label="ترك مناقصه  "
                onChange={(e) => {
                  // @ts-ignore
                  setAssigningType(e.target.value);
                }}
              />
              <FormControlLabel
                value="سایر"
                checked={AssigningType === "سایر"}
                control={<Radio />}
                label="سایر"
                onChange={(e) => {
                  // @ts-ignore
                  setAssigningType(e.target.value);
                }}
              />
              <FormControlLabel
                control={
                  <FaTextField
                    label="سایر"
                    disabled={AssigningType !== "سایر"}
                  />
                }
                label=""
              />
            </RadioGroup>
          </FormControl>

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          {/* <Divider
        sx={{
          gridColumn: "span 6",
        }}
      />
      <div
        style={{
          gridColumn: "span 12",
        }}
      /> */}

          {/* 


    4-9- پيمان مشمول تعديل

  
  */}

          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            پيمان مشمول تعديل
          </FaTypography>
          <FormControl
            sx={{
              gridColumn: "span 12",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {/* <FormLabel id="demo-row-radio-buttons-group-label">
          پيمان مشمول تعديل
        </FormLabel> */}
            <RadioGroup row>
              <FormControlLabel
                value={true}
                control={<Radio />}
                label="مي‌باشد"
                checked={DoesContainAdjustment}
                onChange={() => {
                  // @ts-ignore
                  setDoesContainAdjustment(true);
                }}
              />
              <FormControlLabel
                value={false}
                control={<Radio />}
                label="نمي‌باشد"
                checked={!DoesContainAdjustment}
                onChange={() => {
                  // @ts-ignore
                  setDoesContainAdjustment(false);
                }}
              />
            </RadioGroup>
          </FormControl>

          <div
            style={{
              gridColumn: "span 12",
            }}
          />

          <FaTextField
            label="شماره"
            type="number"
            sx={{
              gridColumn: "span 6",
              display: DoesContainAdjustment ? "block" : "none",
            }}
            value={Adjustment && Adjustment.number}
            onChange={(e) => {
              setAdjustment((prevAdjustment) => ({
                ...prevAdjustment,
                number: parseInt(e.target.value),
                date: prevAdjustment?.date || new Date(),
              }));
            }}
            fullWidth
            error={AdjustmentError.error}
            helperText={AdjustmentError.text}
          />

          <DateButton
            date={Adjustment && Adjustment.date}
            setDate={(date) => {
              setAdjustment(
                (prevAdjustment) =>
                  ({
                    ...prevAdjustment,
                    date: date,
                    number: date ? prevAdjustment?.number || 0 : undefined,
                  } as unknown as { number: number; date: Date } | undefined)
              );
            }}
            sx={{
              gridColumn: "span 6",
              display: DoesContainAdjustment ? "block" : "none",
            }}
            label="تاریخ"
          />
          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />

          {/* 


    4-10- دوره شاخص مبنا

  
  */}
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            دوره شاخص مبنا
          </FaTypography>

          <FormControl
            sx={{
              gridColumn: "span 12",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <FormLabel id="demo-row-radio-buttons-group-label">
              نوع دوره شاخص مبنا
            </FormLabel>
            <RadioGroup row>
              <FormControlLabel
                value={true}
                control={<Radio />}
                label="سه ماهه"
                checked={BaseIndexPeriod && BaseIndexPeriod.isQuarter}
                onChange={() => {
                  setBaseIndexPeriod((prevBaseIndexPeriod) => ({
                    ...prevBaseIndexPeriod,
                    isQuarter: true,
                    quarter: prevBaseIndexPeriod?.quarter || "",
                    month: "",
                    year: "",
                  }));
                }}
              />
              <FormControlLabel
                value={false}
                control={<Radio />}
                label="ماهانه"
                checked={BaseIndexPeriod && !BaseIndexPeriod.isQuarter}
                onChange={() => {
                  setBaseIndexPeriod((prevBaseIndexPeriod) => ({
                    ...prevBaseIndexPeriod,
                    isQuarter: false,
                    quarter: prevBaseIndexPeriod?.quarter || "",
                    month: prevBaseIndexPeriod?.month || "",
                    year: prevBaseIndexPeriod?.year || "",
                  }));
                }}
              />
            </RadioGroup>
          </FormControl>

          <FaTextField
            label="ماه"
            type="number"
            sx={{
              gridColumn: "span 4",
              display:
                BaseIndexPeriod && !BaseIndexPeriod.isQuarter
                  ? "block"
                  : "none",
            }}
            value={BaseIndexPeriod && BaseIndexPeriod.month}
            onChange={(e) => {
              setBaseIndexPeriod((prevBaseIndexPeriod) => ({
                ...prevBaseIndexPeriod,
                month: e.target.value,
                isQuarter: prevBaseIndexPeriod?.isQuarter || false,
                quarter: prevBaseIndexPeriod?.quarter || "",
                year: prevBaseIndexPeriod?.year || "",
              }));
            }}
            error={BaseIndexPeriodError.error}
            helperText={BaseIndexPeriodError.text}
            select
            SelectProps={{
              MenuProps: {
                sx: {
                  maxHeight: "20rem",
                },
              },
            }}
            fullWidth
          >
            {[
              "فروردین",
              "اردیبهشت",
              "خرداد",
              "تیر",
              "مرداد",
              "شهریور",
              "مهر",
              "آبان",
              "آذر",
              "دی",
              "بهمن",
              "اسفند",
            ].map((m) => (
              <MenuItem value={m}>{m}</MenuItem>
            ))}
          </FaTextField>
          <FaTextField
            label="سه ماهه"
            sx={{
              gridColumn: "span 4",
              display:
                BaseIndexPeriod && BaseIndexPeriod.isQuarter ? "block" : "none",
            }}
            value={BaseIndexPeriod?.quarter || ""}
            onChange={(e) => {
              setBaseIndexPeriod((prevBaseIndexPeriod) => {
                if (!prevBaseIndexPeriod) return prevBaseIndexPeriod;
                return {
                  ...prevBaseIndexPeriod,
                  quarter: e.target.value,
                };
              });
            }}
            fullWidth
            error={BaseIndexPeriodError.error}
            helperText={BaseIndexPeriodError.text}
            select
            SelectProps={{
              MenuProps: {
                sx: {
                  maxHeight: "20rem",
                },
              },
            }}
          >
            <MenuItem value={"اول"}>اول</MenuItem>
            <MenuItem value={"دوم"}>دوم</MenuItem>
            <MenuItem value={"سوم"}>سوم</MenuItem>
            <MenuItem value={"چهارم"}>چهارم</MenuItem>
          </FaTextField>
          <FaTextField
            label="سال"
            type="number"
            sx={{
              gridColumn: "span 4",
            }}
            value={BaseIndexPeriod?.year || ""}
            onChange={(e) => {
              setBaseIndexPeriod((prevBaseIndexPeriod) => ({
                ...prevBaseIndexPeriod!,
                year: e.target.value,
              }));
            }}
            error={BaseIndexPeriodError.error}
            helperText={BaseIndexPeriodError.text}
            select
            SelectProps={{
              MenuProps: {
                sx: {
                  maxHeight: "20rem",
                },
              },
            }}
          >
            {[
              "1370",
              "1371",
              "1372",
              "1373",
              "1374",
              "1375",
              "1376",
              "1377",
              "1378",
              "1379",
              "1380",
              "1381",
              "1382",
              "1383",
              "1384",
              "1385",
              "1386",
              "1387",
              "1388",
              "1389",
              "1390",
              "1391",
              "1392",
              "1393",
              "1394",
              "1395",
              "1396",
              "1397",
              "1398",
              "1399",
              "1400",
              "1401",
              "1402",
              "1403",
            ].map((y) => (
              <MenuItem value={y}>{y}</MenuItem>
            ))}
          </FaTextField>

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />

          {/* 


    4-11- تاريخ شروع كار

  
  */}
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            تاريخ شروع كار
          </FaTypography>

          <div
            style={{
              gridColumn: "span 4",
            }}
          />

          <DateButton
            date={OperationStartDate}
            setDate={setOperationStartDate}
            sx={{
              gridColumn: "span 4",
            }}
            label="تاريخ شروع كار "
          />
          {/* 


    4-12- پيشرفت فيزيكي كار در تاريخ درخواست داوري

  
  */}
          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          <FaTypography variant="h6" gridColumn={"span 6"} textAlign={"center"}>
            پيشرفت فيزيكي كار در تاريخ درخواست داوري
          </FaTypography>

          {/* <div
        style={{
          gridColumn: "span 4",
        }}
      /> */}

          <FaTextField
            label="خواهان"
            type="number"
            InputProps={{
              endAdornment: "درصد",
            }}
            sx={{
              gridColumn: "span 6",
            }}
            value={PhysicalProgressInArbitrationDate}
            onChange={(e) => {
              setPhysicalProgressInArbitrationDate(parseInt(e.target.value));
            }}
            error={PhysicalProgressInArbitrationDateError.error}
            helperText={PhysicalProgressInArbitrationDateError.text}
          />
          {/* 


    4-13- پيشرفت ریالی كار در تاريخ درخواست داوري

  
  */}
          <FaTypography variant="h6" gridColumn={"span 6"} textAlign={"center"}>
            پيشرفت ریالی كار در تاريخ درخواست داوري:
          </FaTypography>

          {/* <div
        style={{
          gridColumn: "span 4",
        }}
      /> */}

          <FaTextField
            label="خواهان"
            type="number"
            InputProps={{
              endAdornment: "درصد",
            }}
            sx={{
              gridColumn: "span 6",
            }}
            value={FinancialProgressInArbitrationDateAccuser}
            onChange={(e) => {
              setFinancialProgressInArbitrationDateAccuser(
                parseInt(e.target.value)
              );
            }}
            error={FinancialProgressInArbitrationDateAccuserError.error}
            helperText={FinancialProgressInArbitrationDateAccuserError.text}
          />

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />

          {/* 


    4-14- وضعیت قرارداد در تاریخ درخواست داوری

  
  */}
          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            وضعیت قرارداد در تاریخ درخواست داوری
          </FaTypography>

          <FormControl
            sx={{
              gridColumn: "span 12",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <RadioGroup
              row
              // aria-labelledby="demo-row-radio-buttons-group-label"
              // name="row-radio-buttons-group"
            >
              <FormControlLabel
                value="ابلاغ خاتمه"
                control={<Radio />}
                label="ابلاغ خاتمه"
                checked={ContractStatusInArbitration.title === "ابلاغ خاتمه"}
                onChange={(e) => {
                  setContractStatusInArbitration({
                    ...ContractStatusInArbitration,
                    title: "ابلاغ خاتمه",
                  });
                }}
              />
              <FormControlLabel
                value="ابلاغ فسخ"
                control={<Radio />}
                label="ابلاغ فسخ"
                checked={ContractStatusInArbitration.title === "ابلاغ فسخ"}
                onChange={(e) => {
                  setContractStatusInArbitration({
                    ...ContractStatusInArbitration,
                    title: "ابلاغ فسخ",
                  });
                }}
              />
              <FormControlLabel
                value="جاری"
                control={<Radio />}
                label="جاری"
                checked={ContractStatusInArbitration.title === "جاری"}
                onChange={(e) => {
                  setContractStatusInArbitration({
                    ...ContractStatusInArbitration,
                    title: "جاری",
                  });
                }}
              />

              {/* <FormControlLabel
          control={
            <FaTextField label={"تاریخ"} type="date" focused />
          }
          label=""
          value={ContractStatusInArbitrationDate}
          onChange={(e) => {
            // @ts-ignore
            setContractStatusInArbitrationDate(e.target.value);
          }}
        /> */}
            </RadioGroup>
          </FormControl>

          <FormGroup
            sx={{
              display:
                ContractStatusInArbitration.title === "ابلاغ فسخ" ||
                ContractStatusInArbitration.title === "ابلاغ خاتمه"
                  ? undefined
                  : "none",
              gridColumn: "span 12",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <FormControlLabel
              control={<Checkbox />}
              label="تحویل موقت"
              value={TemporaryDelivery?.checked}
              onChange={(e) => {
                // @ts-ignore
                setTemporaryDelivery({
                  ...TemporaryDelivery,
                  // @ts-ignore
                  checked: e.target.checked,
                });
              }}
            />
            <FormControlLabel
              control={<Checkbox />}
              label="تحویل قطعی"
              onChange={(e) => {
                // @ts-ignore
                setFinalDelivery({
                  ...FinalDelivery,
                  // @ts-ignore
                  checked: e.target.checked,
                });
              }}
              value={FinalDelivery?.checked}
            />
          </FormGroup>

          <DatePicker
            value={ContractStatusInArbitration?.temp}
            onChange={(date) => {
              setContractStatusInArbitration({
                ...ContractStatusInArbitration,
                temp: date,
              });
            }}
            label="تاریخ تحویل موقت"
            sx={{
              gridColumn: "span 6",
              display: TemporaryDelivery?.checked ? "block" : "none",
            }}
          />
          <DatePicker
            value={ContractStatusInArbitration?.final}
            onChange={(date) => {
              setContractStatusInArbitration({
                ...ContractStatusInArbitration,
                final: date,
              });
            }}
            label="تاریخ تحویل قطعی"
            sx={{
              gridColumn: "span 6",
              display: FinalDelivery?.checked ? "block" : "none",
            }}
          />

          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />

          {/* 


    4-15- دستگاه نظارت (مهندس مشاور) 

  
  */}

          <FaTypography
            variant="h5"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            دستگاه نظارت (مهندس مشاور)
          </FaTypography>

          <FaTextField
            label={"دستگاه نظارت (مهندس مشاور) :"}
            sx={{
              gridColumn: "span 12",
            }}
            value={SupervisionDepartment}
            onChange={(e) => {
              setSupervisionDepartment(e.target.value);
            }}
            error={SupervisionDepartmentError.error}
            helperText={SupervisionDepartmentError.text}
          />
          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          {/* 


    4-16- تاخیرات

  
  */}
          <FaTypography
            variant="h6"
            gridColumn={"span 12"}
            textAlign={"center"}
          >
            تاخیرات
          </FaTypography>
          <FaTypography
            variant="body1"
            gridColumn={"span 2"}
            textAlign={"center"}
          >
            مجاز
          </FaTypography>
          <FaTextField
            label={"از نظر خواهان:"}
            sx={{
              gridColumn: "span 4",
            }}
            InputProps={{
              endAdornment: "روز",
            }}
            value={AuthorizedDelays}
            type="number"
            onChange={(e) => {
              setAuthorizedDelays(parseInt(e.target.value));
            }}
            error={AuthorizedDelaysError.error}
            helperText={AuthorizedDelaysError.text}
          />
          <FaTypography
            variant="body1"
            gridColumn={"span 2"}
            textAlign={"center"}
          >
            غیر مجاز
          </FaTypography>
          <FaTextField
            label={"از نظر خواهان:"}
            sx={{
              gridColumn: "span 4",
            }}
            InputProps={{
              endAdornment: "روز",
            }}
            value={UnauthorizedDelays}
            type="number"
            onChange={(e) => {
              setUnauthorizedDelays(parseInt(e.target.value));
            }}
            error={UnauthorizedDelaysError.error}
            helperText={UnauthorizedDelaysError.text}
          />
          <Divider
            sx={{
              gridColumn: "span 12",
            }}
          />
          {/* 


    توجهات

  
  */}
          <FaTypography variant="h5" fontWeight={800} gridColumn={"span 12"}>
            توجه مهم: چنانچه در خصوص تاخیرات و یا تبعات ناشی از آن اختلافی وجود
            دارد، لازم است موارد زیر ارسال شوند:
          </FaTypography>
          <FaTypography variant="h6" fontWeight={800} gridColumn={"span 12"}>
            گزارش توجیهی تاخیرات قرارداد شامل:
          </FaTypography>
          <List
            sx={{
              gridColumn: "span 6",
            }}
          >
            <Box
              display={"flex"}
              justifyContent={"space-between"}
              paddingY={"1rem"}
            >
              <FaTypography variant="body1">
                برنامه های زمان‏بندی اولیه و اصلاحی ابلاغ شده
              </FaTypography>
              <FileBox fileTypes={["pdf", "jpeg"]} />
            </Box>
            <Box
              display={"flex"}
              justifyContent={"space-between"}
              paddingY={"1rem"}
            >
              <FaTypography variant="body1">
                گزارش تهیه شده توسط پیمانکار (به همراه کلیه مستندات و پیوست‏ها)
              </FaTypography>
              <FileBox fileTypes={["pdf", "jpeg"]} />
            </Box>
            <Box
              display={"flex"}
              justifyContent={"space-between"}
              paddingY={"1rem"}
            >
              <FaTypography variant="body1">
                گزارش رسیدگی به تاخیرات توسط مهندس مشاور
              </FaTypography>
              <FileBox fileTypes={["pdf", "jpeg"]} />
            </Box>
            <Box
              display={"flex"}
              justifyContent={"space-between"}
              paddingY={"1rem"}
            >
              <FaTypography variant="body1">
                مستندات ابلاغ نتایج رسیدگی به تاخیرات به پیمانکار توسط کارفرما
              </FaTypography>
              <FileBox fileTypes={["pdf", "jpeg"]} />
            </Box>
          </List>

          <div
            style={{
              gridColumn: "span 12",
            }}
          />
          <div
            style={{
              gridColumn: "span 6",
            }}
          />
          <Button
            variant="contained"
            //   disabled={loading}
            sx={{
              gridColumn: "span 6",
              fontSize: "1.1rem",
              width: "max-content",
              padding: "0.5rem 2rem",
              justifySelf: "flex-end",
              background: primary,
              color: secondaryDark,
              boxShadow: "none",
              borderRadius: 3,
              "&:hover": {
                backgroundColor: GreenLight,
                color: secondaryDark,
                boxShadow: "none",
              },
            }}
            disabled={data?.contract_addContract?.result}
            onClick={() => {
              if (handleErrors()) {
                void createContractMutation({
                  variables: {
                    AccuserRelatedPeople: JSON.stringify(
                      RelatedPeopleByAccusser
                    ),
                    AccusedRelatedPeople: JSON.stringify(
                      RelatedPeopleByAccussed
                    ),
                    AccuserNationality: Nationality,
                    ContractType: contratDetails.contratTypes,
                    CircularNumber: contratDetails.CircularNumber,
                    CircularDate: contratDetails.CircularDate,
                    ContractSubject: ContractSubject,
                    // ContractNumber: ContractNumber,
                    ContractDate: ContractDate,
                    InitialBudget: InitialBudget,
                    InitialTimePeriod: InitialTimePeriod,
                    PriceListOfBasicUnitOfField: JSON.stringify(
                      PriceListOfBasicUnitOfField
                    ),
                    IsSpecialPriceListAttachedToContract: String(
                      IsSpecialPriceListAttachedToContract
                    ),
                    RecommendedCoefficient: RecommendedCoefficient,
                    CoefficientType:
                      RecommendedCoefficient && RecommendedCoefficient > 1
                        ? "پلوس"
                        : "مینوس",
                    AssigningType: AssigningType,
                    DoesContainAdjustment: String(DoesContainAdjustment),
                    BaseIndexPeriod: JSON.stringify(BaseIndexPeriod),
                    OperationStartDateAccuser: OperationStartDateAccuser,
                    PhysicalProgressInArbitrationDateAccuser:
                      PhysicalProgressInArbitrationDate,
                    FinancialProgressInArbitrationDateAccuser:
                      FinancialProgressInArbitrationDateAccuser,
                    ContractStatusInArbitration: JSON.stringify(
                      ContractStatusInArbitration
                    ),
                    SupervisionDepartment: SupervisionDepartment,
                    AuthorizedDelaysAccuser: AuthorizedDelays,
                    UnauthorizedDelaysAccuser: UnauthorizedDelays || undefined,
                    id: contractId ? parseInt(contractId) : 0,
                    Currency: Currency,
                  },
                  onCompleted(data, clientOptions) {
                    alert("قرارداد با موفقیت ثبت شد");
                  },
                  onError(error, clientOptions) {
                    console.log(clientOptions);
                    console.error(error);
                  },
                });
              } else {
                void createContractMutation({
                  variables: {
                    AccuserRelatedPeople: JSON.stringify(
                      RelatedPeopleByAccusser
                    ),
                    AccusedRelatedPeople: JSON.stringify(
                      RelatedPeopleByAccussed
                    ),
                    AccuserNationality: Nationality,
                    ContractType: contratDetails.contratTypes,
                    CircularNumber: contratDetails.CircularNumber,
                    CircularDate: contratDetails.CircularDate,
                    ContractSubject: ContractSubject,
                    // ContractNumber: ContractNumber,
                    ContractDate: ContractDate,
                    InitialBudget: InitialBudget,
                    InitialTimePeriod: InitialTimePeriod,
                    PriceListOfBasicUnitOfField: JSON.stringify(
                      PriceListOfBasicUnitOfField
                    ),
                    IsSpecialPriceListAttachedToContract: String(
                      IsSpecialPriceListAttachedToContract
                    ),
                    RecommendedCoefficient: RecommendedCoefficient,
                    CoefficientType:
                      RecommendedCoefficient && RecommendedCoefficient > 1
                        ? "پلوس"
                        : "مینوس",
                    AssigningType: AssigningType,
                    DoesContainAdjustment: String(DoesContainAdjustment),
                    BaseIndexPeriod: JSON.stringify(BaseIndexPeriod),
                    OperationStartDateAccuser: OperationStartDateAccuser,
                    PhysicalProgressInArbitrationDateAccuser:
                      PhysicalProgressInArbitrationDate,
                    FinancialProgressInArbitrationDateAccuser:
                      FinancialProgressInArbitrationDateAccuser,
                    ContractStatusInArbitration: JSON.stringify(
                      ContractStatusInArbitration
                    ),
                    SupervisionDepartment: SupervisionDepartment,
                    AuthorizedDelaysAccuser: AuthorizedDelays,
                    UnauthorizedDelaysAccuser: UnauthorizedDelays || undefined,
                    id: contractId ? parseInt(contractId) : 0,
                    Currency: Currency,
                  },
                  onCompleted(data, clientOptions) {
                    console.log(data);
                    alert("قرارداد با موفقیت تکمیل شد");
                  },
                  onError(error, clientOptions) {
                    console.log(clientOptions);
                    console.error(error);
                  },
                });
                // navigate("/complaints/addComplaint");
              }
            }}
          >
            ثبت و ادامه
          </Button>

          {data?.contract_updateContract?.result && (
            <Alert
              severity="success"
              sx={{
                gridColumn: "span 6",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <Typography>قرارداد با موفقیت تکمیل شد</Typography>

              <Button
                onClick={() => {
                  void updateCompaint();
                }}
              >
                ادامه و تکمیل درخواست داوری
              </Button>
            </Alert>
          )}
        </Box>
      </Box>
    </>
  );
};

export default UpdateContractPage;
