/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import {
  useGetComplaintQuery,
  useGetComplaintStateTimelinesQuery,
  useGetContractLazyQuery,
} from "../../../../generated-types";
import { getComplaintStateWithId } from "../../../functions/ComplaintStatesFunc";
import DateTimeLineH from "../../../components/DateTimeLineH";
import { Divider, TableRow } from "@mui/material";
import BackButton from "../../../components/BackButton";
import CTable from "../../../components/CustomTable/CTable";

const ComplaintTimeLinePage = () => {
  const [dates, setDates] = React.useState<
    | {
        date: string;
        title: string;
        description: string;
        color?: string;
      }[]
    | []
  >([]);
  const [page, setPage] = React.useState(1);
  const [take, setTake] = React.useState(10);
  const { complaintId } = useParams<{ complaintId: string }>();
  const complaintIdNumber = parseInt(complaintId || "0");

  const { data: stateData, refetch: stateRefetch } =
    useGetComplaintStateTimelinesQuery({
      variables: {
        complaintId: complaintIdNumber,
        skip: (page - 1) * take,
        take: take,
      },
    });

  const { data, refetch } = useGetComplaintQuery({
    variables: {
      id: complaintIdNumber,
    },
    onCompleted(data1) {
      void GetContract({
        onCompleted(data) {
          setDates([
            // {
            //   date: data1.complaint_getComplaint?.result?.createdDate || "",
            //   title: "تاریخ ثبت درخواست داوری",
            //   description: "درخواست داوری توسط خواهان ثبت شد",
            //   color: "#000",
            // },
            {
              date:
                data1.complaint_getComplaint?.result?.secondPaymentDate || "",
              title: "تاریخ پرداخت دوم",
              description: "پرداخت دوم توسط خواهان انجام شد",
              color: "#000",
            },
            {
              date:
                data.contract_getContracts?.result?.items?.[0]
                  ?.circularDateByAccuser || "",
              title: "تاریخ مصوبه قرارداد",
              description: "",
              color: "#000",
            },
            {
              date:
                data.contract_getContracts?.result?.items?.[0]
                  ?.contractDateByAccuser || "",
              title: "تاریخ امضای قرارداد",
              description: "",
              color: "#000",
            },
            {
              date:
                data.contract_getContracts?.result?.items?.[0]
                  ?.operationStartDateByAccuser || "",
              title: "تاریخ شروع عملیات",
              description: "",
              color: "#000",
            },
            {
              date:
                data.contract_getContracts?.result?.items?.[0]
                  ?.tempDeliveryDateByAccuser || "",
              title: "تاریخ تحویل موقت",
              description: "",
              color: "#000",
            },
            {
              date:
                data.contract_getContracts?.result?.items?.[0]
                  ?.finalDeliveryDateByAccuser || "",
              title: "تاریخ تحویل نهایی",
              description: "",
              color: "#000",
            },
          ]);
        },
      });
    },
  });

  useEffect(() => {
    void refetch();
    void stateRefetch();
  }, [complaintId]);

  const [GetContract] = useGetContractLazyQuery({
    variables: {
      id: data?.complaint_getComplaint?.result?.contractId || 0,
    },
  });

  return (
    <div className="flex flex-col gap-5 w-full">
      <div className="flex">
        <BackButton />
      </div>
      <h1 className="text-[1.5rem] font-bold">
        جدول زمانی قرارداد شماره{" "}
        {
          data?.complaint_getComplaint?.result?.contract
            ?.contractNumberByAccuser
        }
      </h1>

      <div className="flex flex-col gap-5 w-full">
        <DateTimeLineH dates={dates} sortType="asc" />
        <Divider className="w-full" />
        <h2>جدول زمانی درخواست داوری شماره {complaintId}</h2>
        {/* <DateTimeLineH
          dates={
            stateData?.complaintStateTimeLine_getComplaintStateTimelines?.result?.items?.map(
              (a) => ({
                date: a.createdDate,
                title: getComplaintStateWithId(a.stateId)?.persianName || "",
                description: "",
                color: "#000",
              })
            ) || []
          }
          sortType="asc"
          // showClock
        /> */}

        <CTable
          page={page}
          setPage={setPage}
          recordsPerPage={take}
          setRecordsPerPage={setTake}
          totalRecords={
            stateData?.complaintStateTimeLine_getComplaintStateTimelines?.result?.totalCount || 0
          }
          tableHeader={
            <TableRow
              sx={{
                th: {
                  padding: "10px",
                },
                "& td": {
                  padding: "10px",
                },
              }}
            >
              <td>نام مرحله</td>
              <td>شماره درخواست</td>
              <td>تاریخ</td>
              {/* <td>کد رهگیری</td> */}
            </TableRow>
          }
        >
          {stateData?.complaintStateTimeLine_getComplaintStateTimelines?.result?.items?.map((item) => (
            <TableRow
              sx={{
                borderRadius: "1rem",
                overflow: "hidden",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                "&:hover": {
                  backgroundColor: "rgba(100,150,150,0.4)",
                  cursor: "pointer",
                },
                "& td": {
                  padding: "10px",
                },
              }}
            >
              <td>{getComplaintStateWithId(item.stateId)?.persianName || ""}</td>
              <td>{item.complaintId}</td>
              <td>
                {new Date(item.createdDate).toLocaleDateString("fa-IR", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                  second: "2-digit",
                })}
              </td>
            </TableRow>
          ))}
        </CTable>
        {/* <DateTimeLine dates={dates} sortType="asc" alternate />
        <DateTimeLine
          dates={
            stateData?.complaintStateTimeLine_getComplaintStateTimelines?.result?.items?.map(
              (a) => ({
                date: a.createdDate,
                title: getComplaintStateWithId(a.stateId)?.persianName || "",
                description: "",
                color: "#000",
              })
            ) || []
          }
          sortType="asc"
          alternate
        /> */}
      </div>
    </div>
  );
};

export default ComplaintTimeLinePage;
