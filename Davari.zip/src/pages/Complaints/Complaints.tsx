/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import {
  Box,
  Button,
  Switch,
  Tab,
  TableCell,
  TableRow,
  Tabs,
  TextField,
  Tooltip,
} from "@mui/material";
import { useRef, useState } from "react";
import { AiFillFileAdd } from "react-icons/ai";
import { useNavigate } from "react-router-dom";
import { useGetPublicContractByNumberQuery, useGetPublicContractsLazyQuery } from "../../../generated-types";
import { useUserStore } from "../../Context/UserStore";
import ComplaintsList from "../../components/Complaints/ComplaintsList";
import NewComplaintList from "../../components/Complaints/NewComplaintList";
import CTable from "../../components/CustomTable/CTable";
import FaTextField from "../../components/FaComponents/FaTextField";
import NewModal from "../../components/Modals";
import { PublicContractSortInput, SortEnumType } from "../../gql/graphql";
import {
  GreenLight,
  background,
  primary,
  secondary,
  secondaryDark,
} from "../../theme/color";
import theme from "../../theme/theme";
import { BsGrid, BsList } from "react-icons/bs";
import { SwiperRef } from "swiper/react";

const Complaints = () => {
  const [addModal, setAddModal] = useState({
    open: false as boolean,
    contractId: 0 as number,
    search: "" as string,
    executorSearch: "" as string,
    idSearch: "" as string,
    titleSearch: "" as string,
    fullName: "" as string,
  });
  const [take, setTake] = useState<number>(15);
  const [page, setPage] = useState<number>(1);
  const [order, setOrder] = useState<PublicContractSortInput>({
    contractID: SortEnumType.Asc,
  });
  const [tab, setTab] = useState<number>(0);
  const scrollContainer = useRef<SwiperRef>(null);
  const [mode, setMode] = useState<"card" | "list">("card");
  const [sortMode, setSortMode] = useState<"ASC" | "DESC">("ASC");
  const navigate = useNavigate();

  const user = useUserStore((state) => state.user);

  // const [addComplaint] = useMutation(CREATE_COMPLAINT, {
  //   onCompleted(data, clientOptions) {
  //     console.log(data);
  //   },
  // });

  const [getPublicContract, { data: contracts, loading }] =
    useGetPublicContractsLazyQuery({
      fetchPolicy: "network-only",
      variables: {
        take: take,
        skip: (page - 1) * take,
        order: order,
        filter: {
          and: [
            {
              or: [
                { fullName: { contains: addModal.search } },
                { contractID: { contains: addModal.search } },
                { contractSubject: { contains: addModal.titleSearch } },
                { contractID: { contains: addModal.idSearch } },
                { executiveTitle: { contains: addModal.executorSearch } },
              ],
            },
            {
              nationalCode: { contains: user.nationalCode },
            },
          ],
        },
      },
    });

  return (
    <>
      <Box
        display={"flex"}
        justifyContent={"flex-start"}
        alignItems={"center"}
        paddingY={1}
        position={"relative"}
      >
        <Tooltip
          title={"نغییر نوع نمایش"}
          // slotProps={{
          //   tooltip:{
          //     sx:{
          //       background:'white',
          //       color:"black",
          //       boxShadow:theme.shadows[1],
          //       padding:2
          //     }
          //   }
          // }}
        >
          <div className="flex gap-2 items-center">
            <BsGrid />
            <Switch
              checked={mode === "list"}
              onChange={(e) => {
                setMode(e.target.checked ? "list" : "card");
              }}
            />
            <BsList />
          </div>
        </Tooltip>
        <Button
          variant="contained"
          endIcon={<AiFillFileAdd />}
          onClick={() => {
            void getPublicContract();
            setAddModal({ ...addModal, open: true });
          }}
          sx={{
            borderRadius: "50rem",
            backgroundColor: primary,
            fontWeight: 400,
            fontStyle: "normal",
            fontSize: "1.2rem",
            boxShadow: "none",
            position: "fixed",
            top: theme.spacing(10),
            right: 20,
            color: secondaryDark,
            "&:hover": {
              backgroundColor: GreenLight,
              color: secondary,
              boxShadow: "none",
            },
            display: user?.userRoles?.some(
              (role) =>
                role.roleType === "SENIOR_USER" || role.roleType === "EXPERT"
            )
              ? "flex"
              : "none",
          }}
        >
          افزودن درخواست داوری
        </Button>
      </Box>

      <div className={`flex max-w-[85dvw] mx-auto flex-col gap-3 ${mode != "list" ? "hidden" : ""}`}>
        <div className="flex w-full mx-auto">
          <div className="flex gap-2 p-3 bg-gray-10 w-fit rounded-2xl my-3">
            <Tabs
            variant="scrollable"
            scrollButtons="auto"
              value={tab}
              onChange={(e, v) => {
                setTab(v as number);
                scrollContainer.current?.swiper.slideTo(v as number);
                scrollContainer.current?.swiper.activeIndex;
              }}
            >
              {user?.userRoles?.some(
                (role) => role.roleType === "SENIOR_USER"
              ) && (
                // <ComplaintsList
                //   type="accuser"
                //   departmentId={
                //     user.userType === "CONTRACTOR_OR_CONSULTANT" ||
                //     user.userType === "ORGANIZATION"
                //       ? user.id
                //       : user.parentId
                //   }
                // />
                <Tab label="درخواست های داوری شما" value={0} />
              )}

              {user?.userRoles?.some(
                (role) => role.roleType === "SENIOR_USER"
              ) &&
                !user?.userRoles?.some(
                  (role) => role.roleType === "SUPER_ADMIN"
                ) && <Tab label="درخواست های داوری به طرفیت شما" value={1} />}
              {user?.userRoles?.some((role) => role.roleType === "EXPERT" && user.userType != "CONTRACTOR_OR_CONSULTANT") && (
                <Tab
                  label="درخواست های داوری تخصیص داده شده به شما"
                  value={2}
                />
              )}
              {/* <Tab label="تاریخچه درخواست ها" value={3} /> */}
            </Tabs>
          </div>
        </div>

        <NewComplaintList
          departmentId={
            user.userType === "CONTRACTOR_OR_CONSULTANT" ||
            user.userType === "ORGANIZATION"
              ? user.id
              : user.parentId
          }
          type={tab === 0 ? "accuser" : tab === 1 ? "accused" : tab === 1 ? "assigned": "all"}
        />
      </div>

      <Box
        sx={{
          display: mode === "card" ? "grid" : "none",
          gridTemplateColumns: {
            xs: "1fr",
            lg: user?.userRoles?.some((role) => role.roleType === "SUPER_ADMIN")
              ? "1fr"
              : "1fr 1fr",
          },
          gap: 1,
        }}
      >
        {user?.userRoles?.some((role) => role.roleType === "SENIOR_USER") && (
          <ComplaintsList
            type="accuser"
            departmentId={
              user.userType === "CONTRACTOR_OR_CONSULTANT" ||
              user.userType === "ORGANIZATION"
                ? user.id
                : user.parentId
            }
          />
        )}

        {user?.userRoles?.some((role) => role.roleType === "SENIOR_USER") &&
          !user?.userRoles?.some((role) => role.roleType === "SUPER_ADMIN") && (
            <ComplaintsList
              type="accused"
              departmentId={
                user.userType === "CONTRACTOR_OR_CONSULTANT" ||
                user.userType === "ORGANIZATION"
                  ? user.id
                  : user.parentId
              }
            />
          )}

        {user?.userRoles?.some((role) => role.roleType === "EXPERT") && (
          <ComplaintsList
            type="assigned"
            departmentId={user.parentId}
            userId={user.id}
          />
        )}
        {user?.userRoles?.some((role) => role.roleType === "SUPER_ADMIN") && (
          // <ComplaintsList type="all" />
          <NewComplaintList
            type="all"
            userId={user.id}
            departmentId={user.parentId}
          />
        )}
      </Box>

      <NewModal
        name="ثبت درخواست داوری"
        width={{
          xs: "100%",
          sm: "100%",
          md: "90%",
          lg: "80%",
          xl: "80%",
        }}
        isCloseable={true}
        open={addModal.open}
        onClose={() => setAddModal({ ...addModal, open: false })}
        backgroundColor={background}
      >
        <Box
          sx={{
            width: "100%",
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              sm: "1fr",
              md: "1fr 1fr",
              lg: "repeat(4, 1fr)",
            },
            justifyContent: "center",
            alignItems: "stretch",
            gap: 2,
          }}
        >
          <FaTextField
            label="جستجو"
            variant="outlined"
            value={addModal.search}
            onChange={(e) => {
              setAddModal({
                ...addModal,
                search: e.target.value,
              });
              void getPublicContract({
                variables: {
                  take: take,
                  skip: (page - 1) * take,
                  filter: {
                    or: [
                      { fullName: { contains: e.target.value } },
                      { contractID: { contains: e.target.value } },
                    ],
                  },
                },
              });
            }}
            sx={{
              gridColumn: {
                xs: "span 1",
                md: "span 2",
                lg: "span 3",
              },
            }}
          />
          <Button
            variant="contained"
            sx={{
              borderRadius: 2,
              backgroundColor: primary,
              fontWeight: 400,
              fontStyle: "normal",
              fontSize: "1rem",
              boxShadow: "none",
              gridColumn: {
                xs: "span 1",
                md: "span 2",
                lg: "span 1",
              },
              // height: "max-content",
              color: secondaryDark,
              "&:hover": {
                backgroundColor: GreenLight,
                boxShadow: "none",
              },
            }}
            onClick={() => {
              void getPublicContract({
                variables: {
                  take: take,
                  skip: (page - 1) * take,
                  filter: {
                    or: [
                      { fullName: { contains: addModal.search } },
                      { contractID: { contains: addModal.search } },
                    ],
                  },
                },
              });
            }}
          >
            جستجو
          </Button>
          <Button
            variant="contained"
            sx={{
              borderRadius: 2,
              backgroundColor: primary,
              fontWeight: 400,
              fontStyle: "normal",
              fontSize: "1rem",
              boxShadow: "none",
              gridColumn: {
                xs: "span 1",
                md: "span 2",
                lg: "span 4",
              },
              // height: "max-content",
              color: secondaryDark,
              "&:hover": {
                backgroundColor: GreenLight,
                boxShadow: "none",
              },
            }}
            onClick={() => {
              navigate("create/contractPageToFill/");
            }}
          >
            قرارداد موردنظر در فهرست قراردادهای ذیل موجود نمی‌باشد، ادامه ثبت
            درخواست
          </Button>
          {/* {loading &&
            [...Array(10)].map((item) => (
              <Skeleton
                variant="rectangular"
                key={item}
                width="100%"
                height={100}
                sx={{
                  borderRadius: "1rem",
                }}
              />
            ))} */}
          <Box
            sx={{
              gridColumn: {
                xs: "span 2",
                md: "span 2",
                lg: "span 4",
              },
            }}
          >
            <CTable
              colNum={5}
              page={page}
              setPage={setPage}
              totalRecords={
                contracts?.publicContract_getPublicContracts?.result
                  ?.totalCount || 0
              }
              recordsPerPage={take}
              setRecordsPerPage={setTake}
              tableHeader={
                <TableRow
                  sx={{
                    th: {
                      padding: "10px",
                      cursor: "pointer",
                    },
                  }}
                >
                  <TableCell
                    onClick={() => {
                      setOrder({
                        contractID:
                          sortMode === "ASC"
                            ? SortEnumType.Desc
                            : SortEnumType.Asc,
                      });
                      setSortMode(sortMode === "ASC" ? "DESC" : "ASC");
                    }}
                    className="cursor-pointer"
                  >
                    <div className="text">
                      شناسه قرارداد{" "}
                      {order?.contractID === SortEnumType.Asc ? (
                        <span>▲</span>
                      ) : order?.contractID === SortEnumType.Desc ? (
                        <span>▼</span>
                      ) : null}
                    </div>
                  </TableCell>
                  <TableCell
                    onClick={() => {
                      setOrder({
                        executiveTitle:
                          sortMode === "ASC"
                            ? SortEnumType.Desc
                            : SortEnumType.Asc,
                      });
                      setSortMode(sortMode === "ASC" ? "DESC" : "ASC");
                    }}
                    className="cursor-pointer"
                  >
                    <div className="text">
                      نام طرف قرارداد{" "}
                      {order?.executiveTitle === SortEnumType.Asc ? (
                        <span>▲</span>
                      ) : order?.executiveTitle === SortEnumType.Desc ? (
                        <span>▼</span>
                      ) : null}
                    </div>
                  </TableCell>
                  <TableCell
                    onClick={() => {
                      setOrder({
                        fullName:
                          sortMode === "ASC"
                            ? SortEnumType.Desc
                            : SortEnumType.Asc,
                      });
                      setSortMode(sortMode === "ASC" ? "DESC" : "ASC");
                    }}
                    className="cursor-pointer"
                  >
                    نام شرکت{" "}
                    {order?.fullName === SortEnumType.Asc ? (
                      <span>▲</span>
                    ) : order?.fullName === SortEnumType.Desc ? (
                      <span>▼</span>
                    ) : null}
                  </TableCell>
                  <TableCell
                    onClick={() => {
                      setOrder({
                        contractSubject:
                          sortMode === "ASC"
                            ? SortEnumType.Desc
                            : SortEnumType.Asc,
                      });
                      setSortMode(sortMode === "ASC" ? "DESC" : "ASC");
                    }}
                    className="cursor-pointer"
                  >
                    عنوان قرارداد{" "}
                    {order?.contractSubject === SortEnumType.Asc ? (
                      <span>▲</span>
                    ) : order?.contractSubject === SortEnumType.Desc ? (
                      <span>▼</span>
                    ) : null}
                  </TableCell>
                  <TableCell
                    onClick={() => {
                      setOrder({
                        agreeDate:
                          sortMode === "ASC"
                            ? SortEnumType.Desc
                            : SortEnumType.Asc,
                      });
                      setSortMode(sortMode === "ASC" ? "DESC" : "ASC");
                    }}
                    className="cursor-pointer"
                  >
                    تاریخ انعقاد{" "}
                    {order?.agreeDate === SortEnumType.Asc ? (
                      <span>▲</span>
                    ) : order?.agreeDate === SortEnumType.Desc ? (
                      <span>▼</span>
                    ) : null}
                  </TableCell>
                </TableRow>
              }
            >
              {" "}
              <TableRow
                sx={{
                  background: "white",
                  transition: " all 0.3s ease-in-out",
                }}
              >
                <td
                  style={{
                    padding: "5px",
                  }}
                >
                  {" "}
                  <TextField
                    variant="outlined"
                    sx={{
                      width: "100%",
                    }}
                    placeholder="شناسه قرارداد"
                    value={addModal.idSearch}
                    onChange={(e) =>
                      setAddModal({
                        ...addModal,
                        idSearch: e.target.value,
                      })
                    }
                  />
                </td>
                <td
                  style={{
                    padding: "5px",
                  }}
                >
                  <TextField
                    variant="outlined"
                    sx={{
                      width: "100%",
                    }}
                    placeholder="نام طرف قرارداد"
                    value={addModal.executorSearch}
                    onChange={(e) =>
                      setAddModal({
                        ...addModal,
                        executorSearch: e.target.value,
                      })
                    }
                  />
                </td>
                <td
                  style={{
                    padding: "5px",
                  }}
                >
                  <TextField
                    variant="outlined"
                    sx={{
                      width: "100%",
                    }}
                    placeholder="نام شرکت"
                    value={addModal.fullName}
                    onChange={(e) =>
                      setAddModal({
                        ...addModal,
                        fullName: e.target.value,
                      })
                    }
                  />
                </td>
                <td
                  style={{
                    padding: "5px",
                  }}
                >
                  {" "}
                  <TextField
                    variant="outlined"
                    sx={{
                      width: "100%",
                    }}
                    placeholder="عنوان قرارداد"
                    value={addModal.titleSearch}
                    onChange={(e) =>
                      setAddModal({
                        ...addModal,
                        titleSearch: e.target.value,
                      })
                    }
                  />
                </td>
                <td></td>
                <td></td>
              </TableRow>
              {contracts?.publicContract_getPublicContracts.result?.items?.map(
                (item) => (
                  <TableRow
                    sx={{
                      borderRadius: "1rem",
                      overflow: "hidden",
                      whiteSpace: "nowrap",
                      textOverflow: "ellipsis",
                      // "&:nth-of-type(odd)": {
                      //   backgroundColor: "#f5f5f5",
                      // },
                      // "&:nth-of-type(even)": {
                      //   backgroundColor: "#fff",
                      // },
                      // center every cell
                      "&:hover": {
                        backgroundColor: "rgba(100,150,150,0.1)",
                        cursor: "pointer",
                      },
                      "& td": {
                        padding: "10px",
                        // borderRadius: "1rem",
                      },
                    }}
                    onClick={() => {
                      setAddModal({
                        ...addModal,
                        contractId: item?.id,
                      });
                      navigate(
                        `/complaints/${item?.id}/create/contractPageToFill/`
                      );
                    }}
                  >
                    <td>{item?.contractID}</td>
                    <td>{item?.executiveTitle}</td>
                    <td>{item?.fullName}</td>
                    <td>{item?.contractSubject}</td>
                    <td>
                      {item?.agreeDate &&
                        new Date(item?.agreeDate as string).toLocaleDateString(
                          "fa-IR"
                        )}
                    </td>
                    {/* <td>
                      {item?.createdDate &&
                        new Date(
                          item?.createdDate as string
                        ).toLocaleDateString("fa-IR")}
                    </td> */}
                  </TableRow>
                )
              )}
            </CTable>
          </Box>
        </Box>
      </NewModal>
    </>
  );
};

export default Complaints;
