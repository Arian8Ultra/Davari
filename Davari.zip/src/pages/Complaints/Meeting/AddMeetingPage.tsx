/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
import { useMutation } from "@apollo/client";
import {
  Box,
  Button,
  LinearProgress,
  MenuItem,
  TextField,
  Typography,
  colors,
} from "@mui/material";
import { DatePicker, TimeClock, TimePicker } from "@mui/x-date-pickers";
import React from "react";
import { useParams } from "react-router-dom";
import {
  useGenerateAssignToExpertLetterMutation,
  useGenerateComplaintDecreeMutation,
  useGetComplaintQuery,
  useSendDetermineExpertLetterMutation,
  useSendInviteToMeetingLetterMutation,
} from "../../../../generated-types";
import { useUserStore } from "../../../Context/UserStore";
import BackButton from "../../../components/BackButton";
import FaTypography from "../../../components/FaComponents/FaTypography";
import { getComplaintStateWithEnum } from "../../../functions/ComplaintStatesFunc";
import { convertToPersianDigits } from "../../../functions/Functions";
import {
  ComplaintStateStatus,
  SendCallToMeetingSmsDocument,
  UpdateComplaintFullDocument,
} from "../../../gql/graphql";
import { primary } from "../../../theme/color";

const AddMeetingPage = () => {
  const { complaintId } = useParams();
  const [date, setDate] = React.useState<Date | null>(new Date());
  const [letterDate, setLetterDate] = React.useState<Date | null>(new Date());
  const [letterNum, setLetterNum] = React.useState<string>("");
  const [hour, setHour] = React.useState<number>(0);
  const [minute, setMinute] = React.useState<number>(0);
  const [endHour, setEndHour] = React.useState<number>(0);
  const [endMinute, setEndMinute] = React.useState<number>(0);
  const [place, setPlace] = React.useState<string>("");
  const user = useUserStore.getState().user;

  const { data } = useGetComplaintQuery({
    variables: {
      id: parseInt(complaintId || "0"),
    },
  });
  const [sendSms, { loading }] = useMutation(SendCallToMeetingSmsDocument, {
    variables: {
      input: {
        complaintId: parseInt(complaintId || "") || 0,
        meetingDate: date?.toDateString() || "",
        meetingTime: "PT" + hour + "H" + minute + "M" || "",
        meetingPlace:
          "تهران، ميدان بهارستان، خيابان دانشسرا، سازمان برنامه و بودجه كشور  " +
          place,
      },
    },
    onCompleted: (data) => {
      console.log(data);
      // if (data.sms_sendInviteToMeetingSMS.code === 1) {
      void updateComplaint({
        onCompleted(data) {
          console.log(data);
          if (data.complaint_updateComplaint.status.code === 1) {
            alert("با موفقیت ارسال شد");
            void generateDecree({
              onCompleted(data) {
                console.log("generateDecree", data);
                window.location.href = "/portal";
              },
              onError(error) {
                console.log("generateDecree", error);
              },
            });
          } else {
            alert("خطا در ارسال");
          }
        },
        onError(error) {
          alert("خطا در ارسال");
        },
      });
      // } else {
      //   alert("خطا در ارسال پیامک");
      // }
    },
    onError: (error) => {
      alert("خطا در ارسال پیامک");
    },
  });

  const [SendDetermineExpertLetter] = useSendDetermineExpertLetterMutation({
    variables: {
      input: {
        complaintId: parseInt(complaintId || "") || 0,
        letterDate:
          data?.complaint_getComplaint?.result?.assignToExpertLetterDate || "",
        letterNum:
          data?.complaint_getComplaint?.result?.assignToExpertLetterNum || "",
        meetingDate: date?.toISOString() || "",
        meetingTime: "PT" + hour + "H" + minute + "M" || "",
      },
    },
    onCompleted: (data) => {
      console.log(data);
    },
    onError: (error) => {
      console.log(error);
    },
  });

  const [GenerateAssignToExpertLetter] =
    useGenerateAssignToExpertLetterMutation({
      variables: {
        input: {
          complaintId: parseInt(complaintId || "") || 0,
          userId: user.id,
          letterDate:
            data?.complaint_getComplaint?.result?.assignToExpertLetterDate ||
            "",
          letterNum:
            data?.complaint_getComplaint?.result?.assignToExpertLetterNum || "",
          meetingDate: date?.toDateString() || "",
          meetingTime: "PT" + hour + "H" + minute + "M" || "",
        },
      },
    });

  const [updateComplaint] = useMutation(UpdateComplaintFullDocument, {
    variables: {
      input: {
        id: parseInt(complaintId || "") || 0,
        complaintStateId: getComplaintStateWithEnum(
          ComplaintStateStatus.CheckingAndUploadingTheSignedDecree
        ).id,
      },
    },
  });
  const [generateDecree] = useGenerateComplaintDecreeMutation({
    variables: {
      input: {
        complaintId: parseInt(complaintId || "") || 0,
        canonDate: new Date().toDateString(),
        canonDate2: new Date().toDateString(),
        canonNum: "0",
        canonNum2: "0",
        circularDate: new Date().toDateString(),
        circularNum: "0",
        clause: "0",
        deliveryDate: new Date().toDateString(),
        userId: user.id,
      },
    },
  });
  return (
    <>
      <BackButton />
      <Box
        display={"grid"}
        gridTemplateColumns={"repeat(6, 1fr)"}
        alignItems={"center"}
        justifyContent={"center"}
        gap={1}
        padding={"2rem"}
        paddingTop={"0"}
        border={`2px solid ${primary}`}
        borderRadius={"1rem"}
        position={"relative"}
        marginY={"3rem"}
        width={{
          xs: "100%",
          sm: "100%",
          md: "80%",
          lg: "70%",
          xl: "66%",
        }}
        sx={{
          background: colors.grey[50],
          display: "grid",
        }}
        className={"gap-5"}
        marginX={"auto"}
      >
        <Box
          gridColumn={"span 6"}
          borderRadius={"1rem"}
          sx={{
            position: "absolute",
            top: "0",
            left: "50%",
            transform: "translateY(-50%) translateX(-50%)",
            background: primary,
            padding: "0.5rem 1rem",
            userSelect: "none",
            width: "max-content",
            maxWidth: "70%",
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <FaTypography variant="h6" textAlign={"center"}>
            تعیین زمان جلسه مربوط به درخواست داوری به شماره
          </FaTypography>
          <Typography variant="h6" textAlign={"center"}>
            {" : "}
            {convertToPersianDigits(complaintId)}
          </Typography>
        </Box>

        <DatePicker
          value={date || undefined}
          onChange={(newValue) => {
            setDate(newValue);
          }}
          sx={{
            gridColumn: "span 6",
            mt: "50px",
          }}
          disablePast
        />

        <FaTypography
          fontSize={"14px"}
          sx={{
            gridColumn: "span 1",
            // mt: "50px",
          }}
        >
          زمان شروع جلسه :
        </FaTypography>

        <TextField
          label="ساعت"
          variant="outlined"
          sx={{
            gridColumn: "span 1",
            // mt: "50px",
          }}
          size="small"
          type="number"
          onChange={(e) => {
            setHour(parseInt(e.target.value));
          }}
          value={hour}
          select
        >
          {[...Array(24)].map((_, i) => (
            <MenuItem key={i} value={i}>
              {convertToPersianDigits(i)}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="دقیقه"
          variant="outlined"
          sx={{
            gridColumn: "span 1",
            // mt: "50px",
          }}
          size="small"
          type="number"
          onChange={(e) => {
            setMinute(parseInt(e.target.value));
          }}
          value={minute}
          select
        >
          {[...Array(60)].map((_, i) => (
            <MenuItem key={i} value={i}>
              {convertToPersianDigits(i)}
            </MenuItem>
          ))}
        </TextField>

        {/* <div className="col-span-3"></div> */}

        <FaTypography
          fontSize={"14px"}
          sx={{
            gridColumn: "span 1",
            // mt: "50px",
          }}
        >
          زمان پایان جلسه :
        </FaTypography>

        <TextField
          label="ساعت"
          variant="outlined"
          sx={{
            gridColumn: "span 1",
            // mt: "50px",
          }}
          size="small"
          type="number"
          onChange={(e) => {
            setEndHour(parseInt(e.target.value));
          }}
          value={endHour}
          select
        >
          {[...Array(24)].map((_, i) => (
            <MenuItem key={i} value={i}>
              {convertToPersianDigits(i)}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="دقیقه"
          variant="outlined"
          sx={{
            gridColumn: "span 1",
            // mt: "50px",
          }}
          size="small"
          type="number"
          onChange={(e) => {
            setEndMinute(parseInt(e.target.value));
          }}
          value={endMinute}
          select
        >
          {[...Array(60)].map((_, i) => (
            <MenuItem key={i} value={i}>
              {convertToPersianDigits(i)}
            </MenuItem>
          ))}
        </TextField>

        {/* <TimeClock
          value={time}
          onChange={(newValue) => {
            setTime(newValue);
          }}

          sx={{
            gridColumn: "span 3",
            mt: "50px",
          }}
          ampm={false}
        /> */}

        <TextField
          label="محل برگزاری جلسه"
          variant="outlined"
          sx={{
            gridColumn: "span 6",
            //   mt: "50px",
          }}
          size="small"
          onChange={(e) => {
            setPlace(e.target.value);
          }}
          value={place}
          InputProps={{
            startAdornment: (
              <div className="whitespace-nowrap text-gray-55 mx-1 text-sm">
                تهران، ميدان بهارستان، خيابان دانشسرا، سازمان برنامه و بودجه
                كشور
              </div>
            ),
          }}
        />

        {/* <TextField
          label="شماره نامه تعیین کارشناس"
          variant="outlined"
          sx={{
            gridColumn: "span 3",
            mt: "50px",
          }}
          size="medium"
          onChange={(e) => {
            setLetterNum(e.target.value);
          }}
          value={letterNum}
        /> */}

        {/* <DatePicker
          label="تاریخ نامه تعیین کارشناس"
          sx={{
            gridColumn: "span 3",
            mt: "50px",
          }}
          value={letterDate || undefined}
          onChange={(newValue) => {
            setLetterDate(newValue);
          }}
        /> */}
        <div
          style={{
            gridColumn: "span 6",
          }}
        >
          {loading && <LinearProgress />}
        </div>

        <Button
          variant="contained"
          sx={{
            gridColumn: "span 6",
            fontSize: "1.1rem",
            width: "max-content",
            padding: "0.25rem 1rem",
            justifySelf: "flex-end",
            background: primary,
            color: "white",
            boxShadow: "none",
            "&:hover": {
              backgroundColor: colors.green[500],
              color: "white",
              boxShadow: "none",
            },
          }}
          className="rounded"
          onClick={() => {
            void sendSms();
            void SendDetermineExpertLetter();
            void GenerateAssignToExpertLetter();
          }}
        >
          ارسال پیامک
        </Button>
      </Box>
    </>
  );
};

export default AddMeetingPage;
