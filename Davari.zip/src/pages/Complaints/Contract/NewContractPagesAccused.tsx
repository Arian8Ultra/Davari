/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { AddCircleOutline, CancelRounded } from "@mui/icons-material";
import {
  Box,
  Button,
  Checkbox,
  CircularProgress,
  Divider,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormLabel,
  IconButton,
  InputLabel,
  LinearProgress,
  List,
  ListItemText,
  MenuItem,
  OutlinedInput,
  Radio,
  RadioGroup,
  Select,
  SelectChangeEvent,
  TextField,
  Typography,
} from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { NumericFormat } from "react-number-format";
import { useNavigate, useParams } from "react-router-dom";
import { ToWords } from "to-words";
import {
  ComplaintStateStatus,
  useCreate_Adjustment_Statement_TableMutation,
  useCreate_Installment_TableMutation,
  useCreate_Work_Condition_Statement_TableMutation,
  useGet_User_QueriableLazyQuery,
  useGetAllOganizationUsersQuery,
  useGetContractQuery,
  useGetUserWithFilterLazyQuery,
  useUpdateComplaintFullMutation,
  useUpdateContractMutation,
} from "../../../../generated-types";
import { useAlertStore } from "../../../Context/AlertStore";
import { useUserStore } from "../../../Context/UserStore";
import { UPLOAD_FILE } from "../../../api/upload";
import cityCodes from "../../../assets/CityCodes.json";
import BackButton from "../../../components/BackButton";
import FaTextField from "../../../components/FaComponents/FaTextField";
import FaTypography from "../../../components/FaComponents/FaTypography";
import FileBox from "../../../components/FileBox";
import TimeLine from "../../../components/TimeLine";
import TreeChart, { TreeChartObject } from "../../../components/TreeChart";
import { getComplaintStateWithEnum } from "../../../functions/ComplaintStatesFunc";
import {
  ContractGeneralType,
  ContractInput,
  RegistrarType,
  UserType,
} from "../../../gql/graphql";
import countries from "../../../static/Countries";
import currencies from "../../../static/Currencies.json";
import { provinces } from "../../../static/provinces.json";
import { primary, secondary } from "../../../theme/color";
import { cityCodeType } from "./ContractPage";
import { convertToPersianDigits } from "../../../functions/Functions";

const NewContractPagesAccused = () => {
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();
  const { contractId, complaintId, stageNum } = useParams<{
    contractId?: string;
    complaintId?: string;
    type?: string;
    stageNum?: string;
  }>();
  const { user, token } = useUserStore();
  const navigate = useNavigate();
  const {
    watch,
    setValue,
    setError,
    clearErrors,
    formState: { errors, isValid },
    getValues,
    register,
    resetField,
    handleSubmit,
  } = useForm<ContractInput>();

  // const [stage, setStage] = useState(parseFloat(stageNum || "1") || 1);
  const toWords = new ToWords({
    localeCode: "fa-IR",
  });
  const [hasIncOrDec, setHasIncOrDec] = useState(false);
  const [Employee, setEmployee] = React.useState<string>();
  const [Employer, setEmployer] = React.useState<string>();
  const [contractDetailsIsOther, setContractDetailsIsOther] = useState(false);
  const [loading, setLoading] = useState(false);
  const [catchError, setCatchError] = useState<string>();

  const [tempPeopleFromAccuser, SetTempPeopleFromAccuser] = useState<{
    name?: string;
    phoneNumber?: string;
    position?: string;
    nationalCode?: string;
    landLine?: string;
  }>();

  const [tempPeopleFromAccused, SetTempPeopleFromAccused] = useState<{
    name?: string;
    phoneNumber?: string;
    position?: string;
    nationalCode?: string;
    landLine?: string;
  }>();

  const [contractTypeGeneral, setContractTypeGeneral] = useState<string>();
  const [contractTypeSpecific, setContractTypeSpecific] = useState<string>();

  const [AccusedDepartmentId, setAccusedDepartmentId] =
    React.useState<string>();
  const [RelatedPeopleByAccusser, setRelatedPeopleByAccusser] = React.useState<
    {
      name?: string;
      phone?: string;
      position?: string;
      nationalCode?: string;
      landLine?: string;
    }[]
  >([]);

  const [RelatedPeopleByAccussed, setRelatedPeopleByAccussed] = React.useState<
    {
      name?: string;
      phone?: string;
      position?: string;
      nationalCode?: string;
      landLine?: string;
    }[]
  >([]);

  const [SupervisionDepartmentPersonnel1, setSupervisionDepartmentPersonnel1] =
    useState<{
      name?: string;
      phone?: string;
      position?: string;
      nationalCode?: string;
      landLine?: string;
    }>();

  const [SupervisionDepartmentPersonnel2, setSupervisionDepartmentPersonnel2] =
    useState<{
      name?: string;
      phone?: string;
      position?: string;
      nationalCode?: string;
      landLine?: string;
    }>();

  const [treeViewObject, setTreeViewObject] = useState<TreeChartObject>();
  const [FromWebService, setFromWebService] = useState(false);
  type BaseIndexPeriodType = {
    isQuarter: boolean;
    quarter: string;
    month: string;
    year: string;
  };
  const [BaseIndexPeriod, setBaseIndexPeriod] =
    React.useState<BaseIndexPeriodType>();
  const [updateCompaint] = useUpdateComplaintFullMutation({
    variables: {
      input: {
        isArchived: false,
        id: complaintId ? parseInt(complaintId) : 0,
        complaintStateId: getComplaintStateWithEnum(
          ComplaintStateStatus.WaitingForAccusedToRegisterArbitrationTerms
        ).id,
      },
    },
    onCompleted(data) {
      alert("ثبت شد");
      navigate(
        `/complaints/${contractId || ""}/${complaintId || ""}/tablesPage`
      );
    },
  });

  const [addInstallment] = useCreate_Installment_TableMutation({
    onCompleted(data, clientOptions) {
      console.log("🚀 ~ onCompleted ~ addInstallment:", data);
    },
  });

  const [addWorkCondition] = useCreate_Work_Condition_Statement_TableMutation({
    onCompleted(data, clientOptions) {
      console.log("🚀 ~ onCompleted ~ addWorkCondition:", data);
    },
  });
  const [addAdjustmentStatement] = useCreate_Adjustment_Statement_TableMutation(
    {
      onCompleted(data, clientOptions) {
        console.log("🚀 ~ onCompleted ~ addAdjustmentStatement:", data);
      },
    }
  );
  const contract_details_items = [
    {
      id: 1,
      generalType: ContractGeneralType.Contractor,
      title:
        "موافقتنامه و شرایط عمومی و شرایط خصوصی پیمان‌ها- نشریه شماره ۴۳۱۱ – بخشنامه شماره ۸۴۲/۵۴-۱۰۸۸/۱۰۲ مورخ ۱۳۷۸/۰۳/۰۳",
      children: [
        {
          id: 2,
          title:
            "انعقاد قرارداد اجرای کارهای ساختمانی به صورت سرجمع- بخشنامه شماره ۹۶/۱۲۹۹۱۸۸ مورخ ۱۳۹۶/۰۵/۰۴",
        },
        {
          id: 3,
          title:
            "انعقاد قرارداد اجرای کارهای ساختمانی به صورت سرجمع- بخشنامه شماره ۱۰۰/۶۴۰۵ مورخ ۱۳۸۹/۰۲/۰۴",
        },
        {
          id: 4,
          title:
            "انعقاد قرارداد بر اساس فهرست بهای تجمیع شده راه، باند فرودگاه و زیرسازی راه آهن – شماره ۶۵۶۳۷/۱۰۰ مورخ ۱۳۹۱/۰۸/۱۴",
        },
        {
          id: 0,
          title: "هیچکدام",
        },
      ],
    },
    {
      id: 5,
      generalType: ContractGeneralType.Consultant,
      title:
        "موافقتنامه و شرایط عمومی همسان قراردادهای خدمات مشاوره - نشریه شماره ۴۳۱۸- بخشنامه شماره ۱۰۵/۸۴۲-۵۴/۲۴۶۰- مورخ ۱۳۷۹/۰۴/۲۹",
    },
    {
      id: 6,
      generalType: ContractGeneralType.Consultant,
      title:
        "موافقتنامه و شرایط عمومی همسان قراردادهای خدمات مشاوره پژوهشی - نشریه شماره ۳۴۱۹- بخشنامه شماره ۲۷۵۳/۵۴-۱۶۷۰/۱۰۲ مورخ ۱۳۷۹/۰۵/۲۴",
    },
    {
      id: 7,
      generalType: ContractGeneralType.PlanAndExecution,
      title:
        "موافقتنامه و شرایط عمومی همسان قراردادهای خدمات مدیریت طرح- نشریه شماره ۲۴۱۲۱ مورخ ۱۳۸۰/۰۱/۲۸",
    },
    {
      id: 8,
      generalType: ContractGeneralType.Contractor,
      title:
        "موافقتنامه، پیوست‌ها، شرایط عمومی و شرایط خصوصی پیمان‌های تامین کالا و تجهیزات، ساختمان و نصب به صورت توام (PC)، برای کارهای صنعتی مورخ ۱۸/۱۲/۱۳۸۳",
    },
    {
      id: 9,
      generalType: ContractGeneralType.PlanAndExecution,
      title:
        "قرارداد همسان طرح و ساخت (EPC غیر صنعتی)- 85428/101 مورخ ۱۵/۰۵/۱۳۸۴",
    },
    {
      id: 10,
      generalType: ContractGeneralType.PlanAndExecution,
      title:
        "موافقت‌نامه مشارکت عمومی- خصوصی (PPP) بخشنامه شماره ۹۳/۱۷۲۸۰۴-مورخ ۲۶/۱۲/۱۳۹۳",
    },
    {
      id: 10,
      generalType: ContractGeneralType.PlanAndExecution,
      title:
        "موافقتنامه ساخت، بهره‌برداری، واگذاری (BOT)- نشریه شماره ۴۶۹ مورخ ۲۴/۱۰/۱۳۸۷",
    },
  ] as {
    id: number;
    generalType: ContractGeneralType;
    title: string;
    children: { id: number; title: string }[];
  }[];

  const { data: Departments } = useGetAllOganizationUsersQuery({
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });

  const [getUser] = useGet_User_QueriableLazyQuery({
    variables: {
      id: AccusedDepartmentId || "",
    },
  });

  const [updateComplaint] = useUpdateComplaintFullMutation({
    onCompleted(data) {
      console.log("🚀 ~ onCompleted ~ data:", data);
    },
  });

  const [UpdateContract, { loading: AddContractLoading }] =
    useUpdateContractMutation({
      onCompleted(data, clientOptions) {
        console.log("🚀 ~ onCompleted ~ AddContract:", data);
        void addAdjustmentStatement({
          variables: {
            contractId: data?.contract_updateContract?.result?.id,
            filledBy: RegistrarType.Accused,
            userId: user.id || "",
          },
          onCompleted(data, clientOptions) {
            console.log("🚀 ~ onCompleted ~ addAdjustmentStatement:", data);
          },
          onError(error, clientOptions) {
            console.log("🚀 ~ onError ~ addAdjustmentStatement:", error);
          },
        });

        void addInstallment({
          variables: {
            contractId: data?.contract_updateContract?.result?.id,
            registrarType: RegistrarType.Accused,
            userId: user.id || "",
          },
          onCompleted(data, clientOptions) {
            console.log("🚀 ~ onCompleted ~ addInstallment:", data);
          },
          onError(error, clientOptions) {
            console.log("🚀 ~ onError ~ addInstallment:", error);
          },
        });

        void addWorkCondition({
          variables: {
            contractId: data?.contract_updateContract?.result?.id,
            filledBy: RegistrarType.Accused,
            userId: user.id || "",
          },
          onCompleted(data, clientOptions) {
            console.log("🚀 ~ onCompleted ~ addWorkCondition:", data);
          },
          onError(error, clientOptions) {
            console.log("🚀 ~ onError ~ addWorkCondition:", error);
          },
        });

        void updateCompaint({
          variables: {
            input: {
              isArchived: false,
              id: parseInt(complaintId || ""),
              complaintStateId: getComplaintStateWithEnum(
                ComplaintStateStatus.WaitingForAccusedToRegisterArbitrationTerms
              ).id,
            },
          },
          onCompleted(d) {
            console.log("🚀 ~ createComplaint ~~:", d);
            navigate(
              `/complaints/${contractId}/${parseInt(
                complaintId || ""
              )}/tablesPage`
            );
          },
          onError(error, clientOptions) {
            console.log("🚀 ~ createComplaint ~ error:", error);
          },
        });
      },
    });

  const onSubmit = async (data: ContractInput) => {
    setLoading(true);
    try {
      await UpdateContract({
        variables: {
          input: {
            ...data,
            id: parseInt(contractId || ""),
            accusedRelatedPeopleByAccused: JSON.stringify(
              RelatedPeopleByAccussed
            ),
            accuserRelatedPeopleByAccused: JSON.stringify(
              RelatedPeopleByAccusser
            ),
            supervisionDepartmentPersonnelByAccused: JSON.stringify([
              SupervisionDepartmentPersonnel1,
              SupervisionDepartmentPersonnel2,
            ]),
            baseIndexPeriodByAccuser: JSON.stringify(BaseIndexPeriod),
            accusedDepartmentUserId: undefined,
            accuserDepartmentUserId: undefined,
            // @ts-ignore
            __typename: undefined,
          },
        },
        onCompleted(data, clientOptions) {
          if (data?.contract_updateContract?.status?.code === 1) {
            setAlertMessage("با موفقیت ثبت شد");
            setAlertType("success");
            setAlertOpen(true);
            setLoading(false);
            navigate(
              `/complaints/${contractId || ""}/${complaintId || ""}/tablesPage`
            );
          } else {
            setAlertMessage("خطا در ثبت اطلاعات");
            setAlertType("error");
            setAlertOpen(true);
            setLoading(false);
          }
        },
      });
    } catch (e) {
      setLoading(false);
      setCatchError(String(e));
      console.log(e);
    }
  };

  const handleParent = (
    parent: {
      fullName: string;
      id: string;
      parent?: {
        fullName: string;
        id: string;
      };
    },
    oldObject: {
      fullName: string;
      id: string;
      parent?: {
        fullName: string;
        id: string;
      };
    }
  ) => {
    console.log(parent);

    const object = {
      fullName: parent.fullName,
      id: parent.id,
      children: [oldObject],
    };
    console.log("object", object);

    if (parent.parent) {
      handleParent(parent.parent, object);
    } else {
      setTreeViewObject(object);
    }
  };

  const { data: contractData } = useGetContractQuery({
    variables: {
      id: parseInt(contractId || "") || 0,
    },
    onCompleted(data) {
      Object.keys(data.contract_getContracts.result?.items?.[0] || {}).map(
        (key) => {
          if (key === "isDeleted") {
            return;
          }
          if (key === "createdDate") {
            return;
          }
          if (key === "__typename") {
            return;
          }
          setFromWebService(true);
          setValue(
            "contractNumberByAccused",
            String(
              data?.contract_getContracts?.result?.items?.[0]
                ?.contractNumberByAccuser
            )
          );

          setValue(
            "contractSubjectByAccused",
            data?.contract_getContracts?.result?.items?.[0]
              ?.contractSubjectByAccuser || ""
          );
          setValue(
            "contractDateByAccused",
            new Date(
              data?.contract_getContracts?.result?.items?.[0]?.contractDateByAccuser
            )
          );
          setValue(
            "initialBudgetByAccused",
            data.contract_getContracts.result?.items?.[0]
              ?.initialBudgetByAccuser
          );
          setValue(
            "currencyByAccused",
            data.contract_getContracts.result?.items?.[0]?.currencyByAccuser
          );
          setValue(
            "executionProvinceByAccused",
            data.contract_getContracts.result?.items?.[0]
              ?.executionProvinceByAccuser
          );
          setValue(
            "accusedRelatedPeopleByAccused",
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "accusedRelatedPeopleByAccuser"
              ]
            )
          );
          setRelatedPeopleByAccusser(
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "accuserRelatedPeopleByAccused" as keyof ContractInput
              ]
            )
          );

          setBaseIndexPeriod(
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "baseIndexPeriodByAccuser" as keyof ContractInput
              ]
            )
          );
          setValue(
            "accuserRelatedPeopleByAccused",
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "accuserRelatedPeopleByAccused" as keyof ContractInput
              ]
            )
          );
          setRelatedPeopleByAccussed(
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "accusedRelatedPeopleByAccused" as keyof ContractInput
              ]
            )
          );

          setSupervisionDepartmentPersonnel1(
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "supervisionDepartmentPersonnelByAccused" as keyof ContractInput
              ]
            )[0]
          );
          setSupervisionDepartmentPersonnel2(
            JSON.parse(
              (data.contract_getContracts.result?.items?.[0] as any)[
                "supervisionDepartmentPersonnelByAccused" as keyof ContractInput
              ]
            )[1]
          );
          setFromWebService(true);
          setValue(
            key as keyof ContractInput,
            (data.contract_getContracts.result?.items?.[0] as any)[key]
          );
        }
      );
    },
  });

  const [GetAccuser, { data: AccuserData }] = useGetUserWithFilterLazyQuery({
    variables: {
      filter: {
        id: {
          eq: contractData?.contract_getContracts.result?.items?.[0]
            ?.accuserDepartmentUserId,
        },
      },
    },
    onCompleted(data) {
      console.log("🚀 ~ onCompleted ~ GetAccuser:", data);
    },
  });

  const [GetAccused, { data: AccusedData }] = useGetUserWithFilterLazyQuery({
    variables: {
      filter: {
        id: {
          eq: contractData?.contract_getContracts.result?.items?.[0]
            ?.accusedDepartmentUserId,
        },
      },
    },
  });

  useEffect(() => {
    void GetAccuser();
    void GetAccused();
    setValue(
      "accuserDepartmentUserId",
      user?.userType === "ORGANIZATION"
        ? user.id
        : user.userType === "CONTRACTOR_OR_CONSULTANT"
        ? user.id
        : user.parentId
    );
  }, [GetAccused, GetAccuser, setValue, user.id, user.parentId, user.userType]);

  return (
    <form className="relative w-full" onSubmit={handleSubmit(onSubmit)}>
      <BackButton to="/complaints" />
      <TimeLine stage={1} />

      <div
        className={`sm:grid-cols-3 md:grid-cols-6 grid-cols-3 p-4 pt-0 gap-5 relative  rounded-xl my-10 w-full md:w-3/4 mx-auto bg-gray-20 grid`}
      >
        <div className="rounded-full top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary-500 px-5 py-2 select-none w-fit z-50 absolute text-center text-16px font-bold">
          اطلاعات قرارداد
        </div>

        <FaTextField
          label="عنوان قرارداد: "
          variant="outlined"
          sx={{
            mt: "50px",
          }}
          type="text"
          className="col-span-full"
          value={watch("contractSubjectByAccused")}
          focused={true}
          // onChange={(e) => {
          //   setValue("contractSubjectByAccused", e.target.value);
          // }}
          disabled={FromWebService}
          error={errors.contractSubjectByAccused ? true : false}
          helperText={errors.contractSubjectByAccused?.message}
          InputLabelProps={{
            shrink: true,
          }}
          inputProps={{
            ...register("contractSubjectByAccused", {
              required: "عنوان قرارداد اجباری است",
            }),
          }}
        />

        <TextField
          label="شناسه قرارداد : "
          variant="outlined"
          sx={{
            gridColumn: "span 3",
          }}
          value={
            watch("contractNumberByAccused")
              ? watch("contractNumberByAccused")
              : ""
          }
          type="text"
          focused={watch("contractNumberByAccused") ? true : false}
          // onChange={(e) => {
          //   setValue("contractNumberByAccused", e.target.value);
          // }}
          disabled={FromWebService}
          inputProps={{
            ...register("contractNumberByAccused", {
              required: "شناسه قرارداد اجباری است",
            }),
          }}
          error={errors.contractNumberByAccused ? true : false}
          helperText={errors.contractNumberByAccused?.message}
        />

        <DatePicker
          label="تاریخ انعقاد قرارداد"
          sx={{
            gridColumn: "span 3",
          }}
          value={
            watch("contractDateByAccused")
              ? new Date(watch("contractDateByAccused"))
              : undefined
          }
          onChange={(date) => {
            setValue("contractDateByAccused", date);
          }}
          disabled={FromWebService}
          slotProps={{
            textField: {
              inputProps: {
                ...register("contractDateByAccused", {
                  required: "تاریخ انعقاد قرارداد اجباری است",
                }),
              },
            },
          }}
        />

        <Typography
          variant="body2"
          sx={{
            width: "100%",
            gridColumn: "span 3",
            border: "1px solid #ccc",
            padding: "0.65rem",
            borderRadius: "0.5rem",
          }}
        >
          کارفرما :{" "}
          {AccuserData?.user_getUsers?.result?.items?.[0]?.userType ==
          UserType.Organization
            ? AccuserData?.user_getUsers?.result?.items?.[0]?.fullName
            : AccusedData?.user_getUsers?.result?.items?.[0]?.fullName}
        </Typography>
        <Typography
          variant="body2"
          sx={{
            width: "100%",
            gridColumn: "span 3",
            border: "1px solid #ccc",
            padding: "0.65rem",
            borderRadius: "0.5rem",
          }}
        >
          طرف قرارداد :{" "}
          {AccuserData?.user_getUsers?.result?.items?.[0]?.userType ==
          UserType.ContractorOrConsultant
            ? AccuserData?.user_getUsers?.result?.items?.[0]?.fullName
            : AccusedData?.user_getUsers?.result?.items?.[0]?.fullName}
        </Typography>

        <TreeChart className="col-span-full" object={treeViewObject} />

        <FormControl
          sx={{
            gridColumn: "span 2",
          }}
        >
          <InputLabel size="small">استان محل اجرای پروژه</InputLabel>

          <Select
            label="استان محل اجرای پروژه"
            multiple
            value={watch("executionProvinceByAccuser") || []}
            onChange={(event: SelectChangeEvent<string[]>) => {
              const {
                target: { value },
              } = event;

              setValue(
                "executionProvinceByAccuser",
                typeof value === "string" ? value.split(",") : value
              );
            }}
            input={
              <OutlinedInput
                label="استان محل اجرای پروژه"
                error={errors.executionProvinceByAccused ? true : false}
                size="small"
                // helperText={errors.executionProvinceByAccuser?.message}
                inputProps={{
                  ...register("executionProvinceByAccused", {
                    required: "استان محل اجرای پروژه اجباری است",
                  }),
                }}
              />
            }
            MenuProps={{
              PaperProps: {
                style: {
                  maxHeight: 48 * 4.5 + 8,
                  width: 250,
                },
              },
            }}
            renderValue={(selected) => selected.join(", ")}
          >
            {provinces.map((name) => (
              <MenuItem key={name.capital} value={name.persian_name}>
                <Checkbox
                  checked={
                    (watch("executionProvinceByAccused")?.indexOf(
                      name.persian_name
                    ) || 0) > -1
                  }
                />
                <ListItemText primary={name.persian_name} />
                {/* {name.persian_name} */}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <FaTextField
          label="نوع ارز قرارداد"
          variant="outlined"
          // type="number"
          sx={{
            gridColumn: "span 1",
          }}
          value={watch("currencyByAccused") || ""}
          focused={watch("currencyByAccused") ? true : false}
          error={errors.currencyByAccused ? true : false}
          helperText={errors.currencyByAccused?.message}
          inputProps={{
            ...register("currencyByAccused", {
              required: {
                message: "نوع ارز قرارداد اجباری است",
                value: true,
              },
            }),
          }}
          SelectProps={{
            MenuProps: {
              sx: {
                maxHeight: 300,
              },
            },
          }}
          select
        >
          {currencies.map((c) => (
            <MenuItem value={c}>{c}</MenuItem>
          ))}
        </FaTextField>

        <NumericFormat
          customInput={FaTextField}
          label="مبلغ اوليه/ حق‌الزحمه قرارداد: "
          disabled={FromWebService}
          required
          InputProps={{
            endAdornment: String(watch("currencyByAccused") || "ریال"),
          }}
          sx={{
            gridColumn: "span 2",
          }}
          focused={watch("initialBudgetByAccused") ? true : false}
          error={errors.initialBudgetByAccused ? true : false}
          helperText={errors.initialBudgetByAccused?.message?.toString()}
          value={watch("initialBudgetByAccused")}
          thousandSeparator
          onValueChange={(v) => {
            setValue("initialBudgetByAccused", v.floatValue);
          }}
          // inputProps={{
          //   ...register("initialBudgetByAccused", {
          //     required: "مبلغ اوليه/ حق‌الزحمه قرارداد اجباری است",
          //   }),
          // }}
        />
        <div className="col-span-1 text-end place-self-center">
          {toWords.convert(watch("initialBudgetByAccused") || 0)}{" "}
          {watch("currencyByAccused") || "ریال"}
        </div>

        <NumericFormat
          customInput={FaTextField}
          label="مدت اوليه قرارداد: "
          variant="outlined"
          InputProps={{
            endAdornment: "ماه",
          }}
          max={100}
          min={0}
          allowNegative={false}
          allowLeadingZeros={false}
          maxLength={3}
          sx={{
            gridColumn: "span 3",
          }}
          value={watch("initialTimePeriodByAccused") || ""}
          focused={watch("initialTimePeriodByAccused") ? true : false}
          onValueChange={(e) => {
            setValue("initialTimePeriodByAccused", e.floatValue);
          }}
          required
          // inputProps={{
          //   ...register("initialTimePeriodByAccused", {
          //     required: "مدت اوليه قرارداد اجباری است",
          //   }),
          // }}
          error={errors.initialTimePeriodByAccused ? true : false}
          helperText={
            errors.initialTimePeriodByAccused?.message ||
            "به جای استفاده از ممیز از نقطه استفاده کنید، برای مثال 12.5"
          }
        />
        {watch("initialTimePeriodByAccuser") ? (
          <Typography
            variant="body1"
            sx={{
              gridColumn: "span 3",
              color: secondary,
            }}
          >
            {convertToPersianDigits(
              String(watch("initialTimePeriodByAccused"))?.split(".")[0]
            ) || convertToPersianDigits(0)}
            /
            {convertToPersianDigits(
              String(watch("initialTimePeriodByAccused"))?.split(".")[1]
            ) || convertToPersianDigits(0)}{" "}
            ماه معادل{" "}
            {convertToPersianDigits(
              Math.floor(
                parseInt(
                  String(watch("initialTimePeriodByAccused"))?.split(".")[0]
                ) / 12
              ).toString()
            )}{" "}
            سال و{" "}
            {convertToPersianDigits(
              Math.floor(
                parseInt(
                  String(watch("initialTimePeriodByAccused"))?.split(".")[0]
                ) % 12
              ).toString()
            )}{" "}
            ماه و{" "}
            {convertToPersianDigits(
              Math.floor(
                (parseInt(
                  String(watch("initialTimePeriodByAccused"))?.split(".")[1] ||
                    convertToPersianDigits(0)
                ) /
                  10) *
                  30 || 0
              ).toString()
            )}{" "}
            روز
          </Typography>
        ) : (
          <div
            className=""
            style={{
              gridColumn: "span 3",
            }}
          ></div>
        )}

        <FormControlLabel
          label={"ابلاغ افزایش / کاهش مبلغ"}
          sx={{
            gridColumn: "span 3",
          }}
          control={
            <Checkbox
              checked={hasIncOrDec}
              onChange={(e) => {
                setHasIncOrDec(e.target.checked);
              }}
            />
          }
        />

        <NumericFormat
          customInput={FaTextField}
          label="مبلغ نهایی قرارداد"
          variant="outlined"
          // type="number"
          thousandSeparator
          InputProps={{
            endAdornment: String(watch("currencyByAccused") || "ریال"),
          }}
          sx={{
            gridColumn: "span 3",
          }}
          value={watch("finalBudgetByAccused")}
          error={errors.finalBudgetByAccused ? true : false}
          helperText={errors.finalBudgetByAccused?.message?.toString()}
          disabled={!hasIncOrDec}
          onValueChange={(v) => {
            setValue("finalBudgetByAccused", v.floatValue);
          }}
          // required={hasIncOrDec}
          {...register("finalBudgetByAccused", {
            required: hasIncOrDec ? "مبلغ نهایی قرارداد اجباری است" : "",
            setValueAs: (v) => {
              return v.floatValue;
            },
          })}
        />

        <FormControlLabel
          label={"قرارداد به کارفرمای جدید منتقل شده است"}
          sx={{
            gridColumn: "span 3",
          }}
          control={
            <Checkbox
              checked={watch("isTransferred") || false}
              onChange={(e) => {
                setValue("isTransferred", e.target.checked);
              }}
              disabled={
                user.userType == "ORGANIZATION" ||
                Departments?.user_getUsers?.result?.items?.find((d) => {
                  return d.id === user.parentId;
                })?.userType === "ORGANIZATION"
                  ? false
                  : false
              }
            />
          }
        />

        <FaTextField
          label="کارفرمای جدید"
          variant="outlined"
          sx={{
            gridColumn: "span 2",
          }}
          value={
            Departments?.user_getUsers?.result?.items?.find((d) => {
              return d.id === user.parentId;
            })?.userType === "ORGANIZATION"
              ? Departments?.user_getUsers?.result?.items?.find((d) => {
                  return d.id === user.parentId;
                })!.fullName
              : user.userType == "ORGANIZATION"
              ? user.fullName
              : Employer
          }
          {...register("accusedDepartmentUserId", {
            required: watch("isTransferred")
              ? "کارفرمای جدید اجباری است"
              : false,
          })}
          onChange={(e) => {
            setEmployer(e.target.value);
            {
              setEmployer(e.target.value);
              if (e) {
                console.log(e.target.value);
                setAccusedDepartmentId(e.target.value);
                void getUser({
                  variables: {
                    id: e.target.value,
                  },
                  onCompleted(data) {
                    console.log(data);
                    if (
                      data?.user_getUserQueryable?.result?.items?.[0]?.parent
                    ) {
                      handleParent(
                        data?.user_getUserQueryable?.result?.items?.[0]
                          ?.parent as any,
                        {
                          fullName:
                            data?.user_getUserQueryable?.result?.items[0]
                              ?.fullName,
                          id:
                            data?.user_getUserQueryable?.result.items[0]?.id ||
                            "",
                        }
                      );
                    } else {
                      setTreeViewObject({
                        fullName:
                          data?.user_getUserQueryable?.result?.items?.[0]
                            ?.fullName || "",
                      });
                    }
                  },
                });
              }
            }
          }}
          select={
            user.userType == "ORGANIZATION" ||
            Departments?.user_getUsers?.result?.items?.find((d) => {
              return d.id === user.parentId;
            })?.userType === "ORGANIZATION"
              ? true
              : true
          }
          error={errors.accusedDepartmentUserId ? true : false}
          helperText={errors.accusedDepartmentUserId?.message}
          disabled={watch("isTransferred") ? false : true}
        >
          {Departments?.user_getUsers?.result?.items?.map((item) => (
            <MenuItem value={item.id as string}>{item.fullName}</MenuItem>
          ))}
        </FaTextField>
        <FileBox
          disabled={!watch("isTransferred")}
          title="مستندات انتقال قرارداد"
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue("isTransferredFileName", res.result?.[0]?.newFileName);
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />
      </div>

      <div
        className={`sm:grid-cols-3 md:grid-cols-6 grid-cols-3 p-4 pt-0 gap-5 relative  rounded-xl my-10 w-full md:w-3/4 mx-auto bg-gray-20 grid`}
      >
        <div className="rounded-full top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary-500 px-5 py-2 select-none w-fit z-50 absolute text-center text-16px font-bold">
          پیوست ها
        </div>

        <FileBox
          sx={{
            gridColumn: "span 3",
            mt: "50px",
          }}
          title="فایل موافقتنامه"
          fileUrl={watch("agreementFileNameByAccused") || ""}
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue(
                  "agreementFileNameByAccused",
                  res.result?.[0]?.newFileName
                );
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />

        <FileBox
          sx={{
            gridColumn: "span 3",
            mt: "50px",
          }}
          title="فایل شرایط عمومی"
          fileUrl={watch("generalConditionsFileNameByAccused") || ""}
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue(
                  "generalConditionsFileNameByAccused",
                  res.result?.[0]?.newFileName
                );
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />

        <FileBox
          sx={{
            gridColumn: "span 3",
          }}
          title="فایل شرایط خصوصی"
          fileUrl={watch("privateTermsFileNameByAccused") || ""}
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue(
                  "privateTermsFileNameByAccused",
                  res.result?.[0]?.newFileName
                );
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />

        <FileBox
          sx={{
            gridColumn: "span 3",
          }}
          title="سایر پیوست‌ ها"
          fileUrl={watch("otherAttachmentFileNamesByAccused")?.[0] || ""}
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue("otherAttachmentFileNamesByAccused", [
                  res.result?.[0]?.newFileName,
                ]);
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />
      </div>

      <div
        className={`sm:grid-cols-3 md:grid-cols-6 grid-cols-3 p-4 pt-0 gap-5 relative  rounded-xl my-10 w-full md:w-3/4 mx-auto bg-gray-20 grid`}
      >
        <div className="rounded-full top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary-500 px-5 py-2 select-none w-fit z-50 absolute text-center text-16px font-bold">
          اطلاعات تکمیلی قرارداد
        </div>

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            محل ثبت شرکت
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        {/* a divider */}
        <FaTextField
          label="محل ثبت شرکت : "
          variant="outlined"
          sx={{
            gridColumn: "span 3",
          }}
          select
          SelectProps={{
            MenuProps: {
              disableScrollLock: true,
              sx: {
                maxHeight: "20rem",
              },
            },
          }}
          value={watch("accusedNationality") || ""}
          // onChange={(e) => {
          //   setValue("accuserNationality", e.target.value);
          // }}
          inputProps={{
            ...register("accusedNationality", {
              required: "محل ثبت شرکت اجباری است",
            }),
          }}
          error={errors.accuserNationality ? true : false}
          helperText={errors.accuserNationality?.message}
        >
          {countries.map((item, index) => (
            <MenuItem key={index} value={item.name_fa}>
              {item.name_fa}
            </MenuItem>
          ))}
        </FaTextField>

        {user.userType == "CONTRACTOR_OR_CONSULTANT" && (
          <FormControlLabel
            className="col-span-3"
            control={
              <Checkbox
                checked={watch("isAccusedIranian") == false ? true : false}
                onChange={(e) => {
                  setValue("isAccusedIranian", !e.target.checked);
                }}
              />
            }
            label="یکی از طرفین مشارکت غیر ایرانی میباشد (در صورت مشارکتی بودن قرارداد)"
          />
        )}

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full"
          >
            نمایندگان(وکلا)
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <Box
          gridColumn={"span 3"}
          display={"flex"}
          flexDirection={"column"}
          justifyContent={"start"}
          alignItems={"center"}
          height={"100%"}
          rowGap={2}
        >
          <FaTypography variant="body1" gridColumn={"span 12"}>
            اطلاعات نمایندگان/وکلا از طرف اینجانب:
          </FaTypography>
          <Box
            display={"grid"}
            gridTemplateColumns={"1fr 1fr 1fr 1fr"}
            gap={2}
            justifyContent={"center"}
            alignItems={"center"}
          >
            {(RelatedPeopleByAccusser?.length || 0) < 3 && (
              <>
                <NumericFormat
                  customInput={FaTextField}
                  label="کد ملی"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 2",
                  }}
                  value={tempPeopleFromAccuser?.nationalCode}
                  // type="number"
                  maxLength={10}
                  onValueChange={(e) => {
                    SetTempPeopleFromAccuser({
                      ...tempPeopleFromAccuser,
                      nationalCode: e.value,
                    });
                  }}
                />
                <FaTextField
                  label="نام و نام خانوادگی"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 2",
                  }}
                  value={tempPeopleFromAccuser?.name}
                  onChange={(e) => {
                    SetTempPeopleFromAccuser({
                      ...tempPeopleFromAccuser,
                      name: e.target.value,
                    });
                  }}
                />
                <div className="grid grid-cols-4 col-span-2 gap-1">
                  <FaTextField
                    label="تلفن ثابت"
                    variant="outlined"
                    sx={{
                      gridColumn: "span 2",
                    }}
                    value={tempPeopleFromAccuser?.landLine}
                    onChange={(e) => {
                      SetTempPeopleFromAccuser({
                        ...tempPeopleFromAccuser,
                        landLine: e.target.value,
                      });
                    }}
                  />
                  <FaTextField
                    label="کد"
                    variant="outlined"
                    sx={{
                      gridColumn: "span 2",
                    }}
                    select
                    SelectProps={{
                      MenuProps: {
                        sx: {
                          maxHeight: "400px",
                        },
                      },
                    }}
                  >
                    {Object.keys(cityCodes).map((i) => (
                      <MenuItem value={cityCodes[i as cityCodeType].code}>
                        {cityCodes[i as cityCodeType].code}
                      </MenuItem>
                    ))}
                  </FaTextField>
                </div>
                <FaTextField
                  label="تلفن همراه"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 2",
                  }}
                  value={tempPeopleFromAccuser?.phoneNumber}
                  onChange={(e) => {
                    SetTempPeopleFromAccuser({
                      ...tempPeopleFromAccuser,
                      phoneNumber: e.target.value,
                    });
                  }}
                />
                <FaTextField
                  label="سمت"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 4",
                  }}
                  value={tempPeopleFromAccuser?.position}
                  onChange={(e) => {
                    SetTempPeopleFromAccuser({
                      ...tempPeopleFromAccuser,
                      position: e.target.value,
                    });
                  }}
                />

                <Button
                  onClick={() => {
                    setRelatedPeopleByAccusser([
                      ...(RelatedPeopleByAccusser || []),
                      {
                        name: tempPeopleFromAccuser?.name,
                        phone: tempPeopleFromAccuser?.phoneNumber,
                        position: tempPeopleFromAccuser?.position,
                        nationalCode: tempPeopleFromAccuser?.nationalCode,
                        landLine: tempPeopleFromAccuser?.landLine,
                      },
                    ]);
                    SetTempPeopleFromAccuser({
                      name: "",
                      phoneNumber: "",
                      position: "",
                      nationalCode: "",
                    });
                  }}
                  sx={{
                    display: "flex",
                    gap: 2,
                    justifyContent: "center",
                    alignItems: "center",
                    gridColumn: "span 4",
                    bgcolor: primary,
                  }}
                >
                  <AddCircleOutline />
                </Button>
              </>
            )}

            {RelatedPeopleByAccusser?.map((person) => (
              <div className="col-span-4 grid grid-cols-4 gap-2 rounded-md p-2 bg-[rgba(0,0,0,0.1)]">
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  کد ملی : {person.nationalCode}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  نام و نام خانوادگی : {person.name}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  تلفن ثابت : {person.landLine}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  تلفن همراه : {person.phone}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 4",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  سمت :{person.position}
                </Typography>

                <IconButton
                  sx={{
                    alignSelf: "center",
                    // aspectRatio: "1/1",
                    // width: "fit-content",
                  }}
                  className="col-span-4 bg-red-50 text-white-100 w-full rounded-md"
                  onClick={() => {
                    setRelatedPeopleByAccusser(
                      RelatedPeopleByAccusser.filter(
                        (item) => item.name !== person.name
                      )
                    );
                    SetTempPeopleFromAccuser({
                      name: "",
                      phoneNumber: "",
                      position: "",
                      landLine: "",
                      nationalCode: "",
                    });
                  }}
                >
                  <CancelRounded />
                </IconButton>
              </div>
            ))}
          </Box>
        </Box>

        <Box
          gridColumn={"span 3"}
          display={"flex"}
          flexDirection={"column"}
          justifyContent={"start"}
          alignItems={"center"}
          height={"100%"}
          rowGap={2}
        >
          <FaTypography variant="body1" className="col-span-full">
            اطلاعات افراد مطلع از طرف مقابل:
          </FaTypography>
          <Box
            display={"grid"}
            gridTemplateColumns={"1fr 1fr"}
            gap={2}
            justifyContent={"center"}
            alignItems={"center"}
          >
            {(RelatedPeopleByAccussed?.length || 0) < 3 && (
              <>
                <NumericFormat
                  customInput={FaTextField}
                  label="کد ملی"
                  variant="outlined"
                  // sx={{
                  //   gridColumn: "span 2",
                  // }}
                  value={tempPeopleFromAccused?.nationalCode}
                  // type="number"
                  maxLength={10}
                  onValueChange={(e) => {
                    SetTempPeopleFromAccused({
                      ...tempPeopleFromAccused,
                      nationalCode: e.value,
                    });
                  }}
                />
                <FaTextField
                  label="نام و نام خانوادگی"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 1",
                  }}
                  value={tempPeopleFromAccused?.name}
                  onChange={(e) => {
                    SetTempPeopleFromAccused({
                      ...tempPeopleFromAccused,
                      name: e.target.value,
                    });
                  }}
                />
                <div className="grid grid-cols-4 col-span-1 gap-1">
                  <FaTextField
                    label="تلفن ثابت"
                    variant="outlined"
                    sx={{
                      gridColumn: "span 2",
                    }}
                    value={tempPeopleFromAccused?.landLine}
                    onChange={(e) => {
                      SetTempPeopleFromAccused({
                        ...tempPeopleFromAccused,
                        landLine: e.target.value,
                      });
                    }}
                  />
                  <FaTextField
                    label="کد"
                    variant="outlined"
                    sx={{
                      gridColumn: "span 2",
                    }}
                    select
                    SelectProps={{
                      MenuProps: {
                        sx: {
                          maxHeight: "400px",
                        },
                      },
                    }}
                  >
                    {Object.keys(cityCodes).map((i) => (
                      <MenuItem value={cityCodes[i as cityCodeType].code}>
                        {cityCodes[i as cityCodeType].code}
                      </MenuItem>
                    ))}
                  </FaTextField>
                </div>
                <FaTextField
                  label="تلفن همراه"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 1",
                  }}
                  value={tempPeopleFromAccused?.phoneNumber}
                  onChange={(e) => {
                    SetTempPeopleFromAccused({
                      ...tempPeopleFromAccused,
                      phoneNumber: e.target.value,
                    });
                  }}
                />
                <FaTextField
                  label="سمت"
                  variant="outlined"
                  sx={{
                    gridColumn: "span 2",
                  }}
                  value={tempPeopleFromAccused?.position}
                  onChange={(e) => {
                    SetTempPeopleFromAccused({
                      ...tempPeopleFromAccused,
                      position: e.target.value,
                    });
                  }}
                />

                <Button
                  onClick={() => {
                    setRelatedPeopleByAccussed([
                      ...(RelatedPeopleByAccussed || []),
                      {
                        name: tempPeopleFromAccused?.name,
                        phone: tempPeopleFromAccused?.phoneNumber,
                        position: tempPeopleFromAccused?.position,
                        nationalCode: tempPeopleFromAccused?.nationalCode,
                      },
                    ]);
                    console.log(tempPeopleFromAccused);

                    SetTempPeopleFromAccused({
                      name: "",
                      phoneNumber: "",
                      position: "",
                      nationalCode: "",
                    });
                  }}
                  sx={{
                    display: "flex",
                    gap: 2,
                    justifyContent: "center",
                    alignItems: "center",
                    gridColumn: "span 2",
                    bgcolor: primary,
                  }}
                >
                  <AddCircleOutline />
                </Button>
              </>
            )}

            {/* <IconButton
                sx={{
                  alignSelf: "center",
                  aspectRatio: "1/1",
                }}
                onClick={() => {
                  setRelatedPeopleByAccussed([
                    ...RelatedPeopleByAccussed,
                    {
                      name: tempPeopleFromAccused?.name,
                      phone: tempPeopleFromAccused?.phoneNumber,
                      position: tempPeopleFromAccused?.position,
                    },
                  ]);
                  SetTempPeopleFromAccused({
                    name: "",
                    phoneNumber: "",
                    position: "",
                  });
                }}
              >
                <Add />
              </IconButton> */}
            {RelatedPeopleByAccussed?.map?.((person) => (
              <div className="col-span-2 grid grid-cols-4 gap-2 rounded-md p-2 bg-[rgba(0,0,0,0.1)]">
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  کد ملی : {person.nationalCode}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  نام و نام خانوادگی : {person.name}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  تلفن ثابت : {person.landLine}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 2",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  تلفن همراه : {person.phone}
                </Typography>
                <Typography
                  sx={{
                    gridColumn: "span 4",
                    border: "1px solid gray",
                    padding: 1,
                    borderRadius: 2,
                    textAlign: "center",
                  }}
                  className="bg-white-100"
                >
                  سمت :{person.position}
                </Typography>

                <IconButton
                  sx={{
                    alignSelf: "center",
                    // aspectRatio: "1/1",
                    // width: "fit-content",
                  }}
                  className="col-span-4 bg-red-50 text-white-100 w-full rounded-md"
                  onClick={() => {
                    setRelatedPeopleByAccussed(
                      RelatedPeopleByAccussed.filter(
                        (item) => item.name !== person.name
                      )
                    );
                    SetTempPeopleFromAccuser({
                      name: "",
                      phoneNumber: "",
                      position: "",
                      landLine: "",
                      nationalCode: "",
                    });
                  }}
                >
                  <CancelRounded />
                </IconButton>
              </div>
            ))}
          </Box>
        </Box>

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            مشخصات قرارداد
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <FaTypography
          variant="h6"
          className="col-span-full"
          textAlign={"justify"}
        >
          {
            "در این قسمت لازم است انواع قرارداد همسان سازمان برنامه و بودجه کشور که مورد استفاده قرار گرفته است، انتخاب شود:"
          }
        </FaTypography>

        <TextField
          select
          error={errors.contractTypeByAccused ? true : false}
          helperText={errors.contractTypeByAccused?.message}
          value={contractTypeGeneral || ""}
          label={"نوع قرارداد"}
          className="col-span-full"
          InputProps={{
            className: "text-ellipsis overflow-hidden",
          }}
          onChange={(e) => {
            setContractTypeGeneral(e.target.value);
            setValue("contractTypeByAccused", [e.target.value]);
            setValue(
              "contractGeneralTypeByAccused",
              contract_details_items.find(
                (item) => item.title === e.target.value
              )?.generalType
            );
          }}
          // required={true}
          inputProps={{
            ...register("contractTypeByAccused", {
              required: "نوع قرارداد اجباری است",
            }),
          }}
          sx={{
            display: contractDetailsIsOther ? "none" : "grid",
          }}
          SelectProps={{
            MenuProps: {
              sx: {
                maxHeight: "20rem",
              },
            },
          }}
        >
          {contract_details_items.map((item, index) => (
            <MenuItem key={index} value={item.title}>
              {item.title}
            </MenuItem>
          ))}
        </TextField>

        {contract_details_items.find(
          (item) => item.title === contractTypeGeneral
        )?.children && (
          <TextField
            label={"نوع قرارداد به صورت خاص"}
            error={errors.contractTypeByAccuser ? true : false}
            helperText={errors.contractTypeByAccuser?.message}
            onChange={(e) => {
              setContractTypeSpecific(e.target.value);
              setValue("contractTypeByAccused", [
                contractTypeGeneral || "",
                e.target.value,
              ]);
            }}
            required={contractTypeGeneral ? true : false}
            // if the value is long then it will be cut off
            value={contractTypeSpecific || ""}
            select
            className="col-span-full"
            sx={{
              display: contractDetailsIsOther ? "none" : "grid",
            }}
            SelectProps={{
              MenuProps: {
                sx: {
                  maxHeight: "20rem",
                },
              },
            }}
          >
            {contract_details_items
              .find(
                (item) => item.title === watch("contractTypeByAccused")?.[0]
              )
              ?.children?.map((item, index) => (
                <MenuItem key={index} value={item.title}>
                  {item.title}
                </MenuItem>
              ))}
          </TextField>
        )}
        <FormGroup
          sx={{
            gap: "1rem",
          }}
          className="col-span-full"
        >
          <FormControlLabel
            control={
              <Checkbox
                onChange={(e) => {
                  setContractDetailsIsOther(e.target.checked);
                  if (e.target.checked) {
                    setValue("contractTypeByAccused", []);
                  }
                }}
              />
            }
            label="   سایر "
          />
        </FormGroup>

        <FaTextField
          label={"شماره"}
          variant={"outlined"}
          className="col-span-3"
          sx={{
            display: contractDetailsIsOther ? "block" : "none",
          }}
          value={watch("circularNumberByAccused")}
          // onChange={(e) => {
          //   setValue("circularNumberByAccused", e.target.value);
          // }}
          fullWidth
          error={errors.circularNumberByAccused ? true : false}
          helperText={errors.circularNumberByAccused?.message}
          inputProps={{
            ...register("circularNumberByAccused", {
              required: contractDetailsIsOther ? "شماره اجباری است" : false,
            }),
          }}
        />
        <DatePicker
          value={
            watch("circularDateByAccused")
              ? new Date(watch("circularDateByAccused"))
              : undefined
          }
          onChange={(date) => {
            setValue("circularDateByAccused", date);
          }}
          slotProps={{
            textField: {
              fullWidth: true,
              inputProps: {
                ...register("circularDateByAccused", {
                  required: contractDetailsIsOther ? "تاریخ اجباری است" : false,
                }),
              },
              error: errors.circularDateByAccused ? true : false,
            },
          }}
          slots={{
            textField: FaTextField,
          }}
          className="col-span-3"
          sx={{
            display: contractDetailsIsOther ? "block" : "none",
          }}
          label={"تاریخ"}
        />

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            ضريب پيشنهادی
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <NumericFormat
          customInput={FaTextField}
          label="ضريب پيشنهادي: "
          sx={{
            gridColumn: "span 4",
          }}
          focused={watch("recommendedCoefficientByAccused") ? true : false}
          value={watch("recommendedCoefficientByAccused")}
          onValueChange={(e) => {
            setValue("recommendedCoefficientByAccused", e.floatValue);
          }}
          max={2}
          min={0}
          helperText={"نسبت مبلغ پیشنهادی پیمانکار به مبلغ برآورد کافرما"}
          allowNegative={false}
          allowLeadingZeros={false}
          maxLength={3}
          // required
          // inputProps={{
          //   ...register("recommendedCoefficientByAccused", {
          //     required: "ضريب پيشنهادي اجباری است",
          //   }),
          // }}
        />

        <FaTypography variant="h6" gridColumn={"span 2"}>
          {watch("recommendedCoefficientByAccused")
            ? watch("recommendedCoefficientByAccused") || 0 > 1
              ? (
                  (watch("recommendedCoefficientByAccused") || 1) * 100 -
                  100
                ).toPrecision(3) + "% پلوس"
              : (
                  100 -
                  (watch("recommendedCoefficientByAccused") || 1) * 100
                ).toPrecision(3) + "% مینوس"
            : ""}
        </FaTypography>

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            نحوه واگذاری كار
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <FormControl
          className="col-span-full"
          sx={{
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <RadioGroup
            row
            name="row-radio-buttons-group"
            className="col-span-full flex justify-evenly w-full"
          >
            <FormControlLabel
              value="مناقصه عمومی"
              checked={watch("assigningTypeByAccused") === "مناقصه عمومی"}
              control={<Radio />}
              label="مناقصه عمومی"
              onChange={(e) => {
                setValue("assigningTypeByAccused", "مناقصه عمومی");
              }}
            />
            <FormControlLabel
              value="مناقصه محدود"
              checked={watch("assigningTypeByAccused") === "مناقصه محدود"}
              control={<Radio />}
              label="مناقصه محدود"
              onChange={(e) => {
                setValue("assigningTypeByAccused", "مناقصه محدود");
              }}
            />
            <FormControlLabel
              value="ترك مناقصه"
              checked={watch("assigningTypeByAccused") === "ترك مناقصه"}
              control={<Radio />}
              label="ترك مناقصه  "
              onChange={(e) => {
                setValue("assigningTypeByAccused", "ترك مناقصه");
              }}
            />
            <FormControlLabel
              value="سایر"
              checked={watch("assigningTypeByAccused") === "سایر"}
              control={<Radio />}
              label="سایر"
              onChange={(e) => {
                setValue("assigningTypeByAccused", "سایر");
              }}
            />
            <FormControlLabel
              control={
                <FaTextField
                  label="سایر"
                  disabled={watch("assigningTypeByAccused") !== "سایر"}
                />
              }
              label=""
            />
          </RadioGroup>
        </FormControl>

        <FileBox
          title={"مستندات مربوطه"}
          className="col-span-full"
          fileUrl={watch("assigningTypeByAccusedFileName") || ""}
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue(
                  "assigningTypeByAccusedFileName",
                  res.result?.[0]?.newFileName
                );
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />
        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            تعديل
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <FormControl className="col-span-full">
          <FormLabel id="demo-row-radio-buttons-group-label">
            پيمان مشمول تعديل
          </FormLabel>
          <RadioGroup row>
            <FormControlLabel
              value={true}
              control={<Radio />}
              label="می‌باشد"
              checked={watch("doesContainAdjustmentByAccused") == "می‌باشد"}
              onChange={() => {
                setValue("doesContainAdjustmentByAccused", "می‌باشد");
              }}
            />
            <FormControlLabel
              value={false}
              control={<Radio />}
              label="نمی‌باشد"
              checked={watch("doesContainAdjustmentByAccused") == "نمی‌باشد"}
              onChange={() => {
                setValue("doesContainAdjustmentByAccused", "نمی‌باشد");
              }}
            />
          </RadioGroup>
        </FormControl>
        <FormControl
          className="col-span-full"
          sx={{
            gridColumn: "span 3",
            display:
              watch("doesContainAdjustmentByAccused") == "می‌باشد"
                ? "block"
                : watch("doesContainAdjustmentByAccused") ==
                  "مشمول دستورالعمل نحوه تعدیل آحاد بهای پیمان‌ها به شماره 101/173073"
                ? "block"
                : watch("doesContainAdjustmentByAccused") == "سایر"
                ? "block"
                : "none",
          }}
        >
          <RadioGroup row>
            <FormControlLabel
              value={true}
              control={<Radio />}
              label="مشمول دستورالعمل نحوه تعدیل آحاد بهای پیمان‌ها به شماره 101/173073"
              checked={
                watch("doesContainAdjustmentByAccused") ==
                "مشمول دستورالعمل نحوه تعدیل آحاد بهای پیمان‌ها به شماره 101/173073"
              }
              onChange={() => {
                setValue(
                  "doesContainAdjustmentByAccused",
                  "مشمول دستورالعمل نحوه تعدیل آحاد بهای پیمان‌ها به شماره 101/173073"
                );
              }}
            />
            <FormControlLabel
              value={true}
              control={<Radio />}
              label="سایر"
              checked={watch("doesContainAdjustmentByAccused") == "سایر"}
              onChange={() => {
                setValue("doesContainAdjustmentByAccused", "سایر");
              }}
            />
          </RadioGroup>
        </FormControl>

        <FaTextField
          label="شماره"
          type="number"
          sx={{
            gridColumn: "span 3",
            display:
              watch("doesContainAdjustmentByAccused") == "سایر"
                ? "block"
                : "none",
          }}
          fullWidth
        />

        <DatePicker
          sx={{
            gridColumn: "span 3",
            display:
              watch("doesContainAdjustmentByAccused") == "سایر"
                ? "block"
                : "none",
          }}
          slotProps={{
            textField: {
              fullWidth: true,
            },
          }}
          label="تاریخ"
        />

        {watch("doesContainAdjustmentByAccused") != "نمی‌باشد" ? (
          <>
            <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
              <FaTypography
                variant="h5"
                textAlign={"center"}
                className="col-span-full whitespace-nowrap"
              >
                دوره شاخص مبنا
              </FaTypography>
              <Divider className="col-span-full w-full" />
            </div>

            <FormControl className="col-span-full">
              <FormLabel id="demo-row-radio-buttons-group-label">
                نوع دوره شاخص مبنا
              </FormLabel>
              <RadioGroup row>
                <FormControlLabel
                  value={true}
                  control={<Radio />}
                  label="سه ماهه"
                  checked={BaseIndexPeriod && BaseIndexPeriod.isQuarter}
                  onChange={() => {
                    const baseIndexPeriod = {
                      isQuarter: true,
                      month: "",
                      year: "",
                      quarter: "",
                    } as BaseIndexPeriodType;
                    setBaseIndexPeriod(baseIndexPeriod);
                    setValue(
                      "baseIndexPeriodByAccused",
                      JSON.stringify(baseIndexPeriod)
                    );
                  }}
                />
                <FormControlLabel
                  value={false}
                  control={<Radio />}
                  label="ماهانه"
                  checked={BaseIndexPeriod && !BaseIndexPeriod.isQuarter}
                  onChange={() => {
                    const baseIndexPeriod = {
                      isQuarter: false,
                      month: BaseIndexPeriod?.month || "",
                      year: BaseIndexPeriod?.year || "",
                      quarter: "",
                    } as BaseIndexPeriodType;
                    setBaseIndexPeriod(baseIndexPeriod);
                    setValue(
                      "baseIndexPeriodByAccused",
                      JSON.stringify(baseIndexPeriod)
                    );
                  }}
                />
              </RadioGroup>
            </FormControl>

            <FaTextField
              label="ماه"
              type="number"
              sx={{
                gridColumn: "span 3",
                display:
                  BaseIndexPeriod && !BaseIndexPeriod.isQuarter
                    ? "block"
                    : "none",
              }}
              value={BaseIndexPeriod && BaseIndexPeriod.month}
              onChange={(e) => {
                const baseIndexPeriod = {
                  ...BaseIndexPeriod,
                  month: e.target.value,
                } as BaseIndexPeriodType;
                setBaseIndexPeriod(baseIndexPeriod);
                setValue(
                  "baseIndexPeriodByAccused",
                  JSON.stringify(baseIndexPeriod)
                );
              }}
              error={errors.baseIndexPeriodByAccused ? true : false}
              helperText={errors.baseIndexPeriodByAccused?.message}
              select
              SelectProps={{
                MenuProps: {
                  sx: {
                    maxHeight: "20rem",
                  },
                },
              }}
              fullWidth
            >
              {[
                "فروردین",
                "اردیبهشت",
                "خرداد",
                "تیر",
                "مرداد",
                "شهریور",
                "مهر",
                "آبان",
                "آذر",
                "دی",
                "بهمن",
                "اسفند",
              ].map((m) => (
                <MenuItem value={m}>{m}</MenuItem>
              ))}
            </FaTextField>
            <FaTextField
              label="سه ماهه"
              sx={{
                gridColumn: "span 3",
                display:
                  BaseIndexPeriod && BaseIndexPeriod.isQuarter
                    ? "block"
                    : "none",
              }}
              value={BaseIndexPeriod?.quarter || ""}
              onChange={(e) => {
                setBaseIndexPeriod((prevBaseIndexPeriod) => {
                  if (!prevBaseIndexPeriod) return prevBaseIndexPeriod;
                  return {
                    ...prevBaseIndexPeriod,
                    quarter: e.target.value,
                  };
                });
              }}
              fullWidth
              error={errors.baseIndexPeriodByAccused ? true : false}
              helperText={errors.baseIndexPeriodByAccused?.message}
              select
              SelectProps={{
                MenuProps: {
                  sx: {
                    maxHeight: "20rem",
                  },
                },
              }}
            >
              <MenuItem value={"اول"}>اول</MenuItem>
              <MenuItem value={"دوم"}>دوم</MenuItem>
              <MenuItem value={"سوم"}>سوم</MenuItem>
              <MenuItem value={"چهارم"}>چهارم</MenuItem>
            </FaTextField>
            <FaTextField
              label="سال"
              type="number"
              sx={{
                gridColumn: "span 3",
              }}
              value={BaseIndexPeriod?.year || ""}
              onChange={(e) => {
                const baseIndexPeriod = {
                  ...BaseIndexPeriod,
                  year: e.target.value,
                } as BaseIndexPeriodType;
                setBaseIndexPeriod(baseIndexPeriod);
                setValue(
                  "baseIndexPeriodByAccused",
                  JSON.stringify(baseIndexPeriod)
                );
              }}
              error={errors.baseIndexPeriodByAccused ? true : false}
              helperText={errors.baseIndexPeriodByAccused?.message}
              select
              SelectProps={{
                MenuProps: {
                  sx: {
                    maxHeight: "20rem",
                  },
                },
              }}
            >
              {[
                "1370",
                "1371",
                "1372",
                "1373",
                "1374",
                "1375",
                "1376",
                "1377",
                "1378",
                "1379",
                "1380",
                "1381",
                "1382",
                "1383",
                "1384",
                "1385",
                "1386",
                "1387",
                "1388",
                "1389",
                "1390",
                "1391",
                "1392",
                "1393",
                "1394",
                "1395",
                "1396",
                "1397",
                "1398",
                "1399",
                "1400",
                "1401",
                "1402",
                "1403",
              ].map((y) => (
                <MenuItem value={y}>{y}</MenuItem>
              ))}
            </FaTextField>
          </>
        ) : (
          ""
        )}

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            تاريخ شروع كار
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <DatePicker
          value={
            watch("operationStartDateByAccused")
              ? new Date(watch("operationStartDateByAccused"))
              : undefined
          }
          onChange={(date) => {
            setValue("operationStartDateByAccused", date);
          }}
          className="col-span-3"
          label="تاريخ شروع كار "
        />

        <FileBox
          title={"مستندات مربوطه"}
          className="col-span-3"
          fileUrl={watch("operationStartDateByAccusedFileName") || ""}
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue(
                  "operationStartDateByAccusedFileName",
                  res.result?.[0]?.newFileName
                );
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            پیشرفت
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <TextField
          label="پيشرفت فيزيكی"
          InputProps={{
            endAdornment: "درصد",
          }}
          className="col-span-3"
          focused={
            watch("physicalProgressInArbitrationDateByAccused") ? true : false
          }
          type="number"
          value={watch("physicalProgressInArbitrationDateByAccused")}
          // onValueChange={(e) => {
          //   setValue(
          //     "physicalProgressInArbitrationDateByAccused",
          //     e.floatValue
          //   );
          // }}
          inputProps={{
            ...register("physicalProgressInArbitrationDateByAccused", {
              required: "پيشرفت فيزيكی اجباری است",
              setValueAs(value) {
                return parseFloat(value);
              },
              valueAsNumber: true,
            }),
          }}
          error={
            errors.physicalProgressInArbitrationDateByAccused ? true : false
          }
          helperText={
            errors.physicalProgressInArbitrationDateByAccused?.message
          }
        />

        <TextField
          label="پيشرفت ریالی"
          InputProps={{
            endAdornment: "درصد",
          }}
          className="col-span-3"
          value={watch("financialProgressInArbitrationDateByAccused")}
          type="number"
          inputProps={{
            ...register("financialProgressInArbitrationDateByAccused", {
              required: "پيشرفت مالی كار اجباری است",
              setValueAs(value) {
                return parseFloat(value);
              },
              valueAsNumber: true,
            }),
          }}
          focused={
            watch("financialProgressInArbitrationDateByAccused") ? true : false
          }
          error={
            errors.financialProgressInArbitrationDateByAccused ? true : false
          }
          helperText={
            errors.financialProgressInArbitrationDateByAccused?.message
          }
        />
        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            وضعیت قرارداد در تاریخ درخواست داوری
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <FormControl
          className="col-span-3 flex gap-5"
          sx={{
            justifyContent: "start",
            alignItems: "center",
            display: "flex",
            gap: 2,
          }}
        >
          <RadioGroup
            row
            sx={{
              width: "100%",
            }}
            className="flex justify-between w-full"
            value={watch("contractStatusAndDateInArbitrationByAccused") || ""}
            onChange={(e) => {
              setValue(
                "contractStatusAndDateInArbitrationByAccused",
                e.target.value
              );
            }}
          >
            <FormControlLabel
              value="ابلاغ خاتمه"
              control={<Radio />}
              label="ابلاغ خاتمه"
            />
            <FormControlLabel
              value="ابلاغ فسخ"
              control={<Radio />}
              label="ابلاغ فسخ"
            />
            <FormControlLabel value="جاری" control={<Radio />} label="جاری" />
            <FormControlLabel
              value="اتمام عملیات موضوع پیمان"
              control={<Radio />}
              label="اتمام عملیات موضوع پیمان"
            />
          </RadioGroup>
        </FormControl>

        <FileBox
          title={"مستندات مربوطه"}
          sx={{
            gridColumn: "span 2",
          }}
          fileUrl={
            watch("contractStatusAndDateInArbitrationByAccusedFirstFileName") ||
            ""
          }
          onFileChange={(f) => {
            void UPLOAD_FILE({
              file: f,
              token: token,
              onSuccess(res) {
                console.log(res);
                setValue(
                  "contractStatusAndDateInArbitrationByAccusedFirstFileName",
                  res.result?.[0]?.newFileName
                );
              },
              onFail(err) {
                console.log(err);
              },
            });
          }}
        />

        <FormGroup
          sx={{
            display:
              watch("contractStatusAndDateInArbitrationByAccused") ===
                "ابلاغ فسخ" ||
              watch("contractStatusAndDateInArbitrationByAccused") ===
                "ابلاغ خاتمه" ||
              watch("contractStatusAndDateInArbitrationByAccused") ===
                "اتمام عملیات موضوع پیمان"
                ? "grid"
                : "none",
            justifyContent: "space-evenly",
            alignItems: "flex-start",
            height: "100%",
          }}
          className="grid-cols-3 col-span-full w-full gap-5"
        >
          <div className="grid grid-cols-3 col-span-full gap-5 items-center">
            <FormControlLabel
              control={
                <Checkbox
                  onChange={(e) => {
                    setValue("tempDeliveryByAccused", e.target.checked);
                  }}
                />
              }
              label="تحویل موقت"
              value={watch("tempDeliveryByAccused")}
            />
            {watch("tempDeliveryByAccused") && (
              <DatePicker
                value={
                  watch("tempDeliveryDateByAccused")
                    ? new Date(watch("tempDeliveryDateByAccused"))
                    : undefined
                }
                onChange={(date) => {
                  setValue("tempDeliveryDateByAccused", date);
                }}
                slotProps={{
                  textField: {
                    fullWidth: true,
                  },
                }}
                label="تاریخ تحویل موقت"
              />
            )}
            {watch("tempDeliveryByAccused") && (
              <FileBox
                title={"مستندات مربوطه"}
                fileUrl={watch("tempDeliveryFileNameByAccused") || ""}
                onFileChange={(f) => {
                  void UPLOAD_FILE({
                    file: f,
                    token: token,
                    onSuccess(res) {
                      console.log(res);
                      setValue(
                        "tempDeliveryFileNameByAccused",
                        res.result?.[0]?.newFileName
                      );
                    },
                    onFail(err) {
                      console.log(err);
                    },
                  });
                }}
              />
            )}
          </div>

          <div className="grid grid-cols-3 col-span-full gap-5 items-center">
            <FormControlLabel
              control={
                <Checkbox
                  onChange={(e) => {
                    setValue("finalDeliveryByAccused", e.target.checked);
                  }}
                />
              }
              label="تحویل قطعی"
              value={watch("finalDeliveryByAccused")}
            />
            {watch("finalDeliveryByAccused") && (
              <DatePicker
                value={
                  watch("finalDeliveryDateByAccused")
                    ? new Date(watch("finalDeliveryDateByAccused"))
                    : undefined
                }
                onChange={(date) => {
                  setValue("finalDeliveryDateByAccused", date);
                }}
                slotProps={{
                  textField: {
                    fullWidth: true,
                  },
                }}
                label="تاریخ تحویل قطعی"
              />
            )}

            {watch("finalDeliveryByAccused") && (
              <FileBox
                title={"مستندات مربوطه"}
                fileUrl={watch("finalDeliveryFileNameByAccused") || ""}
                onFileChange={(f) => {
                  void UPLOAD_FILE({
                    file: f,
                    token: token,
                    onSuccess(res) {
                      console.log(res);
                      setValue(
                        "finalDeliveryFileNameByAccused",
                        res.result?.[0]?.newFileName
                      );
                    },
                    onFail(err) {
                      console.log(err);
                    },
                  });
                }}
              />
            )}
          </div>
        </FormGroup>

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            دستگاه نظارت (مهندس مشاور)
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <FaTextField
          label="عنوان دستگاه نظارت"
          className="col-span-full"
          value={watch("supervisionDepartmentByAccused") || ""}
          // onChange={(e) => {
          //   setValue("supervisionDepartmentByAccused", e.target.value);
          // }}
          fullWidth
          error={errors.supervisionDepartmentByAccused ? true : false}
          helperText={errors.supervisionDepartmentByAccused?.message}
          inputProps={{
            ...register("supervisionDepartmentByAccused", {
              required: "نام اجباری است",
            }),
          }}
        />
        <Box
          display={"grid"}
          gridTemplateColumns={"1fr 1fr 1fr 1fr"}
          gap={2}
          className="col-span-3"
          justifyContent={"center"}
          alignItems={"center"}
        >
          <div className="text col-span-full">فرد مطلع اول</div>
          <NumericFormat
            customInput={FaTextField}
            label="کد ملی"
            variant="outlined"
            sx={{
              gridColumn: "span 2",
            }}
            value={SupervisionDepartmentPersonnel1?.nationalCode}
            // type="number"
            maxLength={10}
            onValueChange={(e) => {
              setSupervisionDepartmentPersonnel1({
                ...SupervisionDepartmentPersonnel1,
                nationalCode: e.value,
              });
            }}
          />
          <FaTextField
            label="نام و نام خانوادگی"
            variant="outlined"
            sx={{
              gridColumn: "span 2",
            }}
            value={SupervisionDepartmentPersonnel1?.name}
            onChange={(e) => {
              setSupervisionDepartmentPersonnel1({
                ...SupervisionDepartmentPersonnel1,
                name: e.target.value,
              });
            }}
          />
          <div className="grid grid-cols-4 col-span-2 gap-1">
            <FaTextField
              label="تلفن ثابت"
              variant="outlined"
              sx={{
                gridColumn: "span 2",
              }}
              value={SupervisionDepartmentPersonnel1?.landLine}
              onChange={(e) => {
                setSupervisionDepartmentPersonnel1({
                  ...SupervisionDepartmentPersonnel1,
                  landLine: e.target.value,
                });
              }}
            />
            <FaTextField
              label="کد"
              variant="outlined"
              sx={{
                gridColumn: "span 2",
              }}
              select
              SelectProps={{
                MenuProps: {
                  sx: {
                    maxHeight: "400px",
                  },
                },
              }}
            >
              {Object.keys(cityCodes).map((i) => (
                <MenuItem value={cityCodes[i as cityCodeType].code}>
                  {cityCodes[i as cityCodeType].code}
                </MenuItem>
              ))}
            </FaTextField>
          </div>
          <FaTextField
            label="تلفن همراه"
            variant="outlined"
            type="number"
            sx={{
              gridColumn: "span 2",
            }}
            value={SupervisionDepartmentPersonnel1?.phone}
            onChange={(e) => {
              setSupervisionDepartmentPersonnel1({
                ...SupervisionDepartmentPersonnel1,
                phone: e.target.value,
              });
            }}
          />
          <FaTextField
            label="سمت"
            variant="outlined"
            sx={{
              gridColumn: "span 4",
            }}
            value={SupervisionDepartmentPersonnel1?.position}
            onChange={(e) => {
              setSupervisionDepartmentPersonnel1({
                ...SupervisionDepartmentPersonnel1,
                position: e.target.value,
              });
            }}
          />
        </Box>

        <Box
          display={"grid"}
          gridTemplateColumns={"1fr 1fr 1fr 1fr"}
          gap={2}
          className="col-span-3"
          justifyContent={"center"}
          alignItems={"center"}
        >
          <div className="text col-span-full">فرد مطلع دوم</div>
          <NumericFormat
            customInput={FaTextField}
            label="کد ملی"
            variant="outlined"
            sx={{
              gridColumn: "span 2",
            }}
            value={SupervisionDepartmentPersonnel2?.nationalCode}
            // type="number"
            maxLength={10}
            onValueChange={(e) => {
              setSupervisionDepartmentPersonnel2({
                ...SupervisionDepartmentPersonnel2,
                nationalCode: e.value,
              });
            }}
          />
          <FaTextField
            label="نام و نام خانوادگی"
            variant="outlined"
            sx={{
              gridColumn: "span 2",
            }}
            value={SupervisionDepartmentPersonnel2?.name}
            onChange={(e) => {
              setSupervisionDepartmentPersonnel2({
                ...SupervisionDepartmentPersonnel2,
                name: e.target.value,
              });
            }}
          />
          <div className="grid grid-cols-4 col-span-2 gap-1">
            <FaTextField
              label="تلفن ثابت"
              variant="outlined"
              sx={{
                gridColumn: "span 2",
              }}
              value={SupervisionDepartmentPersonnel2?.landLine}
              onChange={(e) => {
                setSupervisionDepartmentPersonnel2({
                  ...SupervisionDepartmentPersonnel2,
                  landLine: e.target.value,
                });
              }}
            />
            <FaTextField
              label="کد"
              variant="outlined"
              sx={{
                gridColumn: "span 2",
              }}
              select
              SelectProps={{
                MenuProps: {
                  sx: {
                    maxHeight: "400px",
                  },
                },
              }}
            >
              {Object.keys(cityCodes).map((i) => (
                <MenuItem value={cityCodes[i as cityCodeType].code}>
                  {cityCodes[i as cityCodeType].code}
                </MenuItem>
              ))}
            </FaTextField>
          </div>
          <FaTextField
            label="تلفن همراه"
            variant="outlined"
            sx={{
              gridColumn: "span 2",
            }}
            type="number"
            value={SupervisionDepartmentPersonnel2?.phone}
            onChange={(e) => {
              setSupervisionDepartmentPersonnel2({
                ...SupervisionDepartmentPersonnel2,
                phone: e.target.value,
              });
            }}
          />
          <FaTextField
            label="سمت"
            variant="outlined"
            sx={{
              gridColumn: "span 4",
            }}
            value={SupervisionDepartmentPersonnel2?.position}
            onChange={(e) => {
              setSupervisionDepartmentPersonnel2({
                ...SupervisionDepartmentPersonnel2,
                position: e.target.value,
              });
            }}
          />
        </Box>
        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <Typography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            تاخیرات {`(از نظر خوانده)`}
          </Typography>
          <Divider className="col-span-full w-full" />
        </div>

        <FaTextField
          label="تاخیرات مجاز"
          InputProps={{
            endAdornment: "روز",
          }}
          type="number"
          sx={{
            gridColumn: "span 3",
          }}
          focused={watch("authorizedDelaysByAccused") ? true : false}
          value={watch("authorizedDelaysByAccused")}
          inputProps={{
            ...register("authorizedDelaysByAccused", {
              required: "تاخیرات اجباری است",
              setValueAs(value) {
                return parseInt(value);
              },
              valueAsNumber: true,
            }),
          }}
          error={errors.authorizedDelaysByAccused ? true : false}
          helperText={errors.authorizedDelaysByAccused?.message}
        />

        <FaTextField
          label="تاخیرات غیر مجاز"
          InputProps={{
            endAdornment: "روز",
          }}
          sx={{
            gridColumn: "span 3",
          }}
          type="number"
          focused={watch("unauthorizedDelaysByAccused") ? true : false}
          value={watch("unauthorizedDelaysByAccused")}
          inputProps={{
            ...register("unauthorizedDelaysByAccused", {
              required: "تاخیرات اجباری است",
              setValueAs(value) {
                return parseInt(value);
              },
              valueAsNumber: true,
            }),
          }}
          error={errors.unauthorizedDelaysByAccused ? true : false}
          helperText={errors.unauthorizedDelaysByAccused?.message}
        />

        <div className="flex col-span-full p-5 box-border w-full overflow-hidden items-center mt-10 gap-5">
          <FaTypography
            variant="h5"
            textAlign={"center"}
            className="col-span-full whitespace-nowrap"
          >
            توجهات
          </FaTypography>
          <Divider className="col-span-full w-full" />
        </div>

        <FaTypography
          variant="body1"
          fontWeight={800}
          className="col-span-full"
        >
          توجه مهم: چنانچه در خصوص تاخیرات و یا تبعات ناشی از آن اختلافی وجود
          دارد، لازم است موارد زیر ارسال شوند:
        </FaTypography>

        <FaTypography
          variant="body2"
          fontWeight={800}
          className="col-span-full"
        >
          گزارش توجیهی تاخیرات قرارداد شامل:
        </FaTypography>

        <List
          sx={{
            padding: "1rem",
            border: "1px solid gray",
            borderRadius: 2,
          }}
          className="col-span-full"
        >
          <Box
            display={"flex"}
            justifyContent={"space-between"}
            paddingY={"1rem"}
          >
            <FaTypography variant="body1">
              برنامه های زمان‏بندی اولیه و اصلاحی ابلاغ شده
            </FaTypography>

            <div className="flex">
              <FileBox
                title="زمان بندی اولیه"
                fileUrl={watch("schedulesFileNameMainByAccused") || ""}
                onFileChange={(f) => {
                  void UPLOAD_FILE({
                    file: f,
                    token: token,
                    onSuccess(res) {
                      console.log(res);
                      setValue(
                        "schedulesFileNameMainByAccused",
                        res.result?.[0]?.newFileName
                      );
                    },
                    onFail(err) {
                      console.log(err);
                    },
                  });
                }}
              />
              <FileBox
                title="زمان بندی اصلاحی"
                fileUrl={watch("schedulesFileNameCorrectionByAccused") || ""}
                onFileChange={(f) => {
                  void UPLOAD_FILE({
                    file: f,
                    token: token,
                    onSuccess(res) {
                      console.log(res);
                      setValue(
                        "schedulesFileNameCorrectionByAccused",
                        res.result?.[0]?.newFileName
                      );
                    },
                    onFail(err) {
                      console.log(err);
                    },
                  });
                }}
              />
            </div>
          </Box>
          <Divider />
          <Box
            display={"flex"}
            justifyContent={"space-between"}
            paddingY={"1rem"}
          >
            <FaTypography variant="body1">
              گزارش تهیه شده توسط پیمانکار (به همراه کلیه مستندات و پیوست‏ها)
            </FaTypography>

            <FileBox
              title="مستندات مربوطه"
              fileUrl={watch("contractorReportFileNameByAccused") || ""}
              onFileChange={(f) => {
                void UPLOAD_FILE({
                  file: f,
                  token: token,
                  onSuccess(res) {
                    console.log(res);
                    setValue(
                      "contractorReportFileNameByAccused",
                      res.result?.[0]?.newFileName
                    );
                  },
                  onFail(err) {
                    console.log(err);
                  },
                });
              }}
            />
          </Box>
          <Divider />

          <Box
            display={"flex"}
            justifyContent={"space-between"}
            paddingY={"1rem"}
          >
            <FaTypography variant="body1">
              گزارش رسیدگی به تاخیرات توسط مهندس مشاور
            </FaTypography>

            <FileBox
              title="مستندات مربوطه"
              fileUrl={watch("delayHandlingReportFileNameByAccused") || ""}
              onFileChange={(f) => {
                void UPLOAD_FILE({
                  file: f,
                  token: token,
                  onSuccess(res) {
                    console.log(res);
                    setValue(
                      "delayHandlingReportFileNameByAccused",
                      res.result?.[0]?.newFileName
                    );
                  },
                  onFail(err) {
                    console.log(err);
                  },
                });
              }}
            />
          </Box>
          <Divider />

          <Box
            display={"flex"}
            justifyContent={"space-between"}
            paddingY={"1rem"}
          >
            <FaTypography variant="body1">
              مستندات ابلاغ نتایج رسیدگی به تاخیرات به پیمانکار توسط کارفرما
            </FaTypography>
            <FileBox
              title="مستندات مربوطه"
              fileUrl={watch("delayHandlingResultFileNameByAccused") || ""}
              onFileChange={(f) => {
                void UPLOAD_FILE({
                  file: f,
                  token: token,
                  onSuccess(res) {
                    console.log(res);
                    setValue(
                      "delayHandlingResultFileNameByAccused",
                      res.result?.[0]?.newFileName
                    );
                  },
                  onFail(err) {
                    console.log(err);
                  },
                });
              }}
            />
          </Box>
        </List>
        {isValid && (
          <FaTypography variant="body1" className="col-span-full">
            {/*  */}✅ تمامی اقلام اطلاعاتی لازم تکمیل شده‌اند
          </FaTypography>
        )}
        <button
          className="col-span-full rounded-full bg-primary-500 w-fit place-self-end shadow-none border-none px-10 py-3 text-lg cursor-pointer disabled:opacity-50"
          type="submit"
        >
          ثبت و ادامه
        </button>
        {loading && <LinearProgress />}
        {catchError && (
          <FaTypography variant="body1" color="error" className="col-span-full">
            {catchError}
          </FaTypography>
        )}

        {/* {Object.values(errors).map((error) => (
          <FaTypography variant="body1" color="error">
            {error.message}
          </FaTypography>
        ))} */}
      </div>
    </form>
  );
};

export default NewContractPagesAccused;
