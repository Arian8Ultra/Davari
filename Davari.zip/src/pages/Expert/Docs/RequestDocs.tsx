/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import {
  Add,
  CancelRounded,
  CheckBoxRounded,
  Delete,
} from "@mui/icons-material";
import {
  Box,
  Button,
  Checkbox,
  Divider,
  LinearProgress,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import React, { useMemo } from "react";
import { useParams } from "react-router-dom";
import {
  ComplaintStateStatus,
  DocType,
  useAddDocsRequestMutationMutation,
  useDeleteRequestedDocMutationMutation,
  useGenerateAccusedDocsRequestLetterMutation,
  useGetArgumentsWithFilterQuery,
  useGetComplaintsWithFilterQuery,
  useGetContractQuery,
  useGetCorrectionRequestsFullQueryQuery,
  useGetReqestedDocsQueryQuery,
  useGetTestFetchLetterQuery,
  useGetUserWithFilterLazyQuery,
  useSendDocumentRequestSmsMutation,
  useUpdateComplaintFullMutation,
} from "../../../../generated-types";
import { useUserStore } from "../../../Context/UserStore";
import ArgumentInfoModal from "../../../components/Arguments/ArgumentInfoModal";
import { getComplaintStateWithEnum } from "../../../functions/ComplaintStatesFunc";
import { ComplaintArgument, TargetType } from "../../../gql/graphql";
import {
  Green,
  Red,
  RedLight,
  background,
  primary,
  secondary,
  secondaryDark,
} from "../../../theme/color";
import { ContractSmall } from "../../../GraphQL/Contracts/Mutations";
import { convertToPersianDigitsWithComma } from "../../../functions/Functions";
import { ToWords } from "to-words";
import { API_FILE_DOWNLOAD } from "../../../../config";

const RequestDocs = () => {
  const { complaintId } = useParams<{ complaintId: string }>();
  const user = useUserStore((state) => state.user);
  const [infoModal, setInfoModal] = React.useState<{
    open: boolean;
    argument?: ComplaintArgument;
  }>({
    open: false,
  });

  const [requestedDoc, setRequestedDoc] = React.useState<string>();
  const [requestedFileType, setRequestedFileType] = React.useState<DocType>(
    DocType.File
  );
  const [requestedDocType, setRequestedDocType] = React.useState<TargetType>();

  const { data: ArgumentsData } = useGetArgumentsWithFilterQuery({
    variables: {
      filter: {
        complaintId: {
          eq: parseInt(complaintId || "") || 0,
        },
      },
    },
    onCompleted(data) {
      console.log(data);
    },
  });

  const { data: complaint } = useGetComplaintsWithFilterQuery({
    variables: {
      filter: {
        id: { eq: parseInt(complaintId || "") || 0 },
      },
    },
    onCompleted() {
      void GetAccuser();
      void GetAccused();
    },
  });

  const { data: fetchLetter } = useGetTestFetchLetterQuery({
    variables:{
      letterId: "1"
    }
  });
  const { data } = useGetContractQuery({
    variables: {
      id:
        complaint?.complaint_getComplaints?.result?.items?.[0]?.contractId || 0,
    },
    onCompleted(data) {
      console.log("Contract", data.contract_getContracts.result?.items?.[0]);
    },
  });

  const contract = useMemo(() => {
    return data?.contract_getContracts.result?.items?.[0];
  }, [data]);

  const { data: requestedDocsData, refetch: requestedDocsRefetch } =
    useGetReqestedDocsQueryQuery({
      variables: {
        filter: {
          complaintId: {
            eq: parseInt(complaintId || "") || 0,
          },
        },
      },
    });

  const { data: correctionRequests } = useGetCorrectionRequestsFullQueryQuery({
    variables: {
      filter: {
        complaintId: {
          eq: parseInt(complaintId || "") || 0,
        },
      },
    },
  });

  const [addDoc] = useAddDocsRequestMutationMutation({
    variables: {
      input: {
        complaintId: parseInt(complaintId || "") || 0,
        requestedDocumentName: requestedDoc || "",
        userId: user.id || "",
        target: requestedDocType || TargetType.Both,
        docType: requestedFileType,
      },
    },
    onCompleted() {
      void requestedDocsRefetch();
    },
  });

  const [deleteDoc] = useDeleteRequestedDocMutationMutation({
    onCompleted() {
      void requestedDocsRefetch();
    },
  });

  const [GetAccuser, { data: AccuserData }] = useGetUserWithFilterLazyQuery({
    variables: {
      filter: {
        id: {
          eq: complaint?.complaint_getComplaints.result?.items?.[0]?.contract
            ?.accuserDepartmentUserId,
        },
      },
    },
  });

  const [GetAccused, { data: AccusedData }] = useGetUserWithFilterLazyQuery({
    variables: {
      filter: {
        id: {
          eq: complaint?.complaint_getComplaints.result?.items?.[0]?.contract
            ?.accusedDepartmentUserId,
        },
      },
    },
  });

  const [updateComplaint, { loading }] = useUpdateComplaintFullMutation();
  const toWords = new ToWords({
    localeCode: "fa-IR",
  });
  type BaseIndexPeriodType = {
    isQuarter: boolean;
    quarter: string;
    month: string;
    year: string;
  };

  const [SendDocumentRequestSMS] = useSendDocumentRequestSmsMutation({
    variables:{
      complaintId: parseInt(complaintId || "") || 0,
    }
  })

  const [GenerateAccusedDocsRequestLetter] = useGenerateAccusedDocsRequestLetterMutation({
    variables:{
      input:{
        complaintId: parseInt(complaintId || "") || 0,
        userId: user.id || "",
        previousLetterDate: new Date().toDateString(),
        previousLetterNum: "123123213sadas",
      }
    }
  })

  const firstConditionItems = ["عمرانی (تملک دارایی سرمایه ای)", "غیرعمرانی"];
  const secondConditionItems = [
    "در ماده حل اختلاف قرارداد، داوری شورای عالی فنی درج شده است.",
    "طرفین پس از عقد قرارداد، بر داوری شورا تراضی نموده اند.",
    "فاقد تراضی روی داوری شورا در حین قرارداد یا پس از آن.",
  ];

  const thirdConditionItems = [
    "صورتحساب نهایی توسط پیمانکار امضا نشده است.",
    "صورتحساب نهایی بدون امضای پیمانکار، به پیمانکار ابلاغ شده است؛ اما پیمانکار ظرف مهلت مقرر در قرارداد به آن اعتراض نموده است.",
    "صورتحساب نهایی توسط پیمانکار امضا شده است اما صرفا دعاوی مربوط به آزادسازی ضمانتنامه ها مورد درخواست است.",
    "هیچ یک از موارد فوق.",
  ];

  const fourthConditionItems = [
    "رای قطعی در خصوص دعاوی مورد درخواست توسط مراجع قضایی و شورا صادر نشده است.",
    "رای قطعی در خصوص دعاوی مورد درخواست توسط مراجع قضایی صادر شده است.",
    "رای قطعی در خصوص دعاوی مورد درخواست توسط شورا صادر شده است.",
    "قرار عدم صلاحیت (استماع) توسط مراجع قضایی صادر شده است.",
  ];
  //   const
  return (
    <>
      <ArgumentInfoModal
        open={infoModal.open}
        handleClose={() => setInfoModal({ ...infoModal, open: false })}
        fullArgument={infoModal.argument}
        state={-2}
      />
      <Box
        display={"flex"}
        justifyContent={"center"}
        alignItems={"center"}
        flexDirection={"column"}
        position={"relative"}
        className="my-4"
      >
        <Box
          borderRadius={"3rem"}
          sx={{
            background: primary,
            padding: "0.5rem 1rem",
            userSelect: "none",
            width: "max-content",
            justifySelf: "center",
            zIndex: 1000,
          }}
        >
          <Typography variant={"h6"} sx={{ color: secondary }}>
            مشخصات قرارداد
          </Typography>
        </Box>
        <Divider
          sx={{
            width: "100%",
            backgroundColor: secondary,
            height: "0.2rem",
            margin: "1rem 0",
            position: "absolute",
          }}
        />
      </Box>
      <div className="rounded-lg overflow-hidden shadow-xl mb-4">

        <TableContainer
          className="rounded-lg first:bg-gray-10"
          sx={{
            gridColumn: "1 / span 12",
            m: 0,
            // outline: "2px solid #000",
            // change the table head background color
            // borderRadius: "0.5rem",
            // border:'none',
            "& .MuiTableCell-head": {
              backgroundColor: background,
              // color: primary,
              // outline: `1px solid ${primary}`,
            },
            // give each cell border
            "& .MuiTableCell-root": {
              // border: `1px solid ${secondary}`,
              padding: 1,
            },

            // change the color of first column
            "& .MuiTableCell-body:first-child": {
              backgroundColor: "white",
              // outline: `1px solid ${primary}`,
              borderRight: `1px solid ${secondary}`,
              color: secondaryDark,
              fontWeight: "bold",
            },
          }}
        >
          <Table>
            <TableHead className="bg-white-100 *:font-bold">
              <TableRow className="*:font-bold *:p-2">
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "20%",
                    minHeight: "max-content",
                  }}
                >
                  عنوان
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "40%",
                  }}
                >
                  خواهان
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    width: "40%",
                  }}
                >
                  خوانده
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  عنوان قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractSubjectByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractSubjectByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  شناسه قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractNumberByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractNumberByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  تاریخ انعقاد قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractDateByAccuser
                    ? new Date(
                        contract.contractDateByAccuser
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractDateByAccused
                    ? new Date(
                        contract.contractDateByAccused
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  مبلغ اوليه/ حق‌الزحمه قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {convertToPersianDigitsWithComma(
                    contract?.initialBudgetByAccuser || "-"
                  )}{" "}
                  - {toWords.convert(contract?.initialBudgetByAccuser || 0)}{" "}
                  {contract?.currencyByAccuser}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {convertToPersianDigitsWithComma(
                    contract?.initialBudgetByAccused || "-"
                  )}{" "}
                  - {toWords.convert(contract?.initialBudgetByAccused || 0)}{" "}
                  {contract?.currencyByAccused}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  مدت اوليه قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.initialTimePeriodByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.initialTimePeriodByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  طرفین قرارداد
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {AccuserData?.user_getUsers.result?.items?.[0]?.fullName}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {AccusedData?.user_getUsers.result?.items?.[0]?.fullName}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل موافقتنامه
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.agreementFileNameByAccuser ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.agreementFileNameByAccuser &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.agreementFileNameByAccuser}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.agreementFileNameByAccused ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.agreementFileNameByAccused &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.agreementFileNameByAccused}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل شرایط عمومی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.generalConditionsFileNameByAccuser ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.generalConditionsFileNameByAccuser &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.generalConditionsFileNameByAccuser}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.generalConditionsFileNameByAccused ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.generalConditionsFileNameByAccused &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.generalConditionsFileNameByAccused}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل شرایط خصوصی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.privateTermsFileNameByAccuser ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.privateTermsFileNameByAccuser &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.privateTermsFileNameByAccuser}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.privateTermsFileNameByAccused ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.privateTermsFileNameByAccused &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.privateTermsFileNameByAccused}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  محل ثبت شرکت
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accuserNationality || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accusedNationality || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نمایندگان(وکلا)( از طرف خواهان)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accuserRelatedPeopleByAccuser &&
                    JSON.parse(contract?.accuserRelatedPeopleByAccuser)?.map?.(
                      (
                        item: {
                          name: string;
                          phone: string;
                          position: string;
                          nationalCode: string;
                        },
                        index: React.Key | null | undefined
                      ) => (
                        <div key={index} className="flex flex-col gap-2">
                          <div className="text">
                            نام و نام خانوادگی: {item.name}
                          </div>
                          <div className="text">شماره تماس: {item.phone}</div>
                          <div className="text">
                            کد ملی: {item.nationalCode}
                          </div>
                        </div>
                      )
                    )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accuserRelatedPeopleByAccused &&
                    JSON.parse(contract?.accuserRelatedPeopleByAccused)?.map?.(
                      (
                        item: {
                          name: string;
                          phone: string;
                          position: string;
                          nationalCode: string;
                        },
                        index: React.Key | null | undefined
                      ) => (
                        <div key={index} className="flex flex-col gap-2">
                          <div className="text">
                            نام و نام خانوادگی: {item.name}
                          </div>
                          <div className="text">شماره تماس: {item.phone}</div>
                          <div className="text">
                            کد ملی: {item.nationalCode}
                          </div>
                        </div>
                      )
                    )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نمایندگان(وکلا)( از طرف خوانده)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accusedRelatedPeopleByAccuser
                    ? JSON.parse(
                        contract?.accusedRelatedPeopleByAccuser
                      )?.map?.(
                        (
                          item: {
                            name: string;
                            phone: string;
                          },
                          index: React.Key | null | undefined
                        ) => (
                          <Box key={index} display={"flex"}>
                            {item.name}
                            {item.phone}
                          </Box>
                        )
                      )
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.accusedRelatedPeopleByAccused
                    ? JSON.parse(
                        contract?.accusedRelatedPeopleByAccused
                      )?.map?.(
                        (
                          item: {
                            name: string;
                            phone: string;
                          },
                          index: React.Key | null | undefined
                        ) => (
                          <Box key={index} display={"flex"}>
                            {item.name}
                            {item.phone}
                          </Box>
                        )
                      )
                    : "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  ضريب پيشنهادی
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.recommendedCoefficientByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.recommendedCoefficientByAccused || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  تعدیل
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.doesContainAdjustmentByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.doesContainAdjustmentByAccused || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  نوع دوره شاخص مبنا
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.baseIndexPeriodByAccuser
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccuser
                        ) as BaseIndexPeriodType
                      ).isQuarter
                      ? "سه ماهه"
                      : "ماهانه"
                    : "-"}
                  {contract?.baseIndexPeriodByAccuser
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccuser
                        ) as BaseIndexPeriodType
                      ).month ||
                      (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccuser
                        ) as BaseIndexPeriodType
                      ).quarter
                    : "-"}{" "}
                  {contract?.baseIndexPeriodByAccuser
                    ? JSON.parse(contract?.baseIndexPeriodByAccuser).year
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.baseIndexPeriodByAccused
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccused
                        ) as BaseIndexPeriodType
                      ).isQuarter
                      ? "سه ماهه"
                      : "ماهانه"
                    : "-"}{" "}
                  {" -"}
                  {contract?.baseIndexPeriodByAccused
                    ? (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccused
                        ) as BaseIndexPeriodType
                      ).month ||
                      (
                        JSON.parse(
                          contract?.baseIndexPeriodByAccused
                        ) as BaseIndexPeriodType
                      ).quarter
                    : "-"}{" "}
                  {contract?.baseIndexPeriodByAccuser
                    ? JSON.parse(contract?.baseIndexPeriodByAccuser).year
                    : "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  تاريخ شروع كار
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.operationStartDateByAccuser
                    ? new Date(
                        contract.operationStartDateByAccuser
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.operationStartDateByAccused
                    ? new Date(
                        contract.operationStartDateByAccused
                      ).toLocaleDateString("fa-IR")
                    : "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  فایل تاريخ شروع كار
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.operationStartDateByAccuserFileName ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.operationStartDateByAccuserFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.operationStartDateByAccuserFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.operationStartDateByAccused !=
                      contract?.operationStartDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.operationStartDateByAccusedFileName ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.operationStartDateByAccusedFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.operationStartDateByAccusedFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.physicalProgressInArbitrationDateByAccused !=
                      contract?.physicalProgressInArbitrationDateByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  پيشرفت فيزيكي كار در تاريخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.physicalProgressInArbitrationDateByAccused !=
                      contract?.physicalProgressInArbitrationDateByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.physicalProgressInArbitrationDateByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.physicalProgressInArbitrationDateByAccused !=
                      contract?.physicalProgressInArbitrationDateByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.physicalProgressInArbitrationDateByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.financialProgressInArbitrationDateByAccused !=
                      contract?.financialProgressInArbitrationDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  پيشرفت ریالی كار در تاريخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.financialProgressInArbitrationDateByAccused !=
                      contract?.financialProgressInArbitrationDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.financialProgressInArbitrationDateByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.financialProgressInArbitrationDateByAccused !=
                      contract?.financialProgressInArbitrationDateByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.financialProgressInArbitrationDateByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.contractStatusAndDateInArbitrationByAccuser !=
                      contract?.contractStatusAndDateInArbitrationByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  وضعیت قرارداد در تاریخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccuser?.includes(
                    "ابلاغ خاتمه"
                  )
                    ? "ابلاغ خاتمه"
                    : contract?.contractStatusAndDateInArbitrationByAccuser?.includes(
                        "ابلاغ فسخ"
                      )
                    ? "ابلاغ فسخ"
                    : contract?.contractStatusAndDateInArbitrationByAccuser?.includes(
                        "جاری"
                      )
                    ? "جاری"
                    : "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.contractStatusAndDateInArbitrationByAccuser !=
                      contract?.contractStatusAndDateInArbitrationByAccused
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccused?.includes(
                    "ابلاغ خاتمه"
                  )
                    ? "ابلاغ خاتمه"
                    : contract?.contractStatusAndDateInArbitrationByAccused?.includes(
                        "ابلاغ فسخ"
                      )
                    ? "ابلاغ فسخ"
                    : contract?.contractStatusAndDateInArbitrationByAccused?.includes(
                        "جاری"
                      )
                    ? "جاری"
                    : "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فایل وضعیت قرارداد در تاریخ درخواست داوری
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccuserFirstFileName ? (
                    // a button to donwload the file
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.contractStatusAndDateInArbitrationByAccuserFirstFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.contractStatusAndDateInArbitrationByAccuserFirstFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.contractStatusAndDateInArbitrationByAccusedFirstFileName ? (
                    // a button to donwload the file
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => {
                        contract?.contractStatusAndDateInArbitrationByAccusedFirstFileName &&
                          window.open(
                            `${API_FILE_DOWNLOAD}${contract?.contractStatusAndDateInArbitrationByAccusedFirstFileName}`,
                            "_blank"
                          );
                      }}
                    >
                      دانلود
                    </Button>
                  ) : (
                    "-"
                  )}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.supervisionDepartmentByAccused !=
                      contract?.supervisionDepartmentByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  دستگاه نظارت (مهندس مشاور)
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.supervisionDepartmentByAccused !=
                      contract?.supervisionDepartmentByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.supervisionDepartmentByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.supervisionDepartmentByAccused !=
                      contract?.supervisionDepartmentByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.supervisionDepartmentByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.authorizedDelaysByAccused !=
                      contract?.authorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  تاخیرات مجاز
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.authorizedDelaysByAccused !=
                      contract?.authorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.authorizedDelaysByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.authorizedDelaysByAccused !=
                      contract?.authorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.authorizedDelaysByAccused || "-"}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.unauthorizedDelaysByAccused !=
                      contract?.unauthorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  تاخیرات غیر مجاز
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.unauthorizedDelaysByAccused !=
                      contract?.unauthorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.unauthorizedDelaysByAccuser || "-"}
                </TableCell>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor:
                      contract?.unauthorizedDelaysByAccused !=
                      contract?.unauthorizedDelaysByAccuser
                        ? RedLight
                        : "transparent",
                  }}
                >
                  {contract?.unauthorizedDelaysByAccused || "-"}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor: secondary,
                    color: primary,
                  }}
                  colSpan={3}
                >
                  سامانه قرارداد ها
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  محل تامین اعتبار
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {contract?.sourceOfFundingTitle}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                    backgroundColor: secondary,
                    color: primary,
                  }}
                  colSpan={3}
                >
                  نامه امور
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  خلاصه پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.summary}
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  توضیحات پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.comment}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  شماره پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.letterNum}
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell
                  sx={{
                    textAlign: "center",
                  }}
                >
                  فرستنده پاسخ نامه امور
                </TableCell>
                <TableCell
                  colSpan={2}
                  sx={{
                    textAlign: "center",
                  }}
                >
                  {fetchLetter?.letter_fetchLetter?.result?.senderFullName}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      {/* 







      */}
      <Box
        display={"flex"}
        justifyContent={"center"}
        alignItems={"center"}
        flexDirection={"column"}
        position={"relative"}
      >
        <div className="text gap-4 my-4 text-center w-full text-black-100 underline underline-offset-4">
          صرفا طی یک مرحله می¬توانید درخواست مدارک انجام دهید
        </div>
        <Box
          borderRadius={"3rem"}
          sx={{
            background: primary,
            padding: "0.5rem 1rem",
            userSelect: "none",
            width: "max-content",
            justifySelf: "center",
            zIndex: 1000,
          }}
        >
          <Typography variant={"h6"} sx={{ color: secondary }}>
            دعاوی مرتبط
          </Typography>
        </Box>
        <Divider
          sx={{
            width: "100%",
            backgroundColor: secondary,
            height: "0.2rem",
            margin: "1rem 0",
            position: "absolute",
          }}
        />
      </Box>

      <div className="rounded-lg overflow-hidden shadow-xl my-4">
        <TableContainer
          className="rounded-lg first:bg-gray-10"
          sx={{
            gridColumn: "1 / span 12",
            m: 0,
            // outline: "2px solid #000",
            // change the table head background color
            // borderRadius: "0.5rem",
            // border:'none',
            "& .MuiTableCell-head": {
              backgroundColor: background,
              // color: primary,
              // outline: `1px solid ${primary}`,
            },
            // give each cell border
            "& .MuiTableCell-root": {
              // border: `1px solid ${secondary}`,
              padding: 1,
            },

            // change the color of first column
            "& .MuiTableCell-body:first-child": {
              backgroundColor: "white",
              // outline: `1px solid ${primary}`,
              borderRight: `1px solid ${secondary}`,
              color: secondaryDark,
              fontWeight: "bold",
            },
          }}
        >
          <Table
            sx={{
              // backgroundColor: primaryGreyLightTransparent,
              borderRadius: "0.5rem",
            }}
          >
            <TableHead
              sx={{
                background: secondaryDark,
                fontWeight: "bold",
                borderRadius: "0.5rem",
                color: "white",
                "& th": {
                  textAlign: "center",
                },
              }}
            >
              <TableRow>
                <TableCell
                  sx={{
                    fontWeight: "bold",
                  }}
                >
                  شناسه
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bold",
                  }}
                >
                  خلاصه ادعا
                </TableCell>
                {/* <TableCell
                sx={{
                  fontWeight: "bold",
                  color: "white",
                }}
              >
                لایحه دفاعیه
              </TableCell> */}
                <TableCell
                  sx={{
                    fontWeight: "bold",
                  }}
                >
                  مبلغ خواسته شده ادعا(ریال)
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: "bold",
                  }}
                >
                  ...
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody
              sx={{
                // delete padding of cells
                "& td": {
                  padding: "0.5rem",
                  borderBottom: `1px solid ${secondary}`,
                  borderRight: `1px solid ${secondary}`,
                },
                // add border to first column
                "& td:first-child": {
                  borderRight: `1px solid ${secondary}`,
                  width: "max-content",
                },
                // add border to last column
                "& td:last-child": {
                  borderLeft: `1px solid ${secondary}`,
                  borderRight: `0px solid ${secondary}`,
                },
              }}
            >
              {ArgumentsData?.complaintArgument_getComplaintArguments?.result?.items?.map(
                (item) => (
                  <TableRow>
                    <TableCell
                      sx={{
                        textAlign: "center",
                      }}
                    >
                      {item?.id}
                    </TableCell>
                    <TableCell
                      sx={{
                        textAlign: "center",
                      }}
                    >
                      {item?.summary}
                    </TableCell>
                    <TableCell
                      sx={{
                        textAlign: "center",
                      }}
                    >
                      {convertToPersianDigitsWithComma(item?.suggestedAmount)}
                    </TableCell>
                    <TableCell
                      sx={{
                        textAlign: "center",
                      }}
                    >
                      <Button
                        variant={"text"}
                        fullWidth
                        // sx={{
                        //   backgroundColor: secondaryDark,
                        //   color: "white",
                        //   "&:hover": {
                        //     backgroundColor: secondary,
                        //   },
                        // }}
                        onClick={() =>
                          setInfoModal({ open: true, argument: item })
                        }
                      >
                        مشاهده جزئیات
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </div>
      <Box
        display={"flex"}
        justifyContent={"center"}
        alignItems={"center"}
        flexDirection={"column"}
        position={"relative"}
      >
        <Box
          borderRadius={"3rem"}
          sx={{
            background: primary,
            padding: "0.5rem 1rem",
            userSelect: "none",
            width: "max-content",
            justifySelf: "center",
            zIndex: 1000,
          }}
        >
          <Typography variant={"h6"} sx={{ color: secondary }}>
            مستندات مورد نیاز
          </Typography>
        </Box>
        <Divider
          sx={{
            width: "100%",
            backgroundColor: secondary,
            height: "0.2rem",
            margin: "1rem 0",
            position: "absolute",
          }}
        />
      </Box>
      <Box
        sx={{
          borderRadius: "0.5rem",
          outline: `2px solid ${secondary}`,
          backgroundColor: "rgb(220,220,220)",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
          justifyContent: "center",
          my: "2rem",
          overflow: "hidden",
          width: "100%",
          mx: "auto",
        }}
      >
        <Table
          sx={{
            // backgroundColor: primaryGreyLightTransparent,
            borderRadius: "0.5rem",
          }}
        >
          <TableHead
            sx={{
              background: secondary,
              borderRadius: "0.5rem",
              color: "white",
              "& th": {
                textAlign: "center",
              },
            }}
          >
            <TableRow>
              {/* <TableCell
                sx={{
                  fontWeight: "bold",
                  color: "white",
                }}
              >
                درخواست مستند / پرسش 
              </TableCell> */}
              <TableCell
                sx={{
                  fontWeight: "bold",
                  color: "white",
                }}
              >
                عنوان مستند / طرح پرسش
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                  color: "white",
                }}
              >
                برای
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                  color: "white",
                }}
              >
                ...
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody
            sx={{
              // delete padding of cells
              "& td": {
                padding: "0.5rem",
                borderBottom: `1px solid ${secondary}`,
                borderRight: `1px solid ${secondary}`,
              },
              // add border to first column
              "& td:first-child": {
                borderRight: `1px solid ${secondary}`,
                width: "max-content",
              },
              // add border to last column
              "& td:last-child": {
                borderLeft: `1px solid ${secondary}`,
                borderRight: `0px solid ${secondary}`,
              },
            }}
          >
            <TableRow>
              {/* <TableCell
                sx={{
                  textAlign: "center",
                  width: "20%",
                }}
              >

                <TextField
                  label={"مستند / پرسش"}
                  variant={"outlined"}
                  fullWidth
                  value={requestedFileType}
                  onChange={(e) => {
                    setRequestedFileType(e.target.value as DocType);
                  }}
                  select
                >
                  {["پرسش", "مستند"].map((item) => (
                    <MenuItem
                      value={item === "پرسش" ? DocType.Text : DocType.File}
                    >
                      {item}
                    </MenuItem>
                  ))}
                </TextField>
              </TableCell> */}

              <TableCell
                sx={{
                  textAlign: "center",
                }}
              >
                <TextField
                  variant={"outlined"}
                  fullWidth
                  value={requestedDoc}
                  onChange={(e) => setRequestedDoc(e.target.value)}
                />
              </TableCell>
              <TableCell
                sx={{
                  textAlign: "center",
                  width: "20%",
                }}
              >
                <TextField
                  variant={"outlined"}
                  fullWidth
                  value={requestedDoc}
                  onChange={(e) => {
                    if (e.target.value === "خوانده") {
                      setRequestedDocType(TargetType.Accused);
                    } else if (e.target.value === "خواهان") {
                      setRequestedDocType(TargetType.Accuser);
                    } else {
                      setRequestedDocType(TargetType.Both);
                    }
                  }}
                  select
                >
                  {["خوانده", "خواهان", "هردو"].map((item) => (
                    <MenuItem value={item}>{item}</MenuItem>
                  ))}
                </TextField>
              </TableCell>

              <TableCell
                sx={{
                  textAlign: "center",
                  width: "20%",
                }}
              >
                <Button
                  variant={"contained"}
                  sx={{
                    backgroundColor: Green,
                    ":hover": {
                      backgroundColor: primary,
                    },
                  }}
                  fullWidth
                  onClick={() => {
                    void addDoc();
                  }}
                >
                  <Add />
                  افزودن
                </Button>
              </TableCell>
            </TableRow>
            {requestedDocsData?.documentRequest_getDocumentRequests.result?.items?.map(
              (item) => (
                <TableRow>
                  {/* <TableCell
                    sx={{
                      textAlign: "center",
                    }}
                  >
                    {item?.docType === DocType.File ? "فایلی" : "متنی"}
                  </TableCell> */}
                  <TableCell
                    sx={{
                      textAlign: "center",
                    }}
                  >
                    {item?.requestedDocumentName}
                  </TableCell>
                  <TableCell
                    sx={{
                      textAlign: "center",
                    }}
                  >
                    {item?.target === TargetType.Accuser
                      ? "خواهان"
                      : item?.target === TargetType.Accused
                      ? "خوانده"
                      : "هردو"}
                  </TableCell>
                  <TableCell
                    sx={{
                      textAlign: "center",
                    }}
                  >
                    <Button
                      variant={"contained"}
                      sx={{
                        backgroundColor: Red,
                        ":hover": {
                          backgroundColor: primary,
                        },
                      }}
                      onClick={() => {
                        void deleteDoc({
                          variables: {
                            id: item?.id || 0,
                          },
                        });
                      }}
                    >
                      <Delete />
                      حذف
                    </Button>
                  </TableCell>
                </TableRow>
              )
            )}
          </TableBody>
        </Table>
      </Box>
      <Box display={"flex"} justifyContent={"flex-end"} my={2}>
        {loading && <Typography>در حال ثبت اطلاعات</Typography>}
        {loading && <LinearProgress sx={{ width: "100%" }} />}
        <Button
          variant={"contained"}
          sx={{
            backgroundColor: primary,
            padding: "0.5rem 2rem",
            borderRadius: "3rem",
            color: secondary,
            fontSize: "1.2rem",
            "&:hover": {
              backgroundColor: secondary,
              color: primary,
            },
          }}
          onClick={() => {
            const agree = confirm("آیا از ثبت نهایی اطلاعات اطمینان دارید؟");
            if (agree) {
              void updateComplaint({
                variables: {
                  input: {
                    complaintStateId: getComplaintStateWithEnum(
                      ComplaintStateStatus.UploadingDocumentsByAccuser
                    ).id,
                    id: parseInt(complaintId || "") || 0,
                  },
                },
                onCompleted() {
                  window.location.href = "/expertPortal";
                  void SendDocumentRequestSMS()
                  // void GenerateAccusedDocsRequestLetter()
                },
              });
            }
          }}
        >
          ثبت و تایید نهایی
        </Button>
      </Box>
    </>
  );
};

export default RequestDocs;
