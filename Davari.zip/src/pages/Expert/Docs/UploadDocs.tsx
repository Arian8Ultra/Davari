/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  Box,
  Button,
  Divider,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from "@mui/material";
import { useNavigate, useParams } from "react-router-dom";
import {
  useGetComplaintsWithFilterQuery,
  useGetReqestedDocsQueryLazyQuery,
  useGetReqestedDocsQueryQuery,
  useGetUserWithFilterLazyQuery,
  useSendDocumentRequestResponseSmsMutation,
  useUpdateComplaintFullMutation,
} from "../../../../generated-types";
import { useUserStore } from "../../../Context/UserStore";
import UploadDocCard from "../../../components/Docs/UploadDocCard";
import { getComplaintStateWithEnum } from "../../../functions/ComplaintStatesFunc";
import {
  ComplaintStateStatus,
  RegistrarType,
  TargetType,
} from "../../../gql/graphql";
import { primary, secondary } from "../../../theme/color";
import { useForm } from "react-hook-form";
import DocCard from "../../../components/Docs/DocCard";

const UploadDocs = () => {
  const { complaintId } = useParams<{ complaintId: string }>();
  const user = useUserStore((state) => state.user);
  const navigate = useNavigate();
  const { data: complaint } = useGetComplaintsWithFilterQuery({
    variables: {
      filter: {
        id: { eq: parseInt(complaintId || "") || 0 },
      },
    },
    onCompleted() {
      void GetAccuser();
      void GetAccused();
    },
  });
  const [updateComplaint, { loading }] = useUpdateComplaintFullMutation();

  const [GetAccuser, { data: AccuserData }] = useGetUserWithFilterLazyQuery({
    variables: {
      filter: {
        id: {
          eq: complaint?.complaint_getComplaints.result?.items?.[0]?.contract
            ?.accuserDepartmentUserId,
        },
      },
    },
    onCompleted() {
      void getRequests();
    },
  });


  const [SendDocumentRequestResponseSMS] = useSendDocumentRequestResponseSmsMutation();

  const [
    getRequests,
    { data: requestedDocsData, refetch: requestedDocsRefetch },
  ] = useGetReqestedDocsQueryLazyQuery({
    variables: {
      filter: {
        and: [
          {
            complaintId: {
              eq: parseInt(complaintId || "") || 0,
            },
          },
        ],
      },
    },
    onCompleted(data) {
      console.log("🚀 ~ onCompleted ~ data:", data);
    },
  });

  const { data: allRequests, refetch } = useGetReqestedDocsQueryQuery({
    variables: {
      filter: {
        complaintId: {
          eq: parseInt(complaintId || "") || 0,
        },
      },
    },
  });

  const [GetAccused] = useGetUserWithFilterLazyQuery({
    variables: {
      filter: {
        id: {
          eq: complaint?.complaint_getComplaints.result?.items?.[0]?.contract
            ?.accusedDepartmentUserId,
        },
      },
    },
  });
  return (
    <>
      <Box
        display={"flex"}
        justifyContent={"center"}
        alignItems={"center"}
        flexDirection={"column"}
        position={"relative"}
      >
        <Box
          borderRadius={"3rem"}
          sx={{
            background: primary,
            padding: "0.5rem 1rem",
            userSelect: "none",
            width: "max-content",
            justifySelf: "center",
            zIndex: 1000,
          }}
        >
          <Typography variant={"h6"} sx={{ color: secondary }}>
            مدارک مورد نیاز
          </Typography>
        </Box>
        <Divider
          sx={{
            width: "100%",
            backgroundColor: secondary,
            height: "0.2rem",
            margin: "1rem 0",
            position: "absolute",
          }}
        />
      </Box>
      <div className="rounded-lg overflow-hidden shadow-xl my-4">
        <Table
          sx={{
            // backgroundColor: primaryGreyLightTransparent,
            borderRadius: "0.5rem",
            "& MuiTableCell-root": {
              textAlign: "center",
              padding: "0.1rem",
            },
          }}
        >
          <TableHead
            sx={{
              background: "white",
              borderRadius: "0.5rem",
              // color: "white",
              // center the text in cells
              "& th": {
                // textAlign: "center",
                fontWeight: "bold",
                color: "black",
              },
            }}
          >
            <TableRow>
              <TableCell>عنوان مستند/پرسش</TableCell>
              <TableCell>فایل</TableCell>
              <TableCell>پاسخ</TableCell>
              <TableCell>...</TableCell>
            </TableRow>
          </TableHead>
          <TableBody
          // sx={{
          //   // delete padding of cells
          //   "& td": {
          //     padding: "0.5rem",
          //     borderBottom: `1px solid ${secondary}`,
          //   },
          //   // add border to first column
          //   "& td:first-child": {
          //     borderRight: `1px solid ${secondary}`,
          //     width: "max-content",
          //   },
          //   // add border to last column
          //   "& td:last-child": {
          //     borderLeft: `1px solid ${secondary}`,
          //   },
          // }}
          >
            {requestedDocsData?.documentRequest_getDocumentRequests.result?.items?.map(
              (item) => (
                <DocCard
                  {...item}
                  refetch={requestedDocsRefetch}
                  target={item.target}
                  type={
                    user.id ==
                    AccuserData?.user_getUsers?.result?.items?.[0]?.id
                      ? RegistrarType.Accuser
                      : user.parentId ==
                        AccuserData?.user_getUsers?.result?.items?.[0]?.id
                      ? RegistrarType.Accuser
                      : RegistrarType.Accused
                  }
                />
              )
            )}
          </TableBody>
        </Table>
      </div>

      <Box display={"flex"} justifyContent={"flex-end"} my={2}>
        {loading && <Typography>در حال ثبت اطلاعات</Typography>}
        {loading && <LinearProgress sx={{ width: "100%" }} />}
        <Button
          variant={"contained"}
          sx={{
            backgroundColor: primary,
            padding: "0.5rem 2rem",
            borderRadius: "3rem",
            color: secondary,
            fontSize: "1.2rem",
            "&:hover": {
              backgroundColor: secondary,
              color: primary,
            },
          }}
          onClick={() => {
            const agree = confirm("آیا از ثبت نهایی اطلاعات اطمینان دارید؟");
            if (agree) {
              if (
                allRequests?.documentRequest_getDocumentRequests.result?.items?.some(
                  (a) => {
                    ((a.target == TargetType.Accuser ||
                      a.target == TargetType.Both) &&
                      a.requestedDocumentFileNameAccuser == null) ||
                      ((a.target == TargetType.Accuser ||
                        a.target == TargetType.Both) &&
                        a.requestedDocumentFileNameAccused == null);
                  }
                )
              ) {
                if (
                  user?.id ==
                    AccuserData?.user_getUsers.result?.items?.[0].id &&
                  allRequests?.documentRequest_getDocumentRequests.result?.items?.some(
                    (a) => {
                      (a.target == TargetType.Accuser ||
                        a.target == TargetType.Both) &&
                        a.requestedDocumentFileNameAccuser == null;
                    }
                  )
                ) {
                  alert("مدارک مورد نیاز طرف مقابل ثبت نشده است");
                } else {
                  alert("مدارک مورد نیاز شما ثبت نشده است");
                }
              } else {
                void updateComplaint({
                  variables: {
                    input: {
                      isArchived: false,
                      id: parseInt(complaintId || "") || 0,
                      complaintStateId:
                        user.id ==
                        AccuserData?.user_getUsers.result?.items?.[0].id
                          ? getComplaintStateWithEnum(
                              ComplaintStateStatus.UploadingDocumentsByAccused
                            ).id
                          : user.parentId ==
                            AccuserData?.user_getUsers.result?.items?.[0].id
                          ? getComplaintStateWithEnum(
                              ComplaintStateStatus.UploadingDocumentsByAccused
                            ).id
                          : getComplaintStateWithEnum(
                              ComplaintStateStatus.ReviewingCaseByCaseExpert
                            ).id,
                    },
                  },
                  onCompleted(data) {
                    console.log("🚀 ~ onCompleted ~ data", data);
                    user.id !==
                        AccuserData?.user_getUsers.result?.items?.[0].id && (
                          void SendDocumentRequestResponseSMS({
                            variables:{
                              complaintId: parseInt(complaintId || "") || 0,
                              expertId:complaint?.complaint_getComplaints?.result?.items?.[0]?.councilExpertIds?.[0] || "",
                            }
                          })
                        )
                    navigate(`/complaints`);
                  },
                });
              }
            }
          }}
        >
          ثبت و تایید نهایی
        </Button>
      </Box>
    </>
  );
};

export default UploadDocs;
