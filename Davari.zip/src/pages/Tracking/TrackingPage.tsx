/* eslint-disable @typescript-eslint/no-unnecessary-type-assertion */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-misused-promises */
import React from "react";
import {
  useGenerateComplaintTrackingLetterMutation,
  useGenerateNonFeasibleArgumentTrackingLetterMutation,
  useGetComplaintByTrackingCodeLazyQuery,
} from "../../../generated-types";
import FaTypography from "../../components/FaComponents/FaTypography";
import FaTextField from "../../components/FaComponents/FaTextField";
import { LinearProgress, Typography } from "@mui/material";
import { useAlertStore } from "../../Context/AlertStore";
import { FaDownload } from "react-icons/fa";
import * as libre from "libreoffice-convert";
const TrackingPage = () => {
  const [trackingCode, setTrackingCode] = React.useState<string>("");
  const [trackingType, setTrackingType] = React.useState<
    "complaint" | "argument"
  >("complaint");
  const [fileUrl, setFileUrl] = React.useState<string>("");
  const [blob, setBlob] = React.useState<Blob | null>(null);
  const [pdf, setPdf] = React.useState<Blob | null>(null);
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();

  const [GetComplaintByTrackingCode, { data, loading }] =
    useGetComplaintByTrackingCodeLazyQuery({
      variables: {
        trackingCode: trackingCode,
      },
    });

  const [GenerateNonFeasibleArgumentTrackingLetter, { loading: loading2 }] =
    useGenerateNonFeasibleArgumentTrackingLetterMutation({
      variables: {
        argumentTrackingCode: trackingCode,
      },
      onCompleted(data, clientOptions) {
        if (data.test_generateNonFeasibleArgumentTrackingLetter.length > 0) {
          setFileUrl(
            data.test_generateNonFeasibleArgumentTrackingLetter as string
          );
          // get the file from the url and then convert it to pdf
          const response = fetch(
            "http://172.16.21.147:7030/files/" +
              data.test_generateNonFeasibleArgumentTrackingLetter
          );
          response.then((res) => {
            res.blob().then((blob) => {
              setBlob(blob);
              const reader = new FileReader();
              reader.onloadend = () => {
                const buffer = new Uint8Array(reader.result as ArrayBuffer);
                const pdfBlob = new Blob([buffer], { type: "application/pdf" });
                setPdf(pdfBlob);
              };
              reader.readAsArrayBuffer(blob);
            });
          });
        } else {
          setAlertMessage("یافت نشد");
          setAlertOpen(true);
          setAlertType("error");
        }
      },
    });

  const [GenerateComplaintTrackingLetter, { loading: loading1 }] =
    useGenerateComplaintTrackingLetterMutation({
      variables: {
        complaintCode: trackingCode,
      },
      onCompleted(data, clientOptions) {
        if (data.test_generateComplaintTrackingLetter.length > 0) {
          setFileUrl(data.test_generateComplaintTrackingLetter as string);
          // get the file from the url and then convert it to pdf
          const response = fetch(
            "http://172.16.21.147:7030/files/" +
              data.test_generateComplaintTrackingLetter
          );
          response.then((res) => {
            res.blob().then((blob) => {
              setBlob(blob);
              const reader = new FileReader();
              reader.onloadend = () => {
                const buffer = new Uint8Array(reader.result as ArrayBuffer);
                const pdfBlob = new Blob([buffer], { type: "application/pdf" });
                setPdf(pdfBlob);
              };
              reader.readAsArrayBuffer(blob);
            });
          });
        } else {
          setAlertMessage("یافت نشد");
          setAlertOpen(true);
          setAlertType("error");
        }
      },
    });

  // test_generateNonFeasibleArgumentTrackingLetter
  // test_generateComplaintTrackingLetter
  return (
    <div className="grid grid-cols-2 items-center justify-center gap-4 w-full">
      <div className="col-span-full flex justify-center items-center">
        <div className="grid grid-cols-2 items-center justify-center rounded-full outline outline-1 outline-primary-500 *:duration-300">
          <div
            className={`rounded-full ${
              trackingType == "complaint"
                ? "bg-primary-500 font-bold"
                : "bg-white-100 text-secondary-400"
            } p-2 cursor-pointer`}
            onClick={() => setTrackingType("complaint")}
          >
            <div className="text w-full text-center">استعلام درخواست داوری</div>
          </div>
          <div
            className={`rounded-full ${
              trackingType == "argument"
                ? "bg-primary-500 font-bold"
                : "bg-white-100 text-secondary-400"
            } p-2 cursor-pointer`}
            onClick={() => setTrackingType("argument")}
          >
            <div className="text w-full text-center">
              استعلام دعاوی غیرقابل رسیدگی
            </div>
          </div>
        </div>
      </div>
      <FaTypography
        variant="h5"
        textAlign={"center"}
        className="col-span-full"
      ></FaTypography>
      <FaTextField
        label="کد پیگیری"
        value={trackingCode}
        onChange={(e) => setTrackingCode(e.target.value)}
        className="rounded-full col-span-full"
        fullWidth
        sx={{
          borderRadius: "5rem",
          "& .MuiInputBase-root": {
            borderRadius: "5rem",
          },
        }}
      />
      <div className=""></div>

      <button
        onClick={() => {
          switch (trackingType) {
            case "complaint":
              GenerateComplaintTrackingLetter();
              break;
            case "argument":
              GenerateNonFeasibleArgumentTrackingLetter();
              break;
          }
        }}
        className="bg-primary-500 text-white rounded-full p-3 ring-0 border-none cursor-pointer hover:bg-primary-600 duration-300 ease-in-out"
      >
        {loading1 || loading2 ? <LinearProgress /> : null}
        جستجو
      </button>

      {fileUrl && (
        <a
          href={
            ((import.meta.env.VITE_FILE_URL as string) ||
              "http://172.16.21.147:7030/files/") + fileUrl
          }
          target="_blank"
          rel="noreferrer"
          className="bg-primary-500/30 text-primary-700 no-underline rounded-full p-3 ring-0 border-none cursor-pointer hover:bg-primary-600 duration-300 ease-in-out flex items-center justify-center gap-2 w-full col-span-full"
        >
          <FaDownload size={20} />
          <div className="text">دانلود فایل</div>
        </a>
      )}
    </div>
  );
};

export default TrackingPage;
