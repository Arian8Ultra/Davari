import React from "react";
interface Props {
  dates: {
    date: string;
    title: string;
    description: string;
    color?: string;
  }[];
  sortType?: "asc" | "desc";
  alternate?: boolean;
}
const DateTimeLine = ({ dates, sortType, alternate }: Props) => {
  const sortedDates = dates.sort((a, b) => {
    return (new Date(a.date).getTime() - new Date(b.date || "").getTime());
  });
  const sortedDatesDesc = sortedDates.reverse();
  const sorted = sortType === "asc" ? sortedDates : sortedDatesDesc;

  return (
    <div className="grid grid-cols-[auto,auto,auto] gap-3 w-fit">
      {alternate &&
        sorted.map(
          (date, index) =>
            date.date && (
              <>
                {index % 2 === 0 ? (
                  <div />
                ) : (
                  <div
                    className={`flex flex-col items-end rounded-lg px-5 relative overflow-hidden bg-white-50`}
                    style={{
                      borderTop: `3px solid ${date.color || "#fff"}`,
                    }}
                  >
                    <div className="flex justify-between flex-row-reverse items-center gap-5">
                      <h1 className="text-[1.4rem]">{date.title}</h1>
                      <h2 className="text-[1rem]">
                        {new Date(date.date || "").toLocaleDateString("fa-IR", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </h2>
                    </div>
                    <p className="text-[1.0rem]">{date.description}</p>
                  </div>
                )}
                <div className="flex flex-col items-center justify-center h-full gap-2">
                  {/* <div className="bg-gray-40 h-full w-0.5"></div> */}
                  <div
                    className="h-3 w-3 rounded-full p-1 aspect-square"
                    style={{
                      backgroundColor: date.color || "#000",
                    }}
                  ></div>
                  <div className="bg-gray-40 h-full w-0.5"></div>
                </div>
                {index % 2 !== 0 ? (
                  <div />
                ) : (
                  <div
                    className="flex flex-col items-start bg-white-50 rounded-lg px-5"
                    style={{
                      borderTop: `3px solid ${date.color || "#fff"}`,
                    }}
                  >
                    <div className="flex justify-between items-center gap-5">
                      <h1 className="text-[1.4rem]">{date.title}</h1>
                      <h2 className="text-[1rem]">
                        {new Date(date.date || "").toLocaleDateString("fa-IR", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </h2>
                    </div>
                    <p className="text-[1.0rem]">{date.description}</p>
                  </div>
                )}
              </>
            )
        )}

      {!alternate &&
        sorted.map(
          (date, index) =>
            date.date && (
              <>
                <div />
                <div className="flex flex-col items-center justify-center h-full gap-2">
                  {/* <div className="bg-gray-40 h-full w-0.5"></div> */}
                  <div
                    className="h-3 w-3 rounded-full p-1 aspect-square"
                    style={{
                      backgroundColor: date.color || "#000",
                    }}
                  ></div>
                  <div className="bg-gray-40 h-full w-0.5"></div>
                </div>
                <div
                  className="flex flex-col items-center bg-white-50 rounded-lg px-5"
                  style={{
                    borderTop: `3px solid ${date.color || "#fff"}`,
                  }}
                >
                  <div className="flex justify-between items-center gap-5">
                    <h1 className="text-[1.4rem]">{date.title}</h1>
                    <h2 className="text-[1rem]">
                      {new Date(date.date || "").toLocaleDateString("fa-IR", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </h2>
                  </div>
                  <p className="text-[1.0rem]">{date.description}</p>
                </div>
              </>
            )
        )}
    </div>
  );
};

export default DateTimeLine;
