/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { TableRow, Typography } from "@mui/material";
import { useState } from "react";
import {
  useGetUsersQuery,
  useGetUsersWithParentIdQuery,
} from "../../../../generated-types";
import { useUserStore } from "../../../Context/UserStore";
import CTable from "../../CustomTable/CTable";
import UserTableRow from "./UserTableRow";

const UserList = () => {
  const user = useUserStore((state) => state.user);
  const [page, setPage] = useState(1);
  const [take, setTake] = useState(10);

  const { data, loading, error, refetch } = useGetUsersQuery({
    variables: {
      take: take,
      skip: (page - 1) * take,
    },
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });
  const { data: parentData } = useGetUsersWithParentIdQuery({
    variables: {
      id: user.userType == "ORGANIZATION" ? user.id : user.parentId || "",
    },
    onCompleted(data) {
      console.log("parentData", data);
    },
    onError(error) {
      console.log(error);
    },
  });
  return (
    <>
      <CTable
        totalRecords={data?.user_getUsers?.result?.items?.length || 0}
        page={page}
        setPage={setPage}
        recordsPerPage={take}
        setRecordsPerPage={setTake}

        tableHeader={
          <TableRow className="*:p-4">
            <Typography
              textAlign={"center"}
              display={"table-cell"}
              fontSize={{
                xs: 10,
                sm: 11,
                md: 12,
                lg: 14,
              }}
            >
              نام
            </Typography>

            <Typography
              display={{ xs: "none", md: "table-cell" }}
              textAlign={"center"}
              fontSize={{
                xs: 10,
                sm: 11,
                md: 12,
                lg: 14,
              }}
            >
              بخش
            </Typography>

            <Typography
              display={{ xs: "none", md: "table-cell" }}
              textAlign={"center"}
              fontSize={{
                xs: 10,
                sm: 11,
                md: 12,
                lg: 14,
              }}
            >
              نام کاربری
            </Typography>
            <Typography
              display={{ xs: "none", md: "table-cell" }}
              textAlign={"center"}
              fontSize={{
                xs: 10,
                sm: 11,
                md: 12,
                lg: 14,
              }}
            >
              نقش کاربر
            </Typography>
            <Typography
              display={{ xs: "none", md: "table-cell" }}
              textAlign={"center"}
              fontSize={{
                xs: 10,
                sm: 11,
                md: 12,
                lg: 14,
              }}
            >
              نوع کاربر
            </Typography>
            <Typography
              textAlign={"center"}
              display={"table-cell"}
              fontSize={{
                xs: 10,
                sm: 11,
                md: 12,
                lg: 14,
              }}
            >
              ...
            </Typography>
          </TableRow>
        }
      >
        {loading && <p>در حال بارگذاری</p>}
        {error && <p>خطا در بارگذاری</p>}

        {user.userRoles?.some((role) => role.roleType == "SUPER_ADMIN")
          ? data?.user_getUsers?.result?.items?.map((user) => (
              <UserTableRow
                fullName={user.fullName}
                department={user.parent?.fullName}
                id={user.id || ""}
                userName={user.userName || ""}
                refetch={refetch}
                userRoles={user.userRoles || undefined}
                parentId={user.parentId || ""}
                userType={
                  user.userType == "INDIVIDUAL"
                    ? "حقیقی"
                    : user.userType == "CONTRACTOR_OR_CONSULTANT"
                    ? "پیمانکار / مشاور"
                    : "دستگاه"
                }
                // @ts-ignore
                isJury={false}
              />
            ))
          : parentData?.user_getUsers?.result?.items?.map((user) => (
              <UserTableRow
                fullName={user.fullName}
                department={user.parent?.fullName}
                id={user.id || ""}
                userName={user.userName || ""}
                refetch={refetch}
                userRoles={user.userRoles || undefined}
                parentId={user.parentId || ""}
                userType={
                  user.userType == "INDIVIDUAL"
                    ? "حقیقی"
                    : user.userType == "CONTRACTOR_OR_CONSULTANT"
                    ? "پیمانکار / مشاور"
                    : "دستگاه"
                }
                // @ts-ignore
                isJury={false}
              />
            ))}
      </CTable>
    </>
  );
};

export default UserList;
