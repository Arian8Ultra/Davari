/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Accordion, AccordionDetails, AccordionSummary } from "@mui/material";
import { DepartmentsHierarchyWithSubdepartmentsRootObject } from "../../assets/types";
import React, { useEffect, useState } from "react";
import { Add } from "@mui/icons-material";
import { BsChevronDown } from "react-icons/bs";
interface Props {
  department: DepartmentsHierarchyWithSubdepartmentsRootObject;
  onSelect: (
    department: DepartmentsHierarchyWithSubdepartmentsRootObject
  ) => void;
  selectedDepartment?: DepartmentsHierarchyWithSubdepartmentsRootObject;
}
const DepartmentAccordion = ({
  department,
  onSelect,
  selectedDepartment,
}: Props) => {
  const [open, setOpen] = useState(false);
  const [subDepartments, setSubDepartments] = useState<React.ReactNode[]>([]);

  useEffect(() => {
    if (department.sub_departments) {
      if (open) {
        setSubDepartments(
          department.sub_departments.map((sub_department, index) => (
            <DepartmentAccordion
              key={index}
              department={sub_department}
              onSelect={onSelect}
              selectedDepartment={selectedDepartment}
            />
          ))
        );
      }
    }
  }, [open, department, onSelect, selectedDepartment]);

  return (
    <Accordion
      sx={{
        boxShadow: "none",
        border: "none",
        "& .MuiAccordionSummary-root": {
          padding: "0",
        },
      }}
      expanded={open}
      onChange={() => {
        if (department.sub_departments?.length === 0) {
          onSelect(department);
        } else {
          setOpen(!open);
        }
      }}
    >
      <AccordionSummary
        sx={{
          boxShadow: "none",
          border: "none",
          "& .MuiAccordionSummary-content": {
            margin: "0",
          },
        }}
      >
        <div
          className={`flex w-full justify-between items-center p-2 border-b border-gray-40 rounded-lg ${
            open ? " bg-primary-300/40" : "outline outline-1 outline-gray-40"
          }`}
        >
          <div className=" flex h-full items-center justify-center">
            {department.sub_departments?.length ? (
              <BsChevronDown
                className={`transform ${open ? "rotate-180" : ""} duration-300`}
              />
            ) : undefined}
          </div>
          <div>{department.Department_Name}</div>

          <button
            className="rounded-lg bg-primary-500/30 border-none text-primary-700 flex gap-2 py-1 cursor-pointer hover:shadow-sm items-center"
            onClick={(e) => {
              e.preventDefault();
              onSelect(department);
            }}
          >
            <Add />
            انتخاب
          </button>
        </div>
      </AccordionSummary>
      <AccordionDetails
        sx={{
          boxShadow: "none",
          border: "none",
          padding: "0",
          "& .MuiAccordionDetails-root": {
            padding: "0",
            border: "none",
          },
        }}
      >
        <div className="flex flex-col w-full gap-2 p-3 outline outline-1 outline-gray-40 rounded-lg">
          {subDepartments}
        </div>
      </AccordionDetails>
    </Accordion>
  );
};

export default DepartmentAccordion;
