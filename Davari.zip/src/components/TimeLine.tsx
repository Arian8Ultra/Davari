import { Box, BoxProps, Divider } from "@mui/material";
import { BsCheckCircleFill, BsCircle } from "react-icons/bs";
import { ComplaintTimeLineStages } from "../static/TimeLineStages";
import { primary, primaryDark, secondary } from "../theme/color";
import { convertToPersianDigits } from "../functions/Functions";

interface Props extends BoxProps {
  stage?: number;
}
const TimeLine = (props: Props) => {
  return (
    <Box
      display={{
        xs: "none",
        sm: "none",
        md: "grid",
        lg: "grid",
        xl: "grid",
      }}
      gridTemplateColumns={`1fr`}
      justifyContent={"center"}
      alignItems={"center"}
      className="w-full mt-10"
      gap={2}
      {...props}
    >
      <Box
        display={"grid"}
        gridTemplateColumns={`repeat(${ComplaintTimeLineStages.length},1fr)`}
        justifyContent={"center"}
        alignItems={"center"}
        position={"relative"}
        {...props}
      >
        <Divider
          sx={{
            position: "absolute",
            width: "80%",
            transform: "translateY(-50%) translateX(-50%)",
            left: "50%",
          }}
        />
        {ComplaintTimeLineStages.map((s, i) => (
          <Box
            justifyContent={"center"}
            alignItems={"center"}
            sx={{
              width: "max-content",
              position: "relative",
              display: "flex",
              flexDirection: "column",
              gap: 1,
              zIndex: 100,
              justifySelf: "center",
              borderRadius: "50rem",
              border: `2px solid ${
                props.stage && props.stage > s.id
                  ? primary
                  : props.stage == s.id
                  ? primaryDark
                  : secondary
              }`,
              padding: 1,
              background: "white",
              // aspectRatio: 1,
              scale: props.stage && props.stage == s.id ? "110%" : "90%",
              color:
                props.stage && props.stage > s.id
                  ? primary
                  : props.stage == s.id
                  ? primaryDark
                  : secondary,
            }}
            className="rounded-full h-full"
          >
            {props.stage && props.stage > s.id ? (
              <BsCheckCircleFill
                style={{ color: primary }}
                className="text-[24px] md:text-[32px] absolute -top-10 right-1/2 translate-x-1/2"
              />
            ) : (
              // <BsCircle className="text-[24px] md:text-[32px] absolute -top-10 right-1/2 translate-x-1/2" />
              <div
                className="text-[12px] md:text-[14px] absolute -top-12 right-1/2 translate-x-1/2 rounded-full aspect-square w-10 text-center flex justify-center items-center bg-white-100"
                style={{
                  border: `2px solid ${
                    props.stage && props.stage > s.id
                      ? primary
                      : props.stage == s.id
                      ? primaryDark
                      : secondary 
                  }`,
                  aspectRatio: 1,
                  // color: "white",
                }}
              >
                <div className="text">{convertToPersianDigits(i + 1)}</div>
              </div>
            )}
            {s.title}
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default TimeLine;
