/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/ban-types */
import {
  CancelOutlined,
  FileCopyOutlined,
  UploadFileOutlined,
} from "@mui/icons-material";
import {
  Box,
  Button,
  ButtonProps,
  IconButton,
  Typography,
} from "@mui/material";
import React, { useEffect } from "react";
import { Red, secondary } from "../theme/color";
import {
  BsCheck,
  BsCheckCircleFill,
  BsFillFileEarmarkCheckFill,
} from "react-icons/bs";
interface Props extends ButtonProps {
  setFiles?: (file: File) => void | ((files: File[]) => void);
  files?: File | File[];
  fileTypes?: string[];
  title?: string;
  multiple?: boolean;
  onFileChange?: (file: File) => void;
  fileUrl?: string;
  row?: boolean;
}
const FileBox = ({
  title,
  setFiles,
  files,
  fileTypes,
  multiple = false,
  onFileChange,
  fileUrl,
  row = true,
  ...props
}: Props) => {
  const [file, setFile] = React.useState(files);
  const [fileName, setFileName] = React.useState<string>(fileUrl || "");

  useEffect(() => {
    setFile(files);
  }, [files]);

  useEffect(() => {
    if (fileUrl && fileUrl != "") {
      setFileName(fileUrl);
    }
  });

  const handleFile = (e: { target: { files: any } }) => {
    onFileChange && onFileChange(e.target.files[0]);
    const newFiles = e.target.files;
    console.log(newFiles);
    setFile(newFiles[0]);
    multiple && setFiles && setFiles(newFiles);
    multiple && setFileName(newFiles.map((file: File) => file.name).join(","));
    !multiple && setFiles && setFiles(newFiles[0]);
    !multiple && setFileName(newFiles[0].name.split(".")[0]);
  };
  return (
    //   @ts-ignore
    <Button
      variant="outlined"
      component="label"
      sx={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
      {...props}
    >
      <input
        type="file"
        multiple={multiple}
        onChange={handleFile}
        hidden
        // just accept image and pdf
        accept={fileTypes?.join(",") || "image/*,application/pdf"}
        // style={{
        //   position: "absolute",
        //   top: 0,
        //   left: 0,
        //   width: "100%",
        //   height: "100%",
        //   outline:'1px solid red',
        //   zIndex:1000
        // }}
      />
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          //   border: "1px dotted #ccc",
          flexDirection: row ? "row" : "column",
          borderRadius: "5px",
          justifyContent: "center",
        }}
      >
        {fileName == "" && <UploadFileOutlined />}
        {fileName == "" && props.children}
        <Typography variant="body2" className="whitespace-nowrap">
          {!fileName ? title || "بارگذاری" : ""}
          {/* {!fileName ? title || "بارگذاری" : "(برای ویرایش کلیک کنید)"} */}
        </Typography>

        {/* {fileNames?.length > 0 &&
          fileNames.map((name, index) => (
            <Box>
              <FileCopyOutlined key={index} />
              {name}
            </Box>
          ))} */}

        {fileName != "" && (
          <Box
            sx={{
              display: "flex",
              flexDirection: row ? "row" : "column",
              alignItems: "center",
              justifyContent: "center",
              gap: "5px",
            }}
          >
            <BsFillFileEarmarkCheckFill className="fill-success60 text-xl" />
            <div className="text whitespace-nowrap text-ellipsis overflow-hidden w-32">
              {fileName}
            </div>
            {/* <Typography>برای ویرایش کلیک کنید</Typography> */}
            {props.children}

            <IconButton
              sx={{
                position: "absolute",
                zIndex: 1000,
                left: -10,
                padding: "0px",
                background: "white",
                color: secondary,
                "&:hover": {
                  background: "white",
                  color: Red,
                },
              }}
              onClick={() => {
                setFile(undefined);
                setFileName("");
              }}
            >
              <CancelOutlined />
            </IconButton>
          </Box>
        )}
        {/* {fileName == "" && fileTypes?.join(",")} */}
      </Box>
    </Button>
  );
};

export default FileBox;
