/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { ApolloQueryResult } from "@apollo/client";
import { Add, CancelOutlined } from "@mui/icons-material";
import { Button, TableCell, TableRow, Tooltip } from "@mui/material";
import { useEffect, useState } from "react";
import { RiFileEditFill } from "react-icons/ri";
import { API_FILE_DOWNLOAD } from "../../../../config";
import { convertToPersianDigits } from "../../../functions/Functions";
import { MutationWrapper } from "../../../GraphQL/MutationWrapper";
import { QueryWrapper } from "../../../GraphQL/QueryWrapper";
import {
  DELETE_INSTALLMENT,
  DELETE_INSTALLMENT_PART,
  Installment,
  InstallmentPart,
} from "../../../GraphQL/Tables/Mutations";
import { GET_INSTALLMENT } from "../../../GraphQL/Tables/Queries";
import {
  Red,
  primary,
  primaryTransparent,
  secondaryDark,
} from "../../../theme/color";

interface InstallmentCardProps {
  installment: Installment;
  setNewInstallment: React.Dispatch<React.SetStateAction<Installment>>;
  setEditMode: React.Dispatch<React.SetStateAction<boolean>>;
  refetch: (
    variables?: Partial<any> | undefined
  ) => Promise<ApolloQueryResult<any>>;
  setAddInstallmentPartModal: (
    value: React.SetStateAction<{
      open: boolean;
      installmentPart: InstallmentPart;
      installmentId?: number | undefined;
      edit?: boolean;
    }>
  ) => void;
}
export default function InstallmentStatementCard({
  installment,
  setNewInstallment,
  setEditMode,
  refetch,
  setAddInstallmentPartModal,
}: InstallmentCardProps) {
  const { handleMutation: deleteInstallment } = MutationWrapper(
    DELETE_INSTALLMENT,
    "installment_deleteInstallment"
  );
  const [installmentParts, setInstallmentParts] = useState<InstallmentPart[]>();

  const { handleMutation: deleteInstallmentPart } = MutationWrapper(
    DELETE_INSTALLMENT_PART,
    "installmentPart_deleteInstallmentPart"
  );

  const { data } = QueryWrapper(
    GET_INSTALLMENT,
    "installment_getInstallment",
    { id: installment.id },
    {
      onCompleted(data) {
        console.log("installment_getInstallment", data);
        setInstallmentParts(data.installmentParts);
      },
    }
  );

  useEffect(() => {
    // console.log("TESTTEST", data);
    setInstallmentParts(data?.installmentParts);
  }, [data]);

  return (
    <>
      <TableRow key={installment.id}>
        <TableCell>{installment.title}</TableCell>
        <TableCell>
          {convertToPersianDigits(
            installment.amount?.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
          )}
        </TableCell>
        <TableCell>
          {new Date(installment?.date || new Date()).toLocaleDateString(
            "fa-IR"
          )}
        </TableCell>
        <TableCell>
          <Button
            variant="text"
            color="success"
            href={
              API_FILE_DOWNLOAD + (installment.financialCoverFileName || "")
            }
            target="_blank"
          >
            {installment.financialCoverFileName}
          </Button>
        </TableCell>
        <TableCell className="w-fit">
          <div className="flex w-full justify-end px-4">
            <div className="flex gap-2 w-fit place-self-end ">
              {installment.title.trim() == "میزان مبلغ مستهلک شده" ? (
                ""
              ) : (
                <Button
                  variant="text"
                  sx={{
                    color: primary,
                    "&:hover": {
                      color: primary,
                    },
                  }}
                  onClick={() => {
                    setAddInstallmentPartModal({
                      open: true,
                      installmentPart: {} as InstallmentPart,
                      installmentId: installment.id,
                    });
                  }}
                >
                  <Add />
                  افزودن بخش
                </Button>
              )}
              <Tooltip title="ویرایش">
                <Button
                  variant="text"
                  sx={{
                    color: secondaryDark,
                    "&:hover": {
                      color: secondaryDark,
                    },
                  }}
                  onClick={() => {
                    setNewInstallment(installment);
                    setEditMode(true);
                  }}
                >
                  <RiFileEditFill className="w-6 h-6" />
                  {/* ویرایش */}
                </Button>
              </Tooltip>

              <Tooltip title="حذف">
                <Button
                  variant="text"
                  sx={{
                    // color: Red,
                    "&:hover": {
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    void deleteInstallment({
                      variables: {
                        id: installment.id,
                      },
                    }).then(() => {
                      setNewInstallment({} as Installment);
                      void refetch();
                    });
                  }}
                  className="text-red-50"
                >
                  <CancelOutlined />
                  {/* حذف */}
                </Button>
              </Tooltip>

            </div>
          </div>
        </TableCell>
      </TableRow>
      {installmentParts?.map((installmentPart: InstallmentPart, i) => (
        <TableRow
          key={installmentPart.id}
          sx={{
            backgroundColor: primaryTransparent,
            borderLeft: `2px solid ${primary}`,
          }}
        >
          <TableCell>{installment.title + " - " + String(i + 1)}</TableCell>
          <TableCell>
            {convertToPersianDigits(installmentPart.amount)}
          </TableCell>
          <TableCell>
            {new Date(installmentPart?.date).toLocaleDateString("fa-IR")}
          </TableCell>
          <TableCell></TableCell>
          <TableCell>
            <div className="flex w-full justify-end px-4">
              <div className="flex gap-2 w-fit place-self-end ">
                <div className=""></div>
                <Tooltip title="ویرایش">
                  <Button
                    variant="text"
                    sx={{
                      color: secondaryDark,
                      "&:hover": {
                        color: secondaryDark,
                      },
                    }}
                    className="w-fit"
                    onClick={() => {
                      setAddInstallmentPartModal({
                        open: true,
                        installmentPart: installmentPart,
                        installmentId: installment.id,
                        edit: true,
                      });
                    }}
                    title="ویرایش"
                  >
                    <RiFileEditFill className="w-6 h-6" />
                    {/* ویرایش */}
                  </Button>
                </Tooltip>

                <Tooltip title="حذف">
                  <Button
                    variant="text"
                    sx={{
                      // color: Red,
                      "&:hover": {
                        color: Red,
                      },
                    }}
                    title="حذف"
                    className="w-fit text-red-50"
                    onClick={() => {
                      void deleteInstallmentPart({
                        variables: {
                          id: installmentPart.id,
                        },
                      }).then(() => {
                        setNewInstallment({} as Installment);
                        void refetch();
                      });
                    }}
                  >
                    <CancelOutlined />
                    {/* حذف */}
                  </Button>
                </Tooltip>
              </div>
            </div>
          </TableCell>
        </TableRow>
      ))}
    </>
  );
}
