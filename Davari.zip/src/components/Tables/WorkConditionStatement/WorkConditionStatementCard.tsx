/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { ApolloQueryResult } from "@apollo/client";
import { Add, CancelOutlined, EditOutlined } from "@mui/icons-material";
import {
  Box,
  Button,
  IconButton,
  TableCell,
  TableRow,
  Tooltip,
} from "@mui/material";
import { useEffect, useState } from "react";
import { MutationWrapper } from "../../../GraphQL/MutationWrapper";
import { QueryWrapper } from "../../../GraphQL/QueryWrapper";
import {
  DELETE_WORK_CONDITION_STATEMENT,
  DELETE_WORK_CONDITION_STATEMENT_PART,
  WorkConditionStatement,
  WorkConditionStatementPart,
} from "../../../GraphQL/Tables/Mutations";
import { GET_WORK_CONDITION_STATEMENT } from "../../../GraphQL/Tables/Queries";
import {
  convertToPersianDigits,
  convertToPersianDigitsWithComma,
} from "../../../functions/Functions";
import {
  Red,
  RedLight,
  primary,
  primaryLight,
  primaryTransparent,
  secondaryDark,
  secondaryLighter,
} from "../../../theme/color";
import { RiFileEditFill } from "react-icons/ri";
import { API_FILE_DOWNLOAD } from "../../../../config";

interface WorkConditionStatementCard {
  WorkConditionStatement: WorkConditionStatement;
  setNewWorkConditionStatement: React.Dispatch<
    React.SetStateAction<WorkConditionStatement>
  >;
  setEditMode: React.Dispatch<React.SetStateAction<boolean>>;
  refetch: (
    variables?: Partial<any> | undefined
  ) => Promise<ApolloQueryResult<any>>;
  setAddWorkConditionStatementPartModal: (
    value: React.SetStateAction<{
      open: boolean;
      WorkConditionStatementPart: WorkConditionStatementPart;
      WorkConditionStatementId?: number | undefined;
    }>
  ) => void;
  isConsultant?: boolean;
}
export default function WorkConditionStatementCard({
  WorkConditionStatement,
  setNewWorkConditionStatement,
  setEditMode,
  refetch,
  setAddWorkConditionStatementPartModal,
  isConsultant,
}: WorkConditionStatementCard) {
  const { handleMutation: deleteWorkConditionStatement } = MutationWrapper(
    DELETE_WORK_CONDITION_STATEMENT,
    "workConditionStatement_deleteWorkConditionStatement"
  );
  const [WorkConditionStatementParts, setWorkConditionStatementParts] =
    useState<WorkConditionStatementPart[]>();

  const { handleMutation: deleteWorkConditionStatementPart } = MutationWrapper(
    DELETE_WORK_CONDITION_STATEMENT_PART,
    "workConditionStatementPart_deleteWorkConditionStatementPart"
  );

  const { data, refetch: WorkConditionStatementRefetch } = QueryWrapper(
    GET_WORK_CONDITION_STATEMENT,
    "workConditionStatement_getWorkConditionStatement",
    { id: WorkConditionStatement.id },
    {
      onCompleted(data) {
        console.log("workConditionStatement_getWorkConditionStatement", data);
        setWorkConditionStatementParts(data.workConditionStatementParts);
      },
    }
  );

  useEffect(() => {
    setWorkConditionStatementParts(data?.workConditionStatementParts);
  }, [data]);

  return (
    <>
      <TableRow key={WorkConditionStatement.id}>
        <TableCell>{WorkConditionStatement.title}</TableCell>
        <TableCell>
          {convertToPersianDigitsWithComma(
            WorkConditionStatement.amountProvidedByContractor
          )
            ?.toString()
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
        </TableCell>
        <TableCell>
          {new Date(
            WorkConditionStatement?.dateProvidedByContractor
          ).toLocaleDateString("fa-IR")}
        </TableCell>

        {!isConsultant && (
          <>
            <TableCell>
              {convertToPersianDigitsWithComma(
                WorkConditionStatement.amountConfirmedByConsultant
              )
                ?.toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
            </TableCell>
            <TableCell>
              {new Date(
                WorkConditionStatement?.dateConfirmedByConsultant
              ).toLocaleDateString("fa-IR")}
            </TableCell>
          </>
        )}

        <TableCell>
          {convertToPersianDigitsWithComma(
            WorkConditionStatement.amountApprovedByEmployer
          )}
        </TableCell>
        <TableCell>
          {new Date(
            WorkConditionStatement?.dateApprovedByEmployer
          ).toLocaleDateString("fa-IR")}
        </TableCell>
        <TableCell>
          {convertToPersianDigitsWithComma(WorkConditionStatement.amountPaid)
            ?.toString()
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
        </TableCell>
        <TableCell>
          {new Date(WorkConditionStatement?.datePaid).toLocaleDateString(
            "fa-IR"
          )}
        </TableCell>
        <TableCell>
          <Button
            variant="text"
            color="success"
            href={
              API_FILE_DOWNLOAD +
              (WorkConditionStatement.financialCoverFileName || "")
            }
            target="_blank"
          >
            {WorkConditionStatement.financialCoverFileName}
          </Button>
        </TableCell>
        <TableCell>
          <div className="flex w-full justify-end px-0">
            <div className="flex gap-2 w-fit place-self-end ">
              <Button
                variant="text"
                sx={{
                  color: primary,
                  "&:hover": {
                    color: primary,
                  },
                }}
                onClick={() => {
                  setAddWorkConditionStatementPartModal({
                    open: true,
                    WorkConditionStatementPart:
                      {} as WorkConditionStatementPart,
                    WorkConditionStatementId: WorkConditionStatement.id,
                  });
                }}
                className="whitespace-nowrap"
              >
                <Add />
                افزودن زیرمجموعه
              </Button>
              {/* <Tooltip title={"افزودن زیرمجموعه"}>
                <IconButton
                  sx={{
                    borderRadius: "10px",
                    background: primary,
                    color: secondaryDark,
                    "&:hover": {
                      background: primaryLight,
                    },
                    gap: "0.5rem",
                  }}
                  onClick={() => {
                    setAddWorkConditionStatementPartModal({
                      open: true,
                      WorkConditionStatementPart:
                        {} as WorkConditionStatementPart,
                      WorkConditionStatementId: WorkConditionStatement.id,
                    });
                  }}
                >
                  <Add />
                </IconButton>
              </Tooltip> */}
              <Button
                variant="text"
                sx={{
                  color: secondaryDark,
                  "&:hover": {
                    color: secondaryDark,
                  },
                }}
                onClick={() => {
                  setNewWorkConditionStatement({
                    amountApprovedByEmployer:
                      WorkConditionStatement.amountApprovedByEmployer,
                    amountConfirmedByConsultant:
                      WorkConditionStatement.amountConfirmedByConsultant,
                    amountPaid: WorkConditionStatement.amountPaid,
                    amountProvidedByContractor:
                      WorkConditionStatement.amountProvidedByContractor,
                    dateApprovedByEmployer: new Date(
                      WorkConditionStatement.dateApprovedByEmployer
                    ),
                    dateConfirmedByConsultant: new Date(
                      WorkConditionStatement.dateConfirmedByConsultant
                    ),
                    datePaid: new Date(WorkConditionStatement.datePaid),
                    dateProvidedByContractor: new Date(
                      WorkConditionStatement.dateProvidedByContractor
                    ),
                    filledBy: WorkConditionStatement.filledBy,
                    id: WorkConditionStatement.id,
                    operationPeriodEndDate: new Date(
                      WorkConditionStatement.operationPeriodEndDate
                    ),
                    operationPeriodStartDate: new Date(
                      WorkConditionStatement.operationPeriodStartDate
                    ),
                    title: WorkConditionStatement.title,
                    workConditionStatementTableId:
                      WorkConditionStatement.workConditionStatementTableId,
                  });
                  setEditMode(true);
                }}
              >
                <RiFileEditFill className="w-6 h-6" />
                {/* ویرایش */}
              </Button>
              {/*
              <Tooltip title={"ویرایش"}>
                <IconButton
                  sx={{
                    borderRadius: "10px",
                    background: secondaryLighter,
                    color: secondaryDark,
                    "&:hover": {
                      background: primaryLight,
                    },
                    gap: "0.5rem",
                  }}
                  onClick={() => {
                    setNewWorkConditionStatement(WorkConditionStatement);
                    setEditMode(true);
                  }}
                >
                  <EditOutlined />
                </IconButton>
              </Tooltip>
              */}

              <Button
                variant="text"
                className="text-red-50"
                sx={{
                  // color: Red,
                  "&:hover": {
                    color: Red,
                  },
                }}
                onClick={() => {
                  void deleteWorkConditionStatement({
                    variables: {
                      id: WorkConditionStatement.id,
                    },
                  }).then(() => {
                    setNewWorkConditionStatement({} as WorkConditionStatement);
                    void refetch();
                  });
                }}
              >
                <CancelOutlined />
                {/* حذف */}
              </Button>

              {/*   
              <Tooltip title={"حذف"}>
                <IconButton
                  sx={{
                    borderRadius: "10px",
                    background: Red,
                    color: "white",
                    "&:hover": {
                      background: RedLight,
                      color: Red,
                    },
                    gap: "0.5rem",
                  }}
                  onClick={() => {
                    void deleteWorkConditionStatement({
                      variables: {
                        id: WorkConditionStatement.id,
                      },
                    }).then(() => {
                      setNewWorkConditionStatement(
                        {} as WorkConditionStatement
                      );
                      void refetch();
                    });
                  }}
                >
                  <CancelOutlined />
                </IconButton>
              </Tooltip> */}
            </div>
          </div>
        </TableCell>
      </TableRow>
      {/* {JSON.stringify(WorkConditionStatementParts)} */}
      {WorkConditionStatementParts?.map(
        (WorkConditionStatementPart: WorkConditionStatementPart, index) => (
          <TableRow
            key={WorkConditionStatementPart.id}
            sx={{
              backgroundColor: primaryTransparent,
              borderLeft: `2px solid ${primary}`,
            }}
          >
            <TableCell>
              {WorkConditionStatement.title + " - " + String(index + 1)}
            </TableCell>

            <TableCell>
              {/* {convertToPersianDigits(
                WorkConditionStatementPart.amountProvidedByContractor
              )
                ?.toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")} */}
            </TableCell>
            <TableCell>
              {/* {new Date(
                WorkConditionStatementPart?.dateProvidedByContractor
              ).toLocaleDateString("fa-IR")} */}
            </TableCell>
            <TableCell>
              {/* {convertToPersianDigits(
                WorkConditionStatementPart.amountConfirmedByConsultant
              )
                ?.toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")} */}
            </TableCell>
            <TableCell>
              {/* {new Date(
                WorkConditionStatementPart?.dateConfirmedByConsultant
              ).toLocaleDateString("fa-IR")} */}
            </TableCell>
            <TableCell>
              {/* {convertToPersianDigits(
                WorkConditionStatementPart.amountApprovedByEmployer
              )
                ?.toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")} */}
            </TableCell>
            <TableCell>
              {/* {new Date(
                WorkConditionStatementPart?.dateApprovedByEmployer
              ).toLocaleDateString("fa-IR")} */}
            </TableCell>
            <TableCell>
              {convertToPersianDigits(WorkConditionStatementPart.amountPaid)
                ?.toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
            </TableCell>
            <TableCell>
              {new Date(
                WorkConditionStatementPart?.datePaid
              ).toLocaleDateString("fa-IR")}
            </TableCell>
            <TableCell></TableCell>

            <TableCell>
              <div className="flex w-full justify-end px-0">
                <div className="flex gap-2 w-fit place-self-end ">
                  <Tooltip title={"ویرایش"}>
                    <Button
                      variant="text"
                      sx={{
                        color: secondaryDark,
                        "&:hover": {
                          color: secondaryDark,
                        },
                      }}
                      onClick={() => {
                        setAddWorkConditionStatementPartModal({
                          open: true,
                          WorkConditionStatementPart:
                            WorkConditionStatementPart,
                          WorkConditionStatementId: WorkConditionStatement.id,
                        });
                      }}
                    >
                      <RiFileEditFill className="w-6 h-6" />
                      {/* ویرایش */}
                    </Button>
                  </Tooltip>

                  <Tooltip title={"حذف"}>
                    <Button
                      variant="text"
                      className="text-red-50"
                      sx={{
                        // color: Red,
                        "&:hover": {
                          color: Red,
                        },
                      }}
                      onClick={() => {
                        void deleteWorkConditionStatementPart({
                          variables: {
                            id: WorkConditionStatementPart.id,
                          },
                        }).then(() => {
                          setNewWorkConditionStatement(
                            {} as WorkConditionStatement
                          );
                          void refetch();
                          void WorkConditionStatementRefetch();
                        });
                      }}
                    >
                      <CancelOutlined />
                      {/* حذف */}
                    </Button>
                  </Tooltip>
                </div>
              </div>
            </TableCell>
          </TableRow>
        )
      )}
    </>
  );
}
