/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { DownloadOutlined } from "@mui/icons-material";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import {
  Box,
  Button,
  Checkbox,
  Table,
  TableHead,
  Typography,
} from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers";
import React, { useEffect, useState } from "react";
import { BsPersonAdd } from "react-icons/bs";
import {
  ComplaintStateStatus,
  useGetChildrenOfParentLazyQuery,
  useGetComplaintQuery,
  useSendAssignToJusticeExpertSmsMutation,
  useUpdateComplaintFullMutation,
} from "../../../generated-types";
import { useAlertStore } from "../../Context/AlertStore";
import { getComplaintStateWithEnum } from "../../functions/ComplaintStatesFunc";
import { HandlingType } from "../../gql/graphql";
import { background, secondary } from "../../theme/color";
import FaTextField from "../FaComponents/FaTextField";
import FileBox from "../FileBox";
import NewModal from "../Modals";

interface Props {
  open: boolean;
  onClose: () => void;
  complaintId: number;
}
const DCModal = ({ open, onClose, complaintId }: Props) => {
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();
  const [mode, setMode] = React.useState<
    "expert" | "official" | "judiciary" | "none" | "letter"
  >("letter");
  const [selectedExpertsId, setSelectedExpertsId] = React.useState<string[]>(
    []
  );

  const [letterNum, setLetterNum] = useState("");
  const [letterDate, setLetterDate] = useState<Date | null>(null);

  const [SelectionFile, setSelectionFile] = useState<File>();

  const [GetChildrenOfParent, { data }] = useGetChildrenOfParentLazyQuery({});
  const [UpdateComplaint] = useUpdateComplaintFullMutation();
  const [SendAssignToJusticeExpertSMS] =
    useSendAssignToJusticeExpertSmsMutation({
      variables: {
        complaintId: complaintId,
        expertId: selectedExpertsId[0],
      },
    });

  useEffect(() => {
    void GetChildrenOfParent({
      variables: {
        parentType:
          mode === "expert"
            ? HandlingType.SelectedExpertsOfTheSupremeTechnicalCouncil
            : mode === "official"
            ? HandlingType.CouncilOfOfficialJusticeExperts
            : HandlingType.JudiciaryExpertsCenter,
      },
      onCompleted(data) {
        console.log("🎶 ~ onCompleted ~ data:", data);
      },
      onError(error) {
        console.log("❌ ~ onError ~ error", error);
      },
    });
  }, [GetChildrenOfParent, mode]);

  const ModalBox = () => {
    switch (mode) {
      case "none":
        return (
          <Box
            sx={{
              display: "grid",
              gap: 2,
              gridTemplateColumns: "1fr 1fr 1fr",
              width: "100%",
            }}
          >
            <div className="flex col-span-full">
              {/* a back button for letter page */}
              <Button
                color="success"
                variant="outlined"
                onClick={() => setMode("letter")}
              >
                <ChevronRightIcon />
                بازگشت
              </Button>
            </div>
            <Button
              color="success"
              fullWidth
              variant="outlined"
              sx={{
                aspectRatio: "5/3",
              }}
              onClick={() => {
                void UpdateComplaint({
                  variables: {
                    input: {
                      id: complaintId,
                      handlingType:
                        HandlingType.SelectedExpertsOfTheSupremeTechnicalCouncil,
                    },
                  },
                  onCompleted(data) {
                    if (data?.complaint_updateComplaint?.status?.code == 1) {
                      void UpdateComplaint({
                        variables: {
                          input: {
                            id: complaintId,
                            complaintStateId: getComplaintStateWithEnum(
                              ComplaintStateStatus.DeterminingCaseExpert
                            ).id,
                          },
                        },
                      });
                      setAlertType("success");
                      setAlertMessage("با موفقیت نوع کارشناسی تعیین شد");
                      setAlertOpen(true);
                      setMode("expert");
                    } else {
                      setAlertType("error");
                      setAlertMessage("خطا در تعیین نوع کارشناسی");
                      setAlertOpen(true);
                    }
                  },
                  onError(error) {
                    console.log("❌ ~ onError ~ error", error);
                    setAlertType("error");
                    setAlertMessage(
                      "خطا در تعیین نوع کارشناسی" + error.message
                    );
                    setAlertOpen(true);
                  },
                });
              }}
            >
              کارشناسان منتخب شورای عالی فنی
            </Button>
            <Button
              color="error"
              fullWidth
              variant="outlined"
              onClick={() => {
                void UpdateComplaint({
                  variables: {
                    input: {
                      id: complaintId,
                      handlingType:
                        HandlingType.CouncilOfOfficialJusticeExperts,
                    },
                  },
                  onCompleted(data) {
                    if (data?.complaint_updateComplaint?.status?.code == 1) {
                      void UpdateComplaint({
                        variables: {
                          input: {
                            id: complaintId,
                            complaintStateId: getComplaintStateWithEnum(
                              ComplaintStateStatus.WaitingForDeterminingExpertsCouncilPayment
                            ).id,
                          },
                        },
                      });
                      setAlertType("success");
                      setAlertMessage("با موفقیت نوع کارشناسی تعیین شد");
                      setAlertOpen(true);
                      setMode("official");
                    } else {
                      setAlertType("error");
                      setAlertMessage("خطا در تعیین نوع کارشناسی");
                      setAlertOpen(true);
                    }
                  },
                  onError(error) {
                    console.log("❌ ~ onError ~ error", error);
                    setAlertType("error");
                    setAlertMessage(
                      "خطا در تعیین نوع کارشناسی" + error.message
                    );
                    setAlertOpen(true);
                  },
                });
                // onClose();
              }}
            >
              کانون کارشناسان رسمی دادگستری
            </Button>

            <Button
              color="warning"
              fullWidth
              variant="outlined"
              onClick={() => {
                void UpdateComplaint({
                  variables: {
                    input: {
                      id: complaintId,
                      handlingType: HandlingType.JudiciaryExpertsCenter,
                    },
                  },
                  onCompleted(data) {
                    if (data?.complaint_updateComplaint?.status?.code == 1) {
                      void UpdateComplaint({
                        variables: {
                          input: {
                            id: complaintId,
                            complaintStateId: getComplaintStateWithEnum(
                              ComplaintStateStatus.WaitingForDeterminingExpertsCouncilPayment
                            ).id,
                          },
                        },
                      });
                      setAlertType("success");
                      setAlertMessage("با موفقیت نوع کارشناسی تعیین شد");
                      setAlertOpen(true);
                      setMode("judiciary");
                    } else {
                      setAlertType("error");
                      setAlertMessage("خطا در تعیین نوع کارشناسی");
                      setAlertOpen(true);
                    }
                  },
                  onError(error) {
                    console.log("❌ ~ onError ~ error", error);
                    setAlertType("error");
                    setAlertMessage(
                      "خطا در تعیین نوع کارشناسی" + error.message
                    );
                    setAlertOpen(true);
                  },
                });
              }}
            >
              مرکز کارشناسان قوه قضائیه
            </Button>
          </Box>
        );

      case "expert":
        return (
          <Box
            sx={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
              gap: 2,
            }}
          >
            <Button
              color="success"
              fullWidth
              variant="outlined"
              onClick={() => setMode("none")}
            >
              <ChevronRightIcon />
              بازگشت
            </Button>
            <Box display={"flex"} justifyContent={"space-between"}>
              <p>کارشناسان منتخب شورای عالی فنی</p>
              <Button
                variant={"outlined"}
                color={"success"}
                href={`/signUp/determiningCaseExpert/newUser/${
                  complaintId || ""
                }`}
              >
                <BsPersonAdd />
                افزودن کارشناس جدید
              </Button>
            </Box>
            <Table
              sx={{
                outline: "1px solid #000",
                borderRadius: "0.5rem",
                overflow: "hidden",
                "& td": {
                  padding: "0.5rem",
                  textAlign: "center",
                },
              }}
            >
              <TableHead
                sx={{
                  background: secondary,
                  color: "#fff",
                  "& td": {
                    padding: "0.7rem",
                    textAlign: "center",
                  },
                }}
              >
                <tr>
                  <td>نام</td>
                  <td>...</td>
                </tr>
              </TableHead>
              <tbody>
                {data?.user_getChildrenOfParent?.result?.map((item, index) => (
                  <tr
                    key={index}
                    style={{
                      backgroundColor: selectedExpertsId.includes(
                        item?.id as string
                      )
                        ? "#f0f0f0"
                        : "#fff",
                    }}
                  >
                    <td>{item?.fullName}</td>
                    <td>
                      <Checkbox
                        onChange={() => {
                          if (selectedExpertsId.includes(item?.id as string)) {
                            setSelectedExpertsId((prev) =>
                              prev.filter((id) => id !== item?.id)
                            );
                            return;
                          }
                          setSelectedExpertsId((prev) => [
                            ...prev,
                            item?.id as string,
                          ]);
                        }}
                        checked={selectedExpertsId.includes(item?.id as string)}
                      />
                      {/* <Button
                        onClick={() => {
                          if(selectedExpertsId.includes(item?.id as string)){
                            setSelectedExpertsId((prev) => prev.filter((id) => id !== item?.id));
                            return;
                          }
                          setSelectedExpertsId((prev) => [
                            ...prev,
                            item?.id as string,
                          ]);
                        }}
                      >
                        انتخاب
                      </Button> */}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <Button
              color="success"
              variant="outlined"
              onClick={() => {
                console.log("selectedExpertsId", selectedExpertsId);
                void UpdateComplaint({
                  variables: {
                    input: {
                      id: complaintId,
                      councilExpertIds: selectedExpertsId,
                    },
                  },
                  onCompleted(data) {
                    void UpdateComplaint({
                      variables: {
                        input: {
                          id: complaintId,
                          complaintStateId: getComplaintStateWithEnum(
                            ComplaintStateStatus.DeterminingMeetingByMailRoomExpert
                          ).id,
                        },
                      },
                    });
                    void SendAssignToJusticeExpertSMS();
                    console.log("🚀 ~ onCompleted ~ data", data);
                    alert("کارشناسان انتخاب شده با موفقیت ثبت شدند");
                    window.location.reload();
                  },
                });
              }}
              fullWidth
              disabled={selectedExpertsId.length === 0}
            >
              تایید و ارسال
            </Button>
          </Box>
        );

      case "official":
        return (
          <Box display={"flex"} flexDirection={"column"} gap={2} width={"100%"}>
            <Button
              color="error"
              fullWidth
              variant="outlined"
              onClick={() => setMode("none")}
            >
              <ChevronRightIcon />
              بازگشت
            </Button>
            <Typography mt={5} variant="h6">
              فایل نامه ارسالی به کانون کارشناسان رسمی دادگستری
            </Typography>
            <Button
              color="success"
              fullWidth
              variant="contained"
              onClick={() => setMode("none")}
              sx={{
                padding: "3rem",
              }}
            >
              <DownloadOutlined />
              دانلود نامه
            </Button>
          </Box>
        );

      case "judiciary":
        return (
          <Box display={"flex"} flexDirection={"column"} gap={2} width={"100%"}>
            <Button
              color="warning"
              fullWidth
              variant="outlined"
              onClick={() => setMode("none")}
            >
              <ChevronRightIcon />
              بازگشت
            </Button>
            <Typography mt={5} variant="h6">
              فایل نامه ارسالی به مرکز کارشناسان قوه قضائیه
            </Typography>
            <Button
              color="success"
              fullWidth
              variant="contained"
              onClick={() => setMode("none")}
              sx={{
                padding: "3rem",
              }}
            >
              <DownloadOutlined />
              دانلود نامه
            </Button>
          </Box>
        );

      default:
        return <></>;
    }
  };

  const { data: complaintData } = useGetComplaintQuery({
    variables: {
      id: complaintId,
    },
    onCompleted(data) {
      if (data?.complaint_getComplaint?.result?.id) {
        setLetterDate(
          new Date(
            data?.complaint_getComplaint?.result?.assignToExpertLetterDate || ""
          )
        );
        setLetterNum(
          data?.complaint_getComplaint?.result?.assignToExpertLetterNum || ""
        );
      }
    },
  });
  return (
    <NewModal
      title="تعیین کارشناس پرونده"
      open={open}
      onClose={() => {
        setMode("none");
        onClose();
      }}
      background={background}
      isCloseable
      width={"50%"}
    >
      <ModalBox />

      {mode === "letter" && (
        <div
          className="col-span-full grid-cols-2 grid gap-5 w-full"
          style={{
            gridColumn: "1 / -1",
          }}
        >
          <FileBox className="col-span-full" fileUrl="" />

          <FaTextField
            label="شماره نامه تعیین کارشناس"
            placeholder="شماره نامه تعیین کارشناس"
            value={letterNum}
            onChange={(e) => setLetterNum(e.target.value)}
          />

          <DatePicker
            label="تاریخ نامه تعیین کارشناس"
            value={letterDate}
            onChange={(date) => setLetterDate(date)}
          />

          <button
            className="bg-primary-500 col-span-full text-white rounded-md py-2 border-none text-lg hover:shadow-lg cursor-pointer"
            onClick={() => {
              void UpdateComplaint({
                variables: {
                  input: {
                    id: complaintId,
                    assignToExpertLetterNum: letterNum,
                    assignToExpertLetterDate: letterDate,
                  },
                },
                onCompleted(data) {
                  if (data?.complaint_updateComplaint?.status?.code == 1) {
                    setAlertType("success");
                    setAlertMessage("با موفقیت انجام شد");
                    setAlertOpen(true);
                    setMode("none");
                  } else {
                    setAlertType("error");
                    setAlertMessage("خطا در انجام عملیات");
                    setAlertOpen(true);
                  }
                },
                onError(error) {
                  console.log("❌ ~ onError ~ error", error);
                  setAlertType("error");
                  setAlertMessage("خطا در انجام عملیات" + error.message);
                  setAlertOpen(true);
                },
              });
            }}
          >
            ثبت
          </button>
        </div>
      )}
    </NewModal>
  );
};

export default DCModal;
