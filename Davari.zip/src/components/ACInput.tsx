/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  ClickAwayListener,
  Menu,
  MenuItem,
  OutlinedTextFieldProps,
  TextField,
  TextFieldProps,
} from "@mui/material";
import React, { useEffect } from "react";
interface Props extends OutlinedTextFieldProps {
  getMoreData?: () => void;
  loading?: boolean;
  options?: {
    value: string;
    label: string;
  }[];
  setSelectValue?: (value: any) => void;
  selectValue?: any;
}
const ACInput = ({ getMoreData, variant = "outlined", ...props }: Props) => {
  const [isOnFocus, setIsOnFocus] = React.useState(false);
  const [menuIsOpen, setMenuIsOpen] = React.useState(false);
  const [selectValue, setSelectValue] = React.useState(props.selectValue);
  const ref = React.useRef<HTMLInputElement>(null);
  React.useEffect(() => {
    setIsOnFocus(false);
  }, [props.value]);

  useEffect(() => {
    if (isOnFocus) {
      setMenuIsOpen(true);
    } else {
      setMenuIsOpen(false);
    }
  }, [isOnFocus]);

  useEffect(() => {
    props.setSelectValue && props.setSelectValue(selectValue);
    console.log("selectValue", selectValue);
  }, [props, selectValue]);

  return (
    <ClickAwayListener onClickAway={() => setIsOnFocus(false)}>
      <>
        <TextField
          ref={ref}
          {...props}
          value={
            props.options?.find((o) => o.value === selectValue)?.label || ""
          }
          onClick={() => {
            setIsOnFocus(true);
            setMenuIsOpen(true);
            getMoreData?.();
          }}
          inputMode="search"
          fullWidth
          variant={variant}
        />
        <Menu
          open={menuIsOpen}
          anchorEl={ref.current}
          onClose={() => setMenuIsOpen(false)}
          disableAutoFocus
          disableScrollLock
          disablePortal
          sx={{
            "& .MuiMenu-paper": {
              maxHeight: 400,
              backgroundColor: "white",
            },
          }}
        >
          {props.options?.map((option, i) => (
            <MenuItem
              key={option.value}
              value={option.value}
              onClick={() => {
                // props.onChange &&
                //   props.onChange({
                //     target: {
                //       value: option.value,
                //     },
                //   } as React.ChangeEvent<HTMLInputElement>);

                setSelectValue(option.value);
                setIsOnFocus(false);
              }}
              className={`${option.value === selectValue ? "bg-gray-30" : ""}`}
            >
              {option.label}
            </MenuItem>
          ))}
          {/* a load more item */}
          {getMoreData && (
            <MenuItem
              onClick={() => {
                getMoreData();
              }}
            >
              دریافت بیشتر
            </MenuItem>
          )}
          {props.loading && <div>Loading...</div>}
        </Menu>
      </>
    </ClickAwayListener>
  );
};

export default ACInput;
