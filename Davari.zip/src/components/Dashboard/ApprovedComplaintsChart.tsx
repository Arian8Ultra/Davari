/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import React, { useMemo, useState } from "react";
import { useGetApprovedComplaintsQuery } from "../../../generated-types";
import { convertToPersianDigits, getFaMonth } from "../../functions/Functions";
import { LineChart } from "@mui/x-charts/LineChart";

const ApprovedComplaintsChart = () => {
  const today = useMemo(() => new Date(), []);
  const [mode, setMode] = useState<"daily" | "monthly" | "yearly">("daily");

  const { data, loading, error } = useGetApprovedComplaintsQuery({
    variables: {
      // set end date to now
      endDate: today,
      // set start date to 30 days ago
      startDate: new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000),
    },
  });

  const seriesY = () => {
    switch (mode) {
      case "daily":
        return data?.dashboard_getDailyApprovedComplaints?.result?.map(
          (item) => item?.count || 0
        );
      case "monthly":
        return data?.dashboard_getMonthlyApprovedComplaints?.result?.map(
          (item) => item?.count || 0
        );
      case "yearly":
        return data?.dashboard_getYearlyApprovedComplaints?.result?.map(
          (item) => item?.count || 0
        );
    }
  };
  const seriesX = () => {
    switch (mode) {
      case "daily":
        return data?.dashboard_getDailyApprovedComplaints?.result?.map((item) =>
          new Date(item?.date).toLocaleDateString("fa-IR")
        );
      case "monthly":
        return data?.dashboard_getMonthlyApprovedComplaints?.result?.map(
          (item) => getFaMonth(((item?.monthNum || 0) + 8) % 12)
        );
      case "yearly":
        return data?.dashboard_getYearlyApprovedComplaints?.result?.map(
          (item) => convertToPersianDigits((item?.yearNum || 622) - 621)
        );
    }
  };

  return (
    <div className="flex flex-col bg-white-50 shadow-xl outline-1 outline outline-gray-40 rounded-2xl">
      <div className="flex items-center justify-start border-b p-5 border-gray-40 text-medium_16">
        تعداد درخواست های تایید شده
      </div>

      <div className="flex flex-col items-center justify-center p-5 ">
        <div className="grid grid-cols-3 w-fit shadow-xl rounded-full gap-0">
          <button
            onClick={() => setMode("daily")}
            className={`${
              mode === "daily"
                ? "bg-black-100 text-white-50"
                : " bg-white-100 text-black-100"
            } rounded-full px-6 py-2 text-bold_16 ease-linear duration-200 whitespace-nowrap overflow-hidden text-ellipsis border-0 cursor-pointer hover:shadow-lg`}
          >
            روزانه
          </button>
          <button
            onClick={() => setMode("monthly")}
            className={`${
              mode === "monthly"
                ? "bg-black-100 text-white-50"
                : " bg-white-100 text-black-100"
            } rounded-full px-6 py-2 text-bold_16 ease-linear duration-200 whitespace-nowrap overflow-hidden text-ellipsis border-0 cursor-pointer hover:shadow-lg`}
          >
            ماهانه
          </button>
          <button
            onClick={() => setMode("yearly")}
            className={`${
              mode === "yearly"
                ? "bg-black-100 text-white-50"
                : " bg-white-100 text-black-100"
            } rounded-full px-6 py-2 text-bold_16 ease-linear duration-200 whitespace-nowrap overflow-hidden text-ellipsis border-0 cursor-pointer hover:shadow-lg`}
          >
            سالانه
          </button>
        </div>
        <div className="w-full aspect-[20/9]">
          {/* <CacheProvider value={cacheLtr}> */}
          <LineChart
            xAxis={[
              {
                data: seriesX() || ["همه"],
                scaleType: "point",
              },
            ]}
            series={[
              {
                label: "تعداد درخواست های تایید شده",
                data: seriesY() || [0],
                connectNulls: true,
                showMark: true,
              },
            ]}
            sx={{
              direction: "ltr",
              overflow: "visible",
            }}
          />
          {/* </CacheProvider> */}
        </div>
      </div>
    </div>
  );
};

export default ApprovedComplaintsChart;
