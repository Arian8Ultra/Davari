/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { LineChart } from "@mui/x-charts/LineChart";
import { useMemo } from "react";
import { useGetExpertCountQuery } from "../../../generated-types";
import { BarChart } from "@mui/x-charts";

const ExpertCountChart = () => {
  const { data, loading, error } = useGetExpertCountQuery();

  const seriesY = () => {
    return data?.dashboard_getExpertCount?.result?.map(
      (item) => item?.count || 0
    );
  };
  const seriesX = () => {
    return data?.dashboard_getExpertCount?.result?.map(
      (item) => item?.expertName
    );
  };

  return (
    <div className="flex flex-col bg-white-50 shadow-xl outline-1 outline outline-gray-40 rounded-2xl">
      <div className="flex items-center justify-start border-b p-5 border-gray-40 text-medium_16">
        تعداد درخواست های هر کارشناس
      </div>

      <div className="flex flex-col items-center justify-center p-5 ">
        <div className="w-full aspect-[20/9]">
          {/* <CacheProvider value={cacheLtr}> */}
          <BarChart
            loading={loading}
            xAxis={[
              {
                data: seriesX() || ["همه"],
                scaleType: "band",
              },
            ]}
            series={[
              {
                label: "تعداد رای های صادر شده",
                data: seriesY() || [0],
              },
            ]}
            sx={{
              direction: "ltr",
              overflow: "visible",
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default ExpertCountChart;
