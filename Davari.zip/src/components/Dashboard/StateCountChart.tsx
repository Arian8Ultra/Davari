/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { LineChart } from "@mui/x-charts/LineChart";
import { useGetStateCountQuery } from "../../../generated-types";
import { BarChart } from "@mui/x-charts/BarChart";
import { primary } from "../../theme/color";
import { CacheProvider } from "@emotion/react";
import createCache from "@emotion/cache";
const StateCountChart = () => {
  const { data, loading, error } = useGetStateCountQuery();

  const seriesY = () => {
    return data?.dashboard_getStateCount?.result
      ?.filter((a) => a?.count || 0 > 0)
      ?.map((item) => item?.count || 0);
  };
  const seriesX = () => {
    return data?.dashboard_getStateCount?.result
      ?.filter((a) => a?.count || 0 > 0)
      ?.map((item) => item?.stateName);
  };
  const cacheLtr = createCache({
    key: "muiltr",
  });

  return (
    <div className="flex flex-col bg-white-50 shadow-xl outline-1 outline outline-gray-40 rounded-2xl col-span-full">
      <div className="flex items-center justify-start border-b p-5 border-gray-40 text-medium_16">
        تعداد درخواست های هر وضعیت
      </div>

      <div className="flex flex-col items-center justify-center p-1 ">
        <div className="w-full md:w-full rtl h-dvh" dir="rtl">
        {/* <CacheProvider value={cacheLtr}> */}
          <CacheProvider value={cacheLtr}>
          <BarChart
          loading={loading}
            borderRadius={20}
            yAxis={[
              {
                data: seriesX() || ["همه"],
                scaleType: "band",
                // fill: "rgba(0, 0, 0, 0.87)",
                // stroke: "rgba(0, 0, 0, 0.87)",
                labelStyle: {
                  backgroundColor: primary,
                },
                // change the orientation of the x-axis labels
              },
            ]}
            slotProps={{
              bar:{
                height: '50px',
              }
            }}
            barLabel="value"
            // tooltip={true}
            layout="horizontal"
            series={[
              {
                label: "تعداد درخواست ها",
                data: seriesY() || [0],
                // layout: "horizontal",
                // connectNulls: true,
                // showMark: true,
              },
            ]}
            sx={{
              direction: "ltr",
              overflow: "visible",
            }}
          />

          </CacheProvider>
        </div>
      </div>
    </div>
  );
};

export default StateCountChart;
