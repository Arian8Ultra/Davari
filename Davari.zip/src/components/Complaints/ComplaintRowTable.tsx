/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { useMutation, useQuery } from "@apollo/client";
import { FileOpenOutlined } from "@mui/icons-material";
import {
  Autocomplete,
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
} from "@mui/material";
import { grey, red } from "@mui/material/colors";
import React, { useState } from "react";
import { BsCloudUploadFill } from "react-icons/bs";
import { NumericFormat } from "react-number-format";
import { useNavigate } from "react-router-dom";
import {
  useAddComplaintFileMutationMutation,
  useGetFileFullLazyQuery,
  useGetUserQuery,
  useSendAssignToExpertSmsMutation,
  useSendComplaintCancellationLetterMutation,
  useSendComplaintGotCancelledSmsMutation,
  useSendFirstPaymentAnnouncementRequestLetterMutation,
  useSendFirstPaymentAnnouncementSmsMutation,
  useSendUploadDecreeAnnouncementSmsMutation,
  useSendUploadingSignedDecreeLetterMutation,
  useUpdateComplaintFullMutation,
} from "../../../generated-types";
import { UPLOAD_FILE } from "../../api/upload";
import { useAlertStore } from "../../Context/AlertStore";
import { useUserStore } from "../../Context/UserStore";
import { getComplaintStateWithEnum } from "../../functions/ComplaintStatesFunc";
import { convertToPersianDigits } from "../../functions/Functions";
import {
  ArchiveComplaintDocument,
  ComplaintStateStatus,
  User,
} from "../../gql/graphql";
import { GET_USER_QUERIABLE } from "../../GraphQL/Users/Queries";
import {
  Green,
  GreenLight,
  Red,
  RedLight,
  background,
  primary,
  primaryDark,
  primaryLightTransparent,
  secondary,
  secondaryDark,
} from "../../theme/color";
import FaTextField from "../FaComponents/FaTextField";
import FileBox from "../FileBox";
import NewModal from "../Modals";
import LetterOfCouncilofMinistersModal from "./LetterOfCouncilofMinistersModal";
interface Props {
  status: string;
  contractCode: string;
  contractTitle: string;
  id: number;
  accuser: string;
  accused: string;
  alert?: React.ReactNode;
  type?:
    | "accused"
    | "accuser"
    | "assigned"
    | "chief"
    | "mainRoomExpert"
    | "juryExpert"
    | "all";
  acussedId?: string;
  acusserId?: string;
  state?: ComplaintStateStatus;
  complaintId?: number;
  complaintCode?: string;
  refetch?: () => void;
  contractId?: number;
  trackingCode?: string;
  assignedId?: string;
  date?: Date;
  councilExpert?: string;
}
const ComplaintRowTable = (props: Props) => {
  const [open, setOpen] = useState(false);
  const [files, setFiles] = useState<File>();
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const user = useUserStore((state) => state.user);
  const navigate = useNavigate();
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();
  const [voiceFiles, setVoiceFiles] = useState<File>();

  const [
    openLetterOfCouncilofMinistersModal,
    setOpenLetterOfCouncilofMinistersModal,
  ] = useState(false);
  const [addModal, setAddModal] = useState({
    open: false,
  });

  const style = {
    width: "100%",
    border: `1px solid ${secondary}`,
    borderRadius: "0.5rem",
  };

  const [sendAssignToExpertSMS] = useSendAssignToExpertSmsMutation({
    variables: {
      complaintId: props.id,
    },
  });

  const [SendUploadDecreeAnnouncementSMS] =
    useSendUploadDecreeAnnouncementSmsMutation({
      variables: {
        complaintId: props.id,
      },
    });

  const [SendUploadingSignedDecreeLetter] =
    useSendUploadingSignedDecreeLetterMutation({
      variables: {
        complaintId: props.id,
        signDate: new Date().toISOString(),
      },
    });

  const [assignedUser, setAssignedUser] = useState<{
    fullName: string;
    id: string;
  }>();
  const [departmentsUsers, setDepartmentsUsers] = useState<User[]>([]);
  const [expertsCouncilPaymentCost, setExpertsCouncilPaymentCost] =
    useState<number>();
  const [updateComplaint] = useUpdateComplaintFullMutation();
  const [deleteComplaint] = useMutation(ArchiveComplaintDocument, {
    variables: {
      complaintId: props.id,
    },
    onCompleted() {
      props.refetch && props.refetch();
      setAlertMessage("درخواست داوری شما با موفقیت لغو شد");
      setAlertOpen(true);
      setAlertType("success");
      void sendComplaintGotCancelledSMS();
      void SendComplaintCancellationLetter();
    },
  });

  // const [assignedUser, setAssignedUser] = useState<{
  //   fullName: string;
  //   id: string;
  // }>();

  const { data: assignedUserData } = useGetUserQuery({
    variables: {
      id: props.assignedId || "",
    },
  });

  useQuery(GET_USER_QUERIABLE, {
    variables: {
      id: user.userType == "ORGANIZATION" ? user.id : user.parentId,
    },
    onCompleted(data) {
      console.log("IndivisualsFromOrg", data);
      setDepartmentsUsers(
        data.user_getUserQueryable?.result?.items[0]?.childUsers?.map(
          (user: any) => ({
            id: user.id,
            label: user.fullName,
          })
        )
      );
    },
  });

  const [addFile] = useAddComplaintFileMutationMutation();
  const [getFile] = useGetFileFullLazyQuery();
  const [SendFirstPaymentAnnouncementSMS] =
    useSendFirstPaymentAnnouncementSmsMutation({
      variables: {
        complaintId: props.id,
      },
    });
  const [SendFirstPaymentAnnouncementRequestLetter] =
    useSendFirstPaymentAnnouncementRequestLetterMutation({
      variables: {
        complaintId: props.id,
      },
    });
  const [sendComplaintGotCancelledSMS] =
    useSendComplaintGotCancelledSmsMutation({
      variables: {
        complaintId: props.id,
      },
    });

  const [SendComplaintCancellationLetter] =
    useSendComplaintCancellationLetterMutation({
      variables: {
        complaintId: props.id,
      },
    });

  const { data: accuserData } = useGetUserQuery({
    variables: {
      id: props.acusserId || "",
    },
  });

  const { data: accusedData } = useGetUserQuery({
    variables: {
      id: props.acussedId || "",
    },
  });

  const ActionButtons = () => {
    switch (props.state) {
      case ComplaintStateStatus.WaitingForAccuserToRegisterContract:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/updateByAccuser/contractPageToFill`
                  );
                }}
              >
                ادامه درخواست داوری
              </Button>
            </Box>
          );
        else {
          break;
        }
      case ComplaintStateStatus.WaitingForAccuserToRegisterComplaint:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addComplaint`
                  );
                }}
              >
                ادامه درخواست داوری
              </Button>
            </Box>
          );
        else {
          break;
        }
      // case ComplaintStateStatus.WaitingForAccusedToRegisterArbitrationTerms:
      //   if (props.type == "accuser")
      //     return (
      //       <Box
      //         display={"grid"}
      //         gridTemplateColumns={"repeat(2,1fr)"}
      //         mt={"1rem"}
      //         gap={"6rem"}
      //       >
      //         <Button
      //           sx={{
      //             borderRadius: "0.5rem",
      //             backgroundColor: Red,
      //             color: "white",
      //             "&:hover": {
      //               backgroundColor: red[100],
      //               color: Red,
      //             },
      //           }}
      //           onClick={() => {
      //             const agree = confirm(
      //               "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
      //             );
      //             if (agree) {
      //               void deleteComplaint();
      //             }
      //           }}
      //         >
      //           انصراف از درخواست داوری
      //         </Button>
      //         <Button
      //           sx={{
      //             borderRadius: "0.5rem",
      //             backgroundColor: primaryDark,
      //             color: "white",
      //             "&:hover": {
      //               backgroundColor: primary,
      //               color: "white",
      //             },
      //           }}
      //           onClick={() => {
      //             navigate(
      //               `/complaints/${props.contractId}/${props.id}/addComplaint`
      //             );
      //           }}
      //         >
      //           ادامه درخواست داوری
      //         </Button>
      //       </Box>
      //     );
      //   else {
      //     break;
      //   }

      case ComplaintStateStatus.WaitingForAccuserToRegisterArbitrationTerms:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addComplaint`
                  );
                }}
              >
                ادامه درخواست داوری
              </Button>
            </Box>
          );
        else {
          break;
        }
      case ComplaintStateStatus.WaitingForAccuserToRegisterArguments:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addArguements/0`
                  );
                }}
              >
                ادامه درخواست داوری و افزودن دعاوی
              </Button>
            </Box>
          );
        else {
          break;
        }

      case ComplaintStateStatus.WaitingForAccuserToApproveArguments:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addArguements/0`
                  );
                }}
              >
                ادامه درخواست داوری و افزودن دعاوی
              </Button>
            </Box>
          );
        else {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
        }

      case ComplaintStateStatus.WaitingForAccusedToRegisterContract:
        if (props.type == "accused") {
          if (user.userType == "INDIVIDUAL")
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <div className=""></div>
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Green,
                    color: props.assignedId ? "black" : "white",
                    "&:hover": {
                      backgroundColor: GreenLight,
                      color: Green,
                    },
                    "&:disabled": {
                      color: "black",
                      backgroundColor: GreenLight,
                    },
                  }}
                  className="disabled:text-black-100 bg-primary-500"
                  disabled={props.assignedId ? true : false}
                  onClick={() => {
                    setAddModal({
                      open: true,
                    });
                  }}
                >
                  {assignedUserData?.user_getUser?.result?.fullName
                    ? "تخصیص یافته به:  " +
                      assignedUserData?.user_getUser?.result?.fullName
                    : "ارسال درخواست داوری به کارشناس"}
                </Button>
              </Box>
            );
          else {
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <div className=""></div>

                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Green,
                    color: "white",
                    "&:hover": {
                      backgroundColor: GreenLight,
                      color: Green,
                    },
                  }}
                  onClick={() => {
                    navigate(
                      `/complaints/${props.contractId}/${props.id}/update/contractPageToFill`
                    );
                  }}
                >
                  پاسخ به درخواست داوری
                </Button>
              </Box>
            );
          }
        } else if (props.type == "assigned") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/update/contractPageToFill`
                  );
                }}
              >
                پاسخ به درخواست داوری
              </Button>
            </Box>
          );
        } else {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
        }
      case ComplaintStateStatus.WaitingForAccusedToRegisterArbitrationTerms:
        if (props.type == "accused" || props.type == "assigned")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addComplaint`
                  );
                }}
              >
                پاسخ به درخواست داوری
              </Button>
            </Box>
          );
        else {
          break;
        }
      case ComplaintStateStatus.WaitingForAccusedToAnswerArguments:
        if (props.type == "accused")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addArguements/1`
                  );
                }}
              >
                پاسخ به درخواست داوری
              </Button>
            </Box>
          );
        else {
          break;
        }
      case ComplaintStateStatus.WaitingForAccusedToApproveArgumentsAnswers:
        if (props.type == "accused")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addArguements/1`
                  );
                }}
              >
                پاسخ به درخواست داوری
              </Button>
            </Box>
          );
        else {
          break;
        }

      case ComplaintStateStatus.WaitingForAccuserToViewArguments:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addArguements/-1`
                  );
                }}
              >
                مشاهده لایحه دفاعیه
              </Button>
            </Box>
          );
        else {
          break;
        }

      case ComplaintStateStatus.WaitingForAccuserToApproveAccusedAnswers:
        if (props.type == "accuser")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    `/complaints/${props.contractId}/${props.id}/addArguements/-1`
                  );
                }}
              >
                مشاهده لایحه دفاعیه
              </Button>
            </Box>
          );
        else {
          break;
        }

      case ComplaintStateStatus.WaitingForChiefToAssign:
        if (props.type == "chief")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  setAddModal({
                    open: true,
                  });
                }}
              >
                ارسال درخواست داوری به کارشناس
              </Button>
            </Box>
          );
        else {
          break;
        }
      case ComplaintStateStatus.CheckingForBeingConstructive:
        if (props.type == "mainRoomExpert")
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(`/contract/${props.contractId}/${props.id}`, {
                    state: {
                      complaintId: props.id,
                    },
                  });
                }}
              >
                مشاهده قرارداد و بررسی احراز شرایط داوری
              </Button>
            </Box>
          );
        else {
          break;
        }
      case ComplaintStateStatus.WaitingForMailRoomExpertToGiveAnswersToArguments:
      case ComplaintStateStatus.WaitingForMailroomChiefToConfirmTechnicalCouncilOpinion:
        if (
          user.parentId == props.acusserId ||
          user.parentId == props.acusserId ||
          user.id == props.acusserId ||
          user.id == props.acusserId
        )
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
        return (
          <Box
            display={
              props.type == "chief" &&
              props.state ==
                ComplaintStateStatus.WaitingForMailroomChiefToConfirmTechnicalCouncilOpinion
                ? "grid"
                : "none"
            }
            gridTemplateColumns={"repeat(2,1fr)"}
            mt={"1rem"}
            gap={"6rem"}
          >
            <Button
              sx={{
                borderRadius: "0.5rem",
                backgroundColor: Green,
                color: "white",
                "&:hover": {
                  backgroundColor: GreenLight,
                  color: Green,
                },
              }}
              onClick={() => {
                navigate(
                  // complaints/:contractId/:complaintId/addArguements/:state
                  `/complaints/${props.contractId}/${props.id}/addArguements/7`,
                  {
                    state: {
                      complaintId: props.id,
                    },
                  }
                );
              }}
            >
              مشاهده دعاوی
            </Button>
          </Box>
        );
      case ComplaintStateStatus.AcceptedForBeingConstructiveWaitingForMailroomChiefToConfirm:
        if (
          user.parentId == props.acusserId ||
          user.parentId == props.acusserId ||
          user.id == props.acusserId ||
          user.id == props.acusserId
        )
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
        return (
          <Box
            display={
              props.type == "chief" &&
              props.state ==
                ComplaintStateStatus.AcceptedForBeingConstructiveWaitingForMailroomChiefToConfirm
                ? "grid"
                : "none"
            }
            gridTemplateColumns={"repeat(2,1fr)"}
            mt={"1rem"}
            gap={"6rem"}
          >
            <Button
              sx={{
                borderRadius: "0.5rem",
                backgroundColor: Green,
                color: "white",
                "&:hover": {
                  backgroundColor: GreenLight,
                  color: Green,
                },
              }}
              onClick={() => {
                navigate(`/contract/${props.contractId}/${props.id}`, {
                  state: {
                    complaintId: props.id,
                  },
                });
              }}
            >
              مشاهده قرارداد و بررسی احراز شرایط داوری
            </Button>
          </Box>
        );

      case ComplaintStateStatus.NotAcceptedForBeingConstructiveWaitingForMailroomChiefToConfirm:
        if (
          user.parentId == props.acusserId ||
          user.parentId == props.acusserId ||
          user.id == props.acusserId ||
          user.id == props.acusserId
        )
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
        return (
          <Box
            display={
              props.type == "chief" &&
              props.state ==
                ComplaintStateStatus.NotAcceptedForBeingConstructiveWaitingForMailroomChiefToConfirm
                ? "grid"
                : "none"
            }
            gridTemplateColumns={"repeat(2,1fr)"}
            mt={"1rem"}
            gap={"6rem"}
          >
            <Button
              sx={{
                borderRadius: "0.5rem",
                backgroundColor: Green,
                color: "white",
                "&:hover": {
                  backgroundColor: GreenLight,
                  color: Green,
                },
              }}
              onClick={() => {
                navigate(`/contract/${props.contractId}/${props.id}`, {
                  state: {
                    complaintId: props.id,
                  },
                });
              }}
            >
              مشاهده قرارداد و بررسی احراز شرایط داوری
            </Button>
          </Box>
        );

      case ComplaintStateStatus.WaitingForMailRoomExpertToApproveAnswersToArguments:
        if (
          user.parentId == props.acusserId ||
          user.parentId == props.acusserId ||
          user.id == props.acusserId ||
          user.id == props.acusserId
        )
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
        return (
          <Box
            display={
              props.type == "mainRoomExpert" &&
              // @ts-ignore
              props.state ==
                ComplaintStateStatus.WaitingForMailRoomExpertToGiveAnswersToArguments
                ? "grid"
                : "none"
            }
            gridTemplateColumns={"repeat(3,1fr)"}
            mt={"1rem"}
            gap={"6rem"}
          >
            <Button
              sx={{
                borderRadius: "0.5rem",
                backgroundColor: Green,
                color: "white",
                "&:hover": {
                  backgroundColor: GreenLight,
                  color: Green,
                },
              }}
              onClick={() => {
                navigate(
                  // complaints/:contractId/:complaintId/addArguements/:state
                  `/complaints/${props.contractId}/${props.id}/addArguements/2`,
                  {
                    state: {
                      complaintId: props.id,
                    },
                  }
                );
              }}
            >
              مشاهده دعاوی
            </Button>
          </Box>
        );

      case ComplaintStateStatus.WaitingForChiefToApproveExpertsAnswersToArguments:
        if (props.type == "chief") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                }}
                onClick={() => {
                  navigate(
                    // complaints/:contractId/:complaintId/addArguements/:state
                    `/complaints/${props.contractId}/${props.id}/addArguements/3`,
                    {
                      state: {
                        complaintId: props.id,
                      },
                    }
                  );
                }}
              >
                مشاهده پاسخ کارشناس
              </Button>
            </Box>
          );
        } else {
          break;
        }

      case ComplaintStateStatus.WaitingForMinistersCouncilToAnswerLetter:
        if (props.type === "chief") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              className="grid grid-cols-2"
              mt={"1rem"}
              gap={"6rem"}
            >
              <FaTextField label="شماره نامه" variant="outlined" />

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  void updateComplaint({
                    variables: {
                      input: {
                        id: props.id,
                        isArchived: false,
                        complaintStateId: getComplaintStateWithEnum(
                          ComplaintStateStatus.WaitingForFirstPayment
                        ).id,
                      },
                    },
                    async onCompleted(data, clientOptions) {
                      if (data.complaint_updateComplaint.status.code == 1) {
                        await SendFirstPaymentAnnouncementSMS();
                        await SendFirstPaymentAnnouncementRequestLetter();
                        props.refetch && props.refetch();
                        handleClose();
                      }
                    },
                  });
                }}
              >
                تایید
              </Button>
              {/* <div className=""></div>
  
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: primaryDark,
                    color: "white",
                    "&:hover": {
                      backgroundColor: primary,
                      color: "white",
                    },
                  }}
                  onClick={() => {
                    void updateComplaint({
                      variables: {
                        input: {
                          id: props.id,
                          isArchived: false,
                          // expertArbitrationCost: expertsCouncilPaymentCost,
                          complaintStateId: getComplaintStateWithEnum(
                            ComplaintStateStatus.DeterminingCaseExpert
                          ).id,
                        },
                      },
                    });
                  }}
                >
                  پرداخت هزینه کارشناسی
                </Button> */}
            </Box>
          );
        } else {
          if (user.parentId == props.acusserId || user.id == props.acusserId)
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

      case getComplaintStateWithEnum(
        ComplaintStateStatus.WaitingForFirstPayment
      ).state:
        if (props.type == "accuser") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/pay/1`);
                }}
              >
                پرداخت هزینه اول داوری
              </Button>
            </Box>
          );
        } else {
          break;
        }
      case getComplaintStateWithEnum(
        ComplaintStateStatus.WaitingForExpertsCouncilPayment
      ).state:
        if (props.type == "accuser") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/pay/2`);
                }}
              >
                پرداخت هزینه قوه قضایی
              </Button>
            </Box>
          );
        } else {
          break;
        }
      case getComplaintStateWithEnum(ComplaintStateStatus.DeterminingCaseExpert)
        .state:
        if (props.type == "mainRoomExpert" || props.type == "chief") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    `/signUp/determiningCaseExpert/newUser/${props.id || ""}`
                  );
                }}
              >
                تعیین کارشناس پرونده
              </Button>
            </Box>
          );
        } else {
          break;
        }
      case getComplaintStateWithEnum(
        ComplaintStateStatus.DeterminingMeetingByMailRoomExpert
      ).state:
        if (props.type == "mainRoomExpert" || props.type == "chief") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/setMeeting`);
                }}
              >
                تعیین زمان جلسه پرونده
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

      case ComplaintStateStatus.CheckingAndUploadingTheSignedDecree:
        if (props.type == "mainRoomExpert" || props.type == "chief") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(3,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
              justifyContent={"center"}
              alignItems={"center"}
            >
              <div className="">آپلود قرار نامه امضا شده : </div>

              <FileBox setFiles={setFiles} files={files} fullWidth />

              <div className="">آپلود فایل صوتی جلسه استماع : </div>

              <FileBox setFiles={setVoiceFiles} files={voiceFiles} fullWidth />
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  gap: "0.5rem",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                disabled={!files}
                onClick={() => {
                  void UPLOAD_FILE({
                    file: files,
                    token: localStorage.getItem("token") as string,
                    onFail: (err) => {
                      console.log(err);
                    },
                    onSuccess(res) {
                      console.log(res);
                      void getFile({
                        variables: {
                          filter: {
                            name: {
                              eq: res.result?.[0]?.newFileName,
                            },
                          },
                        },
                        onCompleted(data) {
                          console.log("File", data);
                          void addFile({
                            variables: {
                              input: {
                                complaintId: props.id,
                                title: "قرارنامه امضا شده",
                                fileId:
                                  data.fileGallery_getFiles.result?.items?.[0]
                                    ?.id,
                              },
                            },
                            onCompleted(data, clientOptions) {
                              console.log("addedFile", data);
                              if (
                                data.complaintFile_addComplaintFile.status
                                  .code == 1
                              ) {
                                void UPLOAD_FILE({
                                  file: voiceFiles,
                                  token: localStorage.getItem(
                                    "token"
                                  ) as string,
                                  onFail: (err) => {
                                    console.log(err);
                                  },

                                  onSuccess(res2) {
                                    console.log(res2);
                                    void getFile({
                                      variables: {
                                        filter: {
                                          name: {
                                            eq: res2.result?.[0]?.newFileName,
                                          },
                                        },
                                      },
                                      onCompleted(data) {
                                        console.log("File", data);
                                        void addFile({
                                          variables: {
                                            input: {
                                              complaintId: props.id,
                                              title: "فایل صوتی جلسه استماع",
                                              fileId:
                                                data.fileGallery_getFiles.result
                                                  ?.items?.[0]?.id,
                                            },
                                          },
                                          onCompleted(data, clientOptions) {
                                            console.log("addedFile", data);
                                            if (
                                              data
                                                .complaintFile_addComplaintFile
                                                .status.code == 1
                                            ) {
                                              void updateComplaint({
                                                variables: {
                                                  input: {
                                                    isArchived: false,

                                                    id: props.id,
                                                    complaintStateId:
                                                      getComplaintStateWithEnum(
                                                        ComplaintStateStatus.RequestingDocuments
                                                      ).id,
                                                  },
                                                },
                                                async onCompleted(
                                                  data,
                                                  clientOptions
                                                ) {
                                                  if (
                                                    data
                                                      .complaint_updateComplaint
                                                      .status.code == 1
                                                  ) {
                                                    await SendUploadingSignedDecreeLetter(
                                                      {
                                                        onCompleted() {
                                                          props.refetch &&
                                                            props.refetch();
                                                        },
                                                      }
                                                    );
                                                    await SendUploadDecreeAnnouncementSMS(
                                                      {
                                                        onCompleted(
                                                          data,
                                                          clientOptions
                                                        ) {
                                                          props.refetch &&
                                                            props.refetch();
                                                        },
                                                      }
                                                    );
                                                  }
                                                },
                                              });
                                            }
                                          },
                                        });
                                      },
                                    });
                                  },
                                });
                              }
                            },
                          });
                        },
                      });
                    },
                  });
                }}
              >
                <BsCloudUploadFill />
                ثبت و آپلود
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

      case ComplaintStateStatus.RequestingDocuments:
        if (props.type == "juryExpert") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/docReq`);
                }}
              >
                مشاهده درخواست داوری و درخواست مدارک مورد نیاز
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.UploadingDocumentsByAccused:
        if (props.type == "accused") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/docUpload`);
                }}
              >
                آپلود مدارک مورد نیاز
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.UploadingDocumentsByAccuser:
        if (props.type == "accuser") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/docUpload`);
                }}
              >
                آپلود مدارک مورد نیاز
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

      case ComplaintStateStatus.ReviewingCaseByCaseExpert:
        if (props.type == "juryExpert") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/expertReview`);
                }}
              >
                بررسی درخواست داوری و مدارک
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.MailRoomExpertReviewingTheFinalReport:
        if (props.type == "mainRoomExpert") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    // complaints/:contractId/:complaintId/addArguements/:state
                    `/complaints/${props.contractId}/${props.id}/addArguements/4`,
                    {
                      state: {
                        complaintId: props.id,
                      },
                    }
                  );
                }}
              >
                بررسی درخواست داوری
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.MailRoomChiefReviewingTheFinalReport:
        if (props.type == "chief") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    // complaints/:contractId/:complaintId/addArguements/:state
                    `/complaints/${props.contractId}/${props.id}/addArguements/5`,
                    {
                      state: {
                        complaintId: props.id,
                      },
                    }
                  );
                }}
              >
                بررسی درخواست داوری
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.WaitingForCouncilResult:
        if (props.type == "mainRoomExpert") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    // complaints/:contractId/:complaintId/addArguements/:state
                    `/complaints/${props.contractId}/${props.id}/addArguements/6`,
                    {
                      state: {
                        complaintId: props.id,
                      },
                    }
                  );
                }}
              >
                افزودن نظر شورای
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.WaitingForFinalResultUpload:
        if (props.type == "mainRoomExpert") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>
              {/* <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button> */}
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/verdict`);
                }}
              >
                افزودن رای نهایی
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.WaitingForSecondPayment:
        if (props.type == "accuser") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              {/* <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button> */}

              <div className=""></div>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/pay/3`);
                }}
              >
                پرداخت هزینه دوم داوری
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }
      case ComplaintStateStatus.WaitingForDeterminingExpertsCouncilPayment:
        if (props.type === "chief" || props.type === "mainRoomExpert") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <NumericFormat
                customInput={TextField}
                thousandSeparator
                variant="outlined"
                label="مبلغ هزینه کارشناسی"
                value={expertsCouncilPaymentCost}
                onValueChange={(e) => {
                  setExpertsCouncilPaymentCost(e.floatValue);
                }}
                InputProps={{
                  endAdornment: "ریال",
                }}
              />

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  void updateComplaint({
                    variables: {
                      input: {
                        isArchived: false,
                        id: props.id,
                        expertArbitrationCost: expertsCouncilPaymentCost,
                        complaintStateId: getComplaintStateWithEnum(
                          ComplaintStateStatus.WaitingForExpertsCouncilPayment
                        ).id,
                      },
                    },
                  });
                }}
              >
                تایید مبلغ
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

      case ComplaintStateStatus.WaitingForExpertsCouncilPayment:
        if (props.type === "accuser") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <div className=""></div>

              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  void updateComplaint({
                    variables: {
                      input: {
                        id: props.id,
                        isArchived: false,
                        // expertArbitrationCost: expertsCouncilPaymentCost,
                        complaintStateId: getComplaintStateWithEnum(
                          ComplaintStateStatus.DeterminingCaseExpert
                        ).id,
                      },
                    },
                  });
                }}
              >
                پرداخت هزینه کارشناسی
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

        // case getComplaintStateWithEnum(ComplaintStateStatus.DeterminingCaseExpert):
        return (
          <Box
            display={"grid"}
            gridTemplateColumns={"repeat(2,1fr)"}
            mt={"1rem"}
            gap={"6rem"}
          >
            <div className=""></div>

            <Button
              sx={{
                borderRadius: "0.5rem",
                backgroundColor: primaryDark,
                color: "white",
                "&:hover": {
                  backgroundColor: primary,
                  color: "white",
                },
              }}
              onClick={() => {
                navigate(
                  `/signUp/determiningCaseExpert/newUser/${props.id || ""}`
                );
              }}
            >
              افزودن کارشناس
            </Button>
          </Box>
        );
        case ComplaintStateStatus.WaitingForAccuserAndAccusedToRespondToExpertOpinion:
          if (props.type == "accused") {
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <div className=""></div>
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: primaryDark,
                    color: "white",
                    "&:hover": {
                      backgroundColor: primary,
                      color: "white",
                    },
                  }}
                  onClick={() => {
                    navigate(
                      // complaints/:contractId/:complaintId/addArguements/:state
                      `/complaints/${props.contractId}/${props.id}/addArguements/9`,
                      {
                        state: {
                          complaintId: props.id,
                        },
                      }
                    );
                  }}
                >
                  افزودن پاسخ به نظر کارشناس
                </Button>
              </Box>
            );
          } else if (props.type == "accuser") {
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <div className=""></div>
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: primaryDark,
                    color: "white",
                    "&:hover": {
                      backgroundColor: primary,
                      color: "white",
                    },
                  }}
                  onClick={() => {
                    navigate(
                      // complaints/:contractId/:complaintId/addArguements/:state
                      `/complaints/${props.contractId}/${props.id}/addArguements/8`,
                      {
                        state: {
                          complaintId: props.id,
                        },
                      }
                    );
                  }}
                >
                  افزودن پاسخ به نظر کارشناس
                </Button>
              </Box>
            );
          } else {
            break;
          }
  
        case ComplaintStateStatus.WaitingForFinalExpertOpinion:
          if (props.type == "juryExpert") {
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <div className=""></div>
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: primaryDark,
                    color: "white",
                    "&:hover": {
                      backgroundColor: primary,
                      color: "white",
                    },
                  }}
                  onClick={() => {
                    navigate(`/complaints/${props.id}/expertReview`);
                  }}
                >
                  بررسی درخواست داوری و مدارک
                </Button>
              </Box>
            );
          } else {
            if (
              user.parentId == props.acusserId ||
              user.id == props.acusserId
            )
              return (
                <Box
                  display={"grid"}
                  gridTemplateColumns={"repeat(2,1fr)"}
                  mt={"1rem"}
                  gap={"6rem"}
                >
                  <Button
                    sx={{
                      borderRadius: "0.5rem",
                      backgroundColor: Red,
                      color: "white",
                      "&:hover": {
                        backgroundColor: red[100],
                        color: Red,
                      },
                    }}
                    onClick={() => {
                      const agree = confirm(
                        "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                      );
                      if (agree) {
                        void deleteComplaint();
                      }
                    }}
                  >
                    انصراف از درخواست داوری
                  </Button>
                </Box>
              );
            else {
              break;
            }
          }
  
      case ComplaintStateStatus.ComplaintDetermined:
        if (props.type == "accuser" || props.type == "accused") {
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              {/* <div className=""></div> */}
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: primaryDark,
                  color: "white",
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    // complaints/:contractId/:complaintId/addArguements/:state
                    `/complaints/${props.id}/files`,
                    {
                      state: {
                        complaintId: props.id,
                      },
                    }
                  );
                }}
              >
                مشاهده فایل ها
              </Button>
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: RedLight,
                  color: Red,
                  "&:hover": {
                    backgroundColor: primary,
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(`/complaints/${props.id}/requestCorrection`, {
                    state: {
                      complaintId: props.id,
                    },
                  });
                }}
              >
                طرح درخواست تصحیح رای
              </Button>
            </Box>
          );
        } else {
          if (
            user.parentId == props.acusserId ||
            user.parentId == props.acusserId ||
            user.id == props.acusserId ||
            user.id == props.acusserId
          )
            return (
              <Box
                display={"grid"}
                gridTemplateColumns={"repeat(2,1fr)"}
                mt={"1rem"}
                gap={"6rem"}
              >
                <Button
                  sx={{
                    borderRadius: "0.5rem",
                    backgroundColor: Red,
                    color: "white",
                    "&:hover": {
                      backgroundColor: red[100],
                      color: Red,
                    },
                  }}
                  onClick={() => {
                    const agree = confirm(
                      "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                    );
                    if (agree) {
                      void deleteComplaint();
                    }
                  }}
                >
                  انصراف از درخواست داوری
                </Button>
              </Box>
            );
          else {
            break;
          }
        }

      default:
        if (
          user.parentId == props.acusserId ||
          user.parentId == props.acusserId ||
          user.id == props.acusserId ||
          user.id == props.acusserId
        )
          return (
            <Box
              display={"grid"}
              gridTemplateColumns={"repeat(2,1fr)"}
              mt={"1rem"}
              gap={"6rem"}
            >
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Red,
                  color: "white",
                  "&:hover": {
                    backgroundColor: red[100],
                    color: Red,
                  },
                }}
                onClick={() => {
                  const agree = confirm(
                    "آیا از انصراف از این درخواست داوری مطمئن هستید؟"
                  );
                  if (agree) {
                    void deleteComplaint();
                  }
                }}
              >
                انصراف از درخواست داوری
              </Button>
            </Box>
          );
    }
  };
  return (
    <>
      <LetterOfCouncilofMinistersModal
        open={openLetterOfCouncilofMinistersModal}
        onClose={() => {
          setOpenLetterOfCouncilofMinistersModal(false);
        }}
      />
      <NewModal
        open={open}
        onClose={handleClose}
        height={"70dvh"}
        isCloseable={true}
        background={background}
        name={"درخواست داوری"}
        width={{
          xs: "90vw",
          sm: "80vw",
          md: "60vw",
          lg: "50vw",
        }}
      >
        <Box width={"100%"}>
          <Box display={"flex"} justifyContent={"flex-end"} m={1} gap={3}>
            <Button
              sx={{
                borderRadius: "0.5rem",
                backgroundColor: grey[700],
                color: "white",
                "&:hover": {
                  backgroundColor: grey[600],
                  color: "white",
                },
              }}
              onClick={() => {
                navigate(
                  // complaints/:contractId/:complaintId/addArguements/:state
                  `/complaints/${props.id}/timeLine`,
                  {
                    state: {
                      complaintId: props.id,
                    },
                  }
                );
              }}
              endIcon={<FileOpenOutlined />}
            >
              مشاهده تاریخچه
            </Button>
            {(props.type === "juryExpert" ||
              props.type === "chief" ||
              props.type === "mainRoomExpert" ||
              props.type === "all") && (
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: grey[700],
                  color: "white",
                  "&:hover": {
                    backgroundColor: grey[600],
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(
                    // complaints/:contractId/:complaintId/addArguements/:state
                    `/complaints/${props.id}/files`,
                    {
                      state: {
                        complaintId: props.id,
                      },
                    }
                  );
                }}
                endIcon={<FileOpenOutlined />}
              >
                مشاهده نامه ها
              </Button>
            )}
          </Box>
          <Box sx={style}>
            <TableContainer>
              <Table>
                <TableHead
                  sx={{
                    backgroundColor: primaryLightTransparent,
                    borderBottom: `1px solid ${secondary}`,
                  }}
                ></TableHead>
                <TableBody>
                  {props.trackingCode && (
                    <Tooltip
                      arrow
                      title="از این پس میتوانید برای رهگیری درخواست خود از این کد استفاده نمایید"
                    >
                      <TableRow
                        sx={{
                          borderBottom: `2px solid ${grey[300]}`,
                        }}
                      >
                        <TableCell
                          sx={{
                            color: secondaryDark,
                          }}
                        >
                          کد رهگیری:
                        </TableCell>
                        <TableCell
                          sx={{
                            color: secondaryDark,
                          }}
                        >
                          {convertToPersianDigits(props.trackingCode)}
                        </TableCell>
                      </TableRow>
                    </Tooltip>
                  )}

                  <TableRow
                    sx={{
                      borderBottom: `2px solid ${grey[300]}`,
                    }}
                  >
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      شماره درخواست داوری:
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {convertToPersianDigits(props.id)}
                    </TableCell>
                  </TableRow>
                  <TableRow
                    sx={{
                      borderBottom: `2px solid ${grey[300]}`,
                    }}
                  >
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      خوانده:
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {props.accused}
                    </TableCell>
                  </TableRow>

                  <TableRow
                    sx={{
                      borderBottom: `2px solid ${grey[300]}`,
                    }}
                  >
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      خواهان:
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {props.accuser}
                    </TableCell>
                  </TableRow>

                  <TableRow
                    sx={{
                      borderBottom: `2px solid ${grey[300]}`,
                    }}
                  >
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      وضعیت:
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {
                        getComplaintStateWithEnum(
                          props.state ||
                            ComplaintStateStatus.ComplaintDetermined
                        )?.persianName
                      }
                    </TableCell>
                  </TableRow>

                  <TableRow
                    sx={{
                      borderBottom: `2px solid ${grey[300]}`,
                    }}
                  >
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      شناسه قرارداد :
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {convertToPersianDigits(props.contractCode)}
                    </TableCell>
                  </TableRow>
                  {/* <TableRow
                    sx={{
                      borderBottom: `2px solid ${grey[300]}`,
                    }}
                  >
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      شماره طرح:
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {props.projectId}
                    </TableCell>
                  </TableRow> */}
                  <TableRow>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      تاریخ ثبت:
                    </TableCell>
                    <TableCell
                      sx={{
                        color: secondaryDark,
                      }}
                    >
                      {new Date(props.date!).toLocaleDateString("fa-IR")}
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
          {ActionButtons()}
          <NewModal
            open={addModal.open}
            onClose={() => {
              setAddModal({
                open: false,
              });
            }}
            height={"70dvh"}
            isCloseable={true}
            background={background}
            name={"کارشناس مورد نظر را انتخاب کنید"}
            width={{
              xs: "90vw",
              sm: "80vw",
              md: "60vw",
              lg: "50vw",
            }}
          >
            <Box
              width={"100%"}
              height={"20dvh"}
              display={"flex"}
              flexDirection={"column"}
              sx={{
                border: `1px solid ${primary}`,
                borderRadius: "0.5rem",
                gap: "1rem",
                p: "1rem",
                justifyContent: "space-between",
              }}
            >
              <Autocomplete
                disablePortal
                options={departmentsUsers}
                sx={{ width: "100%", gridColumn: "9/span 4" }}
                renderInput={(params) => (
                  <TextField {...params} label="نام کارشناس برای ارجاع" />
                )}
                onChange={(_e, value) => {
                  console.log(value);
                  setAssignedUser({
                    // @ts-ignore
                    fullName: value?.label,
                    // @ts-ignore
                    id: value?.id,
                  });
                }}
              />
              <Button
                sx={{
                  borderRadius: "0.5rem",
                  backgroundColor: Green,
                  color: "white",
                  "&:hover": {
                    backgroundColor: GreenLight,
                    color: Green,
                  },
                  mt: "0.5rem",
                }}
                onClick={() => {
                  if (
                    props.state == ComplaintStateStatus.WaitingForChiefToAssign
                  ) {
                    void updateComplaint({
                      variables: {
                        input: {
                          isArchived: false,
                          id: props.id,
                          assignedUserId: assignedUser?.id,
                          complaintStateId: getComplaintStateWithEnum(
                            ComplaintStateStatus.CheckingForBeingConstructive
                          ).id,
                        },
                      },

                      onCompleted(data) {
                        console.log(data);
                        props.refetch?.();
                        window.location.reload();
                        setAddModal({
                          open: false,
                        });
                        void sendAssignToExpertSMS();
                        // alert("درخواست داوری با موفقیت ارسال شد");
                      },
                    });
                  } else {
                    void updateComplaint({
                      variables: {
                        input: {
                          isArchived: false,
                          id: props.id,
                          assignedUserId: assignedUser?.id,
                          // complaintStateId: getComplaintStateWithEnum(
                          //   ComplaintStateStatus.CheckingForBeingConstructive
                          // ).id,
                        },
                      },

                      onCompleted(data) {
                        console.log(data);
                        alert("درخواست داوری با موفقیت ارسال شد");
                        props.refetch?.();
                      },
                    });
                  }
                  void sendAssignToExpertSMS();
                  setAddModal({
                    open: false,
                  });
                }}
              >
                ارسال درخواست داوری به کارشناس
              </Button>
            </Box>
          </NewModal>
        </Box>
      </NewModal>

      <TableRow
        sx={{
          borderRadius: "1rem",
          overflow: "hidden",
          whiteSpace: "nowrap",
          textOverflow: "ellipsis",
          "&:hover": {
            backgroundColor: "rgba(100,150,150,0.4)",
            cursor: "pointer",
          },
          "& td": {
            padding: "10px",
          },
        }}
        onClick={handleOpen}
      >
        <td onClick={handleOpen}>{props.id}</td>
        <td onClick={handleOpen}>{props.contractCode}</td>
        <td onClick={handleOpen}>{props.contractTitle}</td>
        {/* <td>{item.contract?.accuserDepartmentUserId}</td> */}
        <td onClick={handleOpen}>
          {accuserData?.user_getUser?.result?.fullName}
        </td>
        <td onClick={handleOpen}>
          {accusedData?.user_getUser?.result?.fullName}
        </td>
        {/* <td>{item.contract?.accusedDepartmentUserId}</td> */}
        <td onClick={handleOpen}>{props.status}</td>
        <td onClick={handleOpen}>{props.alert}</td>
      </TableRow>
    </>
  );
};

export default ComplaintRowTable;
