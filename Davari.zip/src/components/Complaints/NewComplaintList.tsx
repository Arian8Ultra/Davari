/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable no-case-declarations */
import { Box, TableRow } from "@mui/material";
import { useState } from "react";
import { BsExclamation } from "react-icons/bs";
import {
  useGetAllOganizationUsersQuery,
  useGetComplaintsWithFilterQuery,
  useGetUsersQuery,
} from "../../../generated-types";
import { getComplaintStateWithEnum } from "../../functions/ComplaintStatesFunc";
import {
  ComplaintFilterInput,
  ComplaintState,
  ComplaintStateStatus,
  ResponsibleUserType,
  SortEnumType,
} from "../../gql/graphql";
import CTable from "../CustomTable/CTable";
import ComplaintRowTable from "./ComplaintRowTable";
interface Props {
  userId?: string;
  departmentId?: string;
  type?:
    | "accused"
    | "accuser"
    | "assigned"
    | "chief"
    | "mainRoomExpert"
    | "juryExpert"
    | "all";
  justNeeded?: boolean;
}
const NewComplaintList = ({
  departmentId,
  type,
  userId,
  justNeeded,
}: Props) => {
  const [take, setTake] = useState(15);
  const [page, setPage] = useState(1);
  const filter = () => {
    switch (type) {
      case "all":
        return {} as ComplaintFilterInput;

      case "chief":
        return justNeeded
          ? ({
              or: [
                {
                  complaintState: {
                    state: { eq: ComplaintStateStatus.WaitingForChiefToAssign },
                  },
                },
                {
                  complaintState: {
                    state: {
                      eq: ComplaintStateStatus.WaitingForChiefToApproveExpertsAnswersToArguments,
                    },
                  },
                },
                {
                  complaintState: {
                    state: {
                      eq: ComplaintStateStatus.MailRoomChiefReviewingTheFinalReport,
                    },
                  },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.MailRoomChief,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({} as ComplaintFilterInput);

      case "accused":
        return justNeeded
          ? ({
              or: [
                {
                  contract: {
                    accusedDepartmentUserId: {
                      eq: departmentId,
                    },
                  },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.Accused,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({
              contract: {
                accusedDepartmentUserId: {
                  eq: departmentId,
                },
              },
            } as ComplaintFilterInput);

      case "accuser":
        return justNeeded
          ? ({
              or: [
                {
                  contract: { accuserDepartmentUserId: { eq: departmentId } },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.Accuser,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({
              contract: { accuserDepartmentUserId: { eq: departmentId } },
            } as ComplaintFilterInput);

      case "assigned":
        return {
          assignedUserId: {
            eq: userId,
          },
        } as ComplaintFilterInput;

      case "mainRoomExpert":
        return justNeeded
          ? ({
              or: [
                {
                  assignedUserId: {
                    eq: userId,
                  },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.MailRoomExpert,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({
              assignedUserId: {
                eq: userId,
              },
            } as ComplaintFilterInput);

      case "juryExpert":
        return {
          and: [
            {
              complaintState: {
                responsibleRole: {
                  eq: ResponsibleUserType.LegalExpert,
                },
              },
            },
            {
              or: [
                {
                  councilExpertIds: {
                    some: {
                      eq: userId,
                    },
                  },
                },
                {
                  councilExpertIds: {
                    some: {
                      eq: departmentId,
                    },
                  },
                },
              ],
            },
          ],
        } as ComplaintFilterInput;
      default:
        return {} as ComplaintFilterInput;
    }
  };

  const { data: allData, refetch } = useGetComplaintsWithFilterQuery({
    variables: {
      filter: filter(),
      order: [
        {
          createdDate: SortEnumType.Desc,
        },
      ],
      take: take,
      skip: (page - 1) * take,
    },
  });

  const sortedData = () => {
    switch (type) {
      case "accused":
        const needAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole != ResponsibleUserType.Accused
          );
        const doNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole == ResponsibleUserType.Accused
          );

        return [...(doNotNeedAction || []), ...(needAction || [])];

      case "accuser":
        const accuserNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole != ResponsibleUserType.Accuser
          );
        const accuserDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole == ResponsibleUserType.Accuser
          );

        return [
          ...(accuserDoNotNeedAction || []),
          ...(accuserNeedAction || []),
        ];

      case "assigned":
        return [...(allData?.complaint_getComplaints?.result?.items || [])];

      case "mainRoomExpert":
        const mainRoomExpertNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole !=
              ResponsibleUserType.MailRoomExpert
          );
        const mainRoomExpertDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole ==
              ResponsibleUserType.MailRoomExpert
          );

        return [
          ...(mainRoomExpertDoNotNeedAction || []),
          ...(mainRoomExpertNeedAction || []),
        ];

      case "chief":
        const chiefNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole !=
              ResponsibleUserType.MailRoomChief
          );
        const chiefDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole ==
              ResponsibleUserType.MailRoomChief
          );

        return [...(chiefDoNotNeedAction || []), ...(chiefNeedAction || [])];

      case "juryExpert":
        const juryExpertNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole !=
              ResponsibleUserType.LegalExpert
          );
        const juryExpertDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole ==
              ResponsibleUserType.LegalExpert
          );

        return [
          ...(juryExpertDoNotNeedAction || []),
          ...(juryExpertNeedAction || []),
        ];

      case "all":
        return [...(allData?.complaint_getComplaints?.result?.items || [])];

      default:
        return [...(allData?.complaint_getComplaints?.result?.items || [])];
    }
  };

  const { data: users } = useGetUsersQuery({
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });

  const AlertNotif = ({
    complaintState,
  }: {
    complaintState: ComplaintState | undefined;
  }) => {
    if (
      complaintState?.responsibleRole == ResponsibleUserType.Accused &&
      type == "accused"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.Accuser &&
      type == "accuser"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.MailRoomExpert &&
      type == "assigned"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.Accused &&
      type == "assigned"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.Accuser &&
      type == "assigned"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.MailRoomExpert &&
      type == "mainRoomExpert"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.LegalExpert &&
      type == "juryExpert"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else if (
      complaintState?.responsibleRole == ResponsibleUserType.MailRoomChief &&
      type == "chief"
    ) {
      return (
        <Box
          sx={{
            zIndex: 100,
            borderRadius: "50rem",
            width: "100%",
            // height: "1rem",
            display: "flex",
            justifyContent: "center",
            backgroundColor: "rgb(255, 64, 129)",
            color: "white",
            // boxShadow: "0 0 0.5rem rgba(0,0,0,0.2)",
          }}
        >
          <BsExclamation
            style={{
              fontSize: "1.8rem",
            }}
          />
        </Box>
      );
    } else {
      return null;
    }
  };

  return (
    <div className="w-full">
      <div className="w-full">
        <CTable
          page={page}
          setPage={setPage}
          recordsPerPage={take}
          setRecordsPerPage={setTake}
          totalRecords={
            allData?.complaint_getComplaints?.result?.totalCount || 0
          }
          tableHeader={
            <TableRow
              sx={{
                th: {
                  padding: "10px",
                },
                "& td": {
                  padding: "10px",
                },
              }}
            >
              <td>شناسه درخواست داوری</td>
              <td>شناسه قرارداد</td>
              <td>عنوان قرارداد</td>
              <td>خواهان</td>
              <td>خوانده</td>
              <td>وضعیت</td>
              <td></td>

              {/* <td>کد رهگیری</td> */}
            </TableRow>
          }
        >
          {sortedData()?.map?.((item) => (
            // <TableRow
            //   sx={{
            //     borderRadius: "1rem",
            //     overflow: "hidden",
            //     whiteSpace: "nowrap",
            //     textOverflow: "ellipsis",
            //     "&:hover": {
            //       backgroundColor: "rgba(100,150,150,0.4)",
            //       cursor: "pointer",
            //     },
            //     "& td": {
            //       padding: "10px",
            //     },
            //   }}
            // >
            //   <td>{item.id}</td>
            //   <td>{item.contractId}</td>
            //   <td>{item.contract?.contractSubjectByAccuser}</td>
            //   {/* <td>{item.contract?.accuserDepartmentUserId}</td> */}
            //   <td>
            //     {
            //       departments?.user_getUsers?.result?.items?.find(
            //         (a) => a.id == item.contract?.accuserDepartmentUserId
            //       )?.fullName
            //     }
            //   </td>
            //   <td>
            //     {
            //       departments?.user_getUsers?.result?.items?.find(
            //         (a) => a.id == item.contract?.accusedDepartmentUserId
            //       )?.fullName
            //     }
            //   </td>
            //   {/* <td>{item.contract?.accusedDepartmentUserId}</td> */}
            //   <td>
            //     {
            //       getComplaintStateWithEnum(
            //         item.complaintState?.state ||
            //           ComplaintStateStatus.ComplaintDetermined
            //       )?.persianName
            //     }
            //   </td>
            //   <td>
            //     <AlertNotif complaintState={item.complaintState || undefined} />
            //   </td>
            // </TableRow>
            <ComplaintRowTable
              key={item.id}
              alert={
                <AlertNotif complaintState={item.complaintState || undefined} />
              }
              status={
                getComplaintStateWithEnum(
                  item.complaintState?.state ||
                    ComplaintStateStatus.ComplaintDetermined
                )?.persianName
              }
              accuser={
                users?.user_getUsers?.result?.items?.find(
                  (a) => a.id == item.contract?.accuserDepartmentUserId
                )?.fullName || ""
              }

              
              accused={
                users?.user_getUsers?.result?.items?.find(
                  (a) => a.id == item.contract?.accusedDepartmentUserId
                )?.fullName || ""
              }


              contractTitle={item.contract?.contractSubjectByAccuser || ""}
              id={item.id}
              contractId={item.contractId}
              contractCode={item.contract?.contractNumberByAccuser || ""}
              acussedId={item.contract?.accusedDepartmentUserId || ""}
              acusserId={item.contract?.accuserDepartmentUserId || ""}
              trackingCode={item.complaintCode || ""}
              date={item.createdDate}
              refetch={() => {
                void refetch();
              }}
              state={item.complaintState?.state}
              type={type}
            />
          ))}
        </CTable>
      </div>
    </div>
  );
};

export default NewComplaintList;
