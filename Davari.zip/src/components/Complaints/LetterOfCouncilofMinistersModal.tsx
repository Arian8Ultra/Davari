import { TableCell, TableRow } from "@mui/material";
import { useGetTestFetchLetterQuery } from "../../../generated-types";
import NewModal from "../Modals";
interface Props {
  open: boolean;
  onClose: () => void;
  complaintId?: string;
}
const LetterOfCouncilofMinistersModal = (props: Props) => {
  const { data } = useGetTestFetchLetterQuery({
    variables:{
      letterId: props.complaintId || ""
    }
  });
  return (
    <NewModal
      open={props.open}
      onClose={props.onClose}
      title="نامه هیئت وزیران"
      isCloseable
      backgroundColor="white"
    >
      <div className="flex flex-col gap-5">
        <table className="table-auto w-full">
          <tbody className="text-center">
            <TableRow>
              <TableCell
                sx={{
                  textAlign: "center",
                }}
              >
                خلاصه پاسخ نامه امور
              </TableCell>
              <TableCell
                colSpan={2}
                sx={{
                  textAlign: "center",
                }}
              >
                {data?.letter_fetchLetter?.result?.summary}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell
                sx={{
                  textAlign: "center",
                }}
              >
                توضیحات پاسخ نامه امور
              </TableCell>
              <TableCell
                colSpan={2}
                sx={{
                  textAlign: "center",
                }}
              >
                {data?.letter_fetchLetter?.result?.comment}
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell
                sx={{
                  textAlign: "center",
                }}
              >
                شماره پاسخ نامه امور
              </TableCell>
              <TableCell
                colSpan={2}
                sx={{
                  textAlign: "center",
                }}
              >
                {data?.letter_fetchLetter?.result?.letterNum}
              </TableCell>
            </TableRow>

            <TableRow>
              <TableCell
                sx={{
                  textAlign: "center",
                }}
              >
                فرستنده پاسخ نامه امور
              </TableCell>
              <TableCell
                colSpan={2}
                sx={{
                  textAlign: "center",
                }}
              >
                {data?.letter_fetchLetter?.result?.senderFullName}
              </TableCell>
            </TableRow>
          </tbody>
        </table>
      </div>
    </NewModal>
  );
};

export default LetterOfCouncilofMinistersModal;
