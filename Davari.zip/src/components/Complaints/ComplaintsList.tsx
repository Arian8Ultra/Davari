/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable no-case-declarations */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable react-hooks/rules-of-hooks */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { useLazyQuery, useQuery } from "@apollo/client";
import { Box, Stack, Typography } from "@mui/material";
import { useEffect, useMemo } from "react";
import {
  ComplaintFilterInput,
  ComplaintStateStatus,
  GetComplaintsWithFilterDocument,
  GetExpertComplaintsDocument,
  Get_Chief_ComplaintsDocument,
  HandlingType,
  ResponsibleUserType,
  SortEnumType,
} from "../../gql/graphql";
import { secondary } from "../../theme/color";
import theme from "../../theme/theme";
import ComplaintCardNew from "./ComplaintCardNew";
import { useAlertStore } from "../../Context/AlertStore";
import { useGetComplaintsWithFilterQuery } from "../../../generated-types";
interface Props {
  userId?: string;
  departmentId?: string;
  type?:
    | "accused"
    | "accuser"
    | "assigned"
    | "chief"
    | "mainRoomExpert"
    | "juryExpert"
    | "all";

  justNeeded?: boolean;
}
const ComplaintsList = ({ departmentId, type, userId, justNeeded }: Props) => {
  const {
    alertOpen,
    alertType,
    alertMessage,
    setAlertOpen,
    setAlertMessage,
    setAlertType,
  } = useAlertStore();

  const filter = () => {
    switch (type) {
      case "all":
        return {} as ComplaintFilterInput;

      case "chief":
        return justNeeded
          ? ({
              or: [
                {
                  complaintState: {
                    state: { eq: ComplaintStateStatus.WaitingForChiefToAssign },
                  },
                },
                {
                  complaintState: {
                    state: {
                      eq: ComplaintStateStatus.WaitingForChiefToApproveExpertsAnswersToArguments,
                    },
                  },
                },
                {
                  complaintState: {
                    state: {
                      eq: ComplaintStateStatus.MailRoomChiefReviewingTheFinalReport,
                    },
                  },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.MailRoomChief,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({} as ComplaintFilterInput);

      case "accused":
        return justNeeded
          ? ({
              or: [
                {
                  contract: {
                    accusedDepartmentUserId: {
                      eq: departmentId,
                    },
                  },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.Accused,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({
              contract: {
                accusedDepartmentUserId: {
                  eq: departmentId,
                },
              },
            } as ComplaintFilterInput);

      case "accuser":
        return justNeeded
          ? ({
              or: [
                {
                  contract: { accuserDepartmentUserId: { eq: departmentId } },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.Accuser,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({
              contract: { accuserDepartmentUserId: { eq: departmentId } },
            } as ComplaintFilterInput);

      case "assigned":
        return {
          assignedUserId: {
            eq: userId,
          },
        } as ComplaintFilterInput;

      case "mainRoomExpert":
        return justNeeded
          ? ({
              or: [
                {
                  assignedUserId: {
                    eq: userId,
                  },
                },
                {
                  complaintState: {
                    responsibleRole: {
                      eq: ResponsibleUserType.MailRoomExpert,
                    },
                  },
                },
              ],
            } as ComplaintFilterInput)
          : ({
              assignedUserId: {
                eq: userId,
              },
            } as ComplaintFilterInput);

      case "juryExpert":
        return {
          and: [
            {
              complaintState: {
                responsibleRole: {
                  eq: ResponsibleUserType.LegalExpert,
                },
              },
            },
            {
              // or: [
              //   {
              //     councilExpertIds: {
              //       some: {
              //         eq: userId,
              //       },
              //     },
              //   },
              // ],
            },
          ],
        } as ComplaintFilterInput;
      default:
        return {} as ComplaintFilterInput;
    }
  };
  const {
    data: assignedData,
    loading,
    refetch: assignedRefetch,
  } = useQuery(GetComplaintsWithFilterDocument, {
    variables: {
      filter: {
        and: [
          {
            assignedUserId: {
              eq: userId,
            },
          },
        ],
      },
      take: 100,
    },
    onCompleted(data) {
      console.log("assigned data", data);
    },
    // onError(error) {
    //   setAlertOpen(true);
    //   setAlertMessage(error.message);
    //   setAlertType("error");

    // },
  });

  const {
    data: accuserDataTemp,
    loading: accuserLoading,
    refetch: accuserRefetch,
  } = useQuery(GetComplaintsWithFilterDocument, {
    variables: {
      filter: {
        contract: { accuserDepartmentUserId: { eq: departmentId } },
      },
      order: [
        {
          complaintState: {
            priority: SortEnumType.Desc,
          },
        },
      ],
      take: 100,
    },
    onCompleted(data) {
      console.log("accuser data", data);
    },
  });

  const accuserData = useMemo(() => {
    const needAction =
      accuserDataTemp?.complaint_getComplaints?.result?.items?.filter(
        (a) => a.complaintState?.responsibleRole != ResponsibleUserType.Accuser
      );
    const doNotNeedAction =
      accuserDataTemp?.complaint_getComplaints?.result?.items?.filter(
        (a) => a.complaintState?.responsibleRole == ResponsibleUserType.Accuser
      );
    return [...(doNotNeedAction || []), ...(needAction || [])];
  }, [accuserDataTemp?.complaint_getComplaints?.result?.items]);

  const {
    data: chiefDataTemp,
    loading: chiefLoading,
    refetch: chiefRefetch,
  } = useQuery(Get_Chief_ComplaintsDocument, {
    onCompleted(data) {
      console.log("chief data", data);
    },
  });

  const chiefData = useMemo(() => {
    const needAction =
      chiefDataTemp?.complaint_getComplaints?.result?.items?.filter(
        (a) =>
          a.complaintState?.responsibleRole != ResponsibleUserType.MailRoomChief
      );
    const doNotNeedAction =
      chiefDataTemp?.complaint_getComplaints?.result?.items?.filter(
        (a) =>
          a.complaintState?.responsibleRole == ResponsibleUserType.MailRoomChief
      );
    return chiefDataTemp?.complaint_getComplaints?.result?.items;
    // return [...(doNotNeedAction || []), ...(needAction || [])];
  }, [chiefDataTemp?.complaint_getComplaints?.result?.items]);

  const {
    data: accusedDataTemp,
    loading: accusedLoading,
    refetch: accusedRefetch,
  } = useQuery(GetComplaintsWithFilterDocument, {
    variables: {
      filter: {
        contract: { accusedDepartmentUserId: { eq: departmentId } },
      },
      order: [
        {
          complaintState: {
            priority: SortEnumType.Desc,
          },
        },
      ],
      take: 100,
    },
    onCompleted(data) {
      console.log("accused data", data);
    },
  });

  const {
    data: expertsDataTemp,
    loading: expertsLoading,
    refetch: expertsRefetch,
  } = useQuery(GetComplaintsWithFilterDocument, {
    variables: {
      order: [
        {
          createdDate: SortEnumType.Desc,
        },
      ],
      filter: {
        complaintState: {
          responsibleRole: {
            eq: ResponsibleUserType.LegalExpert,
          },
        },
      },
    },
    onCompleted(data) {
      console.log("😎 expertsData data", data);
    },
    // onError(error) {
    //   setAlertOpen(true);
    //   setAlertMessage(error.message);
    //   setAlertType("error");
    // },
  });

  const expertsData = useMemo(() => {
    const needAction =
      expertsDataTemp?.complaint_getComplaints?.result?.items?.filter(
        (a) =>
          a.complaintState?.responsibleRole !=
          ResponsibleUserType.MailRoomExpert
      );
    const doNotNeedAction =
      expertsDataTemp?.complaint_getComplaints?.result?.items?.filter(
        (a) =>
          a.complaintState?.responsibleRole ==
          ResponsibleUserType.MailRoomExpert
      );
    return [...(doNotNeedAction || []), ...(needAction || [])];
  }, [expertsDataTemp?.complaint_getComplaints?.result?.items]);

  const {
    data: allData,
    loading: allLoading,
    refetch,
  } = useGetComplaintsWithFilterQuery({
    variables: {
      filter: filter(),
      order: [
        {
          createdDate: SortEnumType.Desc,
        },
      ],
      take: 100,
      skip: 0,
    },
  });

  // useEffect(() => {
  //   if (type === "all") {
  //     void getAllComplaints();
  //   }
  // }, [getAllComplaints, type]);

  const sortedData = () => {
    switch (type) {
      case "accused":
        const needAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole != ResponsibleUserType.Accused
          );
        const doNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole == ResponsibleUserType.Accused
          );

        return [...(doNotNeedAction || []), ...(needAction || [])];

      case "accuser":
        const accuserNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole != ResponsibleUserType.Accuser
          );
        const accuserDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole == ResponsibleUserType.Accuser
          );

        return [
          ...(accuserDoNotNeedAction || []),
          ...(accuserNeedAction || []),
        ];

      case "assigned":
        return [...(allData?.complaint_getComplaints?.result?.items || [])];

      case "mainRoomExpert":
        const mainRoomExpertNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole !=
              ResponsibleUserType.MailRoomExpert
          );
        const mainRoomExpertDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole ==
              ResponsibleUserType.MailRoomExpert
          );

        return [
          ...(mainRoomExpertDoNotNeedAction || []),
          ...(mainRoomExpertNeedAction || []),
        ];

      case "chief":
        const chiefNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole !=
              ResponsibleUserType.MailRoomChief
          );
        const chiefDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole ==
              ResponsibleUserType.MailRoomChief
          );

        return [...(chiefDoNotNeedAction || []), ...(chiefNeedAction || [])];

      case "juryExpert":
        const juryExpertNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole !=
              ResponsibleUserType.LegalExpert
          );
        const juryExpertDoNotNeedAction =
          allData?.complaint_getComplaints?.result?.items?.filter(
            (a) =>
              a.complaintState?.responsibleRole ==
              ResponsibleUserType.LegalExpert
          );

        return [
          ...(juryExpertDoNotNeedAction || []),
          ...(juryExpertNeedAction || []),
        ];

      case "all":
        return [...(allData?.complaint_getComplaints?.result?.items || [])];

      default:
        return [...(allData?.complaint_getComplaints?.result?.items || [])];
    }
  };
  return (
    <Stack
      spacing={1}
      width={"100%"}
      maxHeight={`calc(100vh - ${theme.spacing(25)})`}
      height={"max-content"}
      gridColumn={
        type === "chief" || type == "mainRoomExpert" || type == "all"
          ? "span 2"
          : "span 1"
      }
      display={
        (type === "chief" && sortedData().length === 0) ||
        (type === "mainRoomExpert" && sortedData().length === 0) ||
        (type === "accused" && sortedData().length === 0) ||
        (type === "accuser" && sortedData().length === 0) ||
        (type === "assigned" && sortedData().length === 0)
          ? "none"
          : "block"
      }
      className="bg-[rgb(240,240,240)] outline outline-1 outline-gray-30"
      sx={{
        // background: "rgba(200,200,200,0.7)",
        // backgroundColor: secondaryLighter,
        borderRadius: 2,
        padding: 0,
        paddingTop: 0,
        overflow: "auto",
        position: "relative",
        // scrollbarGutter: "stable",
      }}
    >
      {type === "accused" ? (
        <Typography
          variant="h5"
          component="h2"
          sx={{
            color: secondary,
            // background: "rgba(200,200,200,0.7)",
            // backgroundColor: primaryGrey,
            // backgroundColor: secondary,
            // background: "rgba(255,255,255,0.3)",
            padding: "0.5rem",
            // borderRadius: 2,
            // textAlign: "center",
            position: "sticky",
            top: 0,
            zIndex: 1000,
            backdropFilter: "blur(10px)",
          }}
          className="bg-white-100 shadow-lg"
        >
          {accuserLoading
            ? "در حال دریافت اطلاعات"
            : "درخواست های داوری به طرفیت شما"}
        </Typography>
      ) : type === "accuser" ? (
        <Typography
          variant="h5"
          component="h2"
          sx={{
            color: secondary,
            // backgroundColor: primaryGrey,
            // backgroundColor: secondary,
            // background: "rgba(255,255,255,0.3)",
            padding: "0.5rem",
            // borderRadius: 2,
            // textAlign: "center",
            // background: "rgba(200,200,200,0.7)",
            position: "sticky",
            top: 0,
            zIndex: 1000,
            backdropFilter: "blur(10px)",
          }}
          className="bg-white-100 shadow-lg"
        >
          {accusedLoading ? "در حال دریافت اطلاعات" : "درخواست های داوری شما"}
        </Typography>
      ) : type === "assigned" ? (
        <Typography
          variant="h5"
          component="h2"
          sx={{
            color: secondary,
            // backgroundColor: primaryGrey,
            // backgroundColor: secondary,
            // background: "rgba(255,255,255,0.3)",
            padding: "0.5rem",
            // borderRadius: 2,
            // textAlign: "center",
            // background: "rgba(200,200,200,0.7)",
            position: "sticky",
            top: 0,
            zIndex: 1000,
            backdropFilter: "blur(10px)",
          }}
          className="bg-white-100 shadow-lg"
        >
          {loading
            ? "در حال دریافت اطلاعات"
            : "درخواست های داوری تعیین شده برای شما"}
        </Typography>
      ) : type === "chief" ? (
        <Typography
          variant="h5"
          component="h2"
          sx={{
            color: secondary,
            // backgroundColor: primaryGrey,
            // backgroundColor: secondary,
            // background: "rgba(255,255,255,0.3)",
            padding: "0.5rem",
            // borderRadius: 2,
            // textAlign: "center",
            // background: "rgba(200,200,200,0.7)",
            position: "sticky",
            top: 0,
            zIndex: 1000,
            backdropFilter: "blur(10px)",
          }}
          className="bg-white-100 shadow-lg"
        >
          درخواست های داوری نیازمند بررسی
        </Typography>
      ) : type == "all" ? (
        <Typography
          variant="h5"
          component="h2"
          sx={{
            color: secondary,
            // backgroundColor: primaryGrey,
            // backgroundColor: secondary,
            // background: "rgba(255,255,255,0.3)",
            padding: "0.5rem",
            // borderRadius: 2,
            // textAlign: "center",
            // background: "rgba(200,200,200,0.7)",
            position: "sticky",
            top: 0,
            zIndex: 1000,
            backdropFilter: "blur(10px)",
          }}
          className="bg-white-100 shadow-lg"
        >
          {allLoading ? "در حال دریافت اطلاعات" : "تمامی درخواست های داوری"}
        </Typography>
      ) : null}

      <Box
        display={"grid"}
        gap={2}
        gridTemplateColumns={
          type === "chief" ||
          type == "mainRoomExpert" ||
          type == "juryExpert" ||
          type == "all"
            ? {
                xs: "repeat(1, 1fr)",
                sm: "repeat(2, 1fr)",
                md: "repeat(43 1fr)",
                lg: "repeat(4, 1fr)",
              }
            : {
                xs: "repeat(1, 1fr)",
                sm: "repeat(2, 1fr)",
                md: "repeat(2, 1fr)",
                lg: "repeat(2, 1fr)",
              }
        }
        padding={1}
        paddingTop={
          type === "chief" ||
          type == "mainRoomExpert" ||
          type == "juryExpert" ||
          type == "all"
            ? 1
            : 0
        }
      >
        {type === "accused"
          ? sortedData()?.map((complaint) => (
              <>
                <ComplaintCardNew
                  key={complaint.id}
                  id={complaint.id}
                  acussedId={String(
                    complaint?.contract?.accusedDepartmentUserId
                  )}
                  councilExpert={complaint?.councilExpertIds?.[0]}
                  acusserId={String(
                    complaint?.contract?.accuserDepartmentUserId
                  )}
                  trackingCode={complaint?.complaintCode || ""}
                  date={complaint?.createdDate}
                  contractId={complaint?.contractId}
                  state={complaint?.complaintState?.state}
                  type="accused"
                  refetch={refetch}
                  createdAt={complaint?.createdDate}
                  contractNumber={
                    complaint?.contract?.contractNumberByAccuser ?? ""
                  }
                  assignedId={complaint.assignedUserId || ""}
                  complaintState={complaint?.complaintState || undefined}
                />
                {complaint.assignedUser?.fullName || ""}
              </>
            ))
          : type === "accuser"
          ? sortedData()?.map((complaint) => (
              <ComplaintCardNew
                key={complaint.id}
                id={complaint.id}
                acussed={complaint?.assignedUser?.userName ?? ""}
                date={complaint?.createdDate}
                contractId={complaint?.contractId}
                councilExpert={complaint?.councilExpertIds?.[0]}
                acussedId={String(complaint?.contract?.accusedDepartmentUserId)}
                acusserId={String(complaint?.contract?.accuserDepartmentUserId)}
                trackingCode={complaint?.complaintCode || ""}
                type="accuser"
                state={complaint?.complaintState?.state}
                refetch={refetch}
                createdAt={complaint?.createdDate}
                assignedId={complaint.assignedUserId || ""}
                contractNumber={
                  complaint?.contract?.contractNumberByAccuser ?? ""
                }
                complaintState={complaint?.complaintState || undefined}
              />
            ))
          : type === "assigned"
          ? sortedData()?.map((complaint) => (
              <ComplaintCardNew
                key={complaint.id}
                id={complaint.id}
                acussed={complaint?.assignedUser?.userName ?? ""}
                date={complaint?.createdDate}
                contractId={complaint?.contractId}
                councilExpert={complaint?.councilExpertIds?.[0]}
                acussedId={String(complaint?.contract?.accusedDepartmentUserId)}
                acusserId={String(complaint?.contract?.accuserDepartmentUserId)}
                trackingCode={
                  complaint?.isFirstPaymentPaid
                    ? complaint?.complaintCode || ""
                    : ""
                }
                type="assigned"
                state={complaint?.complaintState?.state}
                refetch={refetch}
                createdAt={complaint?.createdDate}
                assignedId={complaint.assignedUserId || ""}
                contractNumber={
                  complaint?.contract?.contractNumberByAccuser ?? ""
                }
                complaintState={complaint?.complaintState || undefined}
              />
            ))
          : type === "chief"
          ? sortedData()?.map((complaint) => (
              <ComplaintCardNew
                key={complaint.id}
                id={complaint.id}
                acussed={complaint?.assignedUser?.userName ?? ""}
                date={complaint?.createdDate}
                contractId={complaint?.contractId}
                councilExpert={complaint?.councilExpertIds?.[0]}
                isPortal={true}
                acussedId={String(complaint?.contract?.accusedDepartmentUserId)}
                acusserId={String(complaint?.contract?.accuserDepartmentUserId)}
                type="chief"
                state={complaint?.complaintState?.state}
                refetch={refetch}
                createdAt={complaint?.createdDate}
                assignedId={complaint.assignedUserId || ""}
                contractNumber={
                  complaint?.contract?.contractNumberByAccuser ?? ""
                }
                trackingCode={complaint?.complaintCode || ""}
                complaintState={complaint?.complaintState || undefined}
              />
            ))
          : type === "mainRoomExpert"
          ? sortedData()?.map((complaint) => (
              <ComplaintCardNew
                key={complaint.id}
                id={complaint.id}
                acussed={complaint?.assignedUser?.userName ?? ""}
                councilExpert={complaint?.councilExpertIds?.[0]}
                date={complaint?.createdDate}
                contractId={complaint?.contractId}
                isPortal={true}
                acussedId={String(complaint?.contract?.accusedDepartmentUserId)}
                acusserId={String(complaint?.contract?.accuserDepartmentUserId)}
                type="mainRoomExpert"
                state={complaint?.complaintState?.state}
                refetch={refetch}
                createdAt={complaint?.createdDate}
                assignedId={complaint.assignedUserId || ""}
                contractNumber={
                  complaint?.contract?.contractNumberByAccuser ?? ""
                }
                trackingCode={complaint?.complaintCode || ""}
                complaintState={complaint?.complaintState || undefined}
              />
            ))
          : type == "all"
          ? sortedData()?.map((complaint) => (
              <ComplaintCardNew
                key={complaint.id}
                id={complaint.id}
                acussed={complaint?.assignedUser?.userName || ""}
                councilExpert={complaint?.councilExpertIds?.[0]}
                date={complaint?.createdDate}
                contractId={complaint?.contractId}
                isPortal={true}
                createdAt={complaint?.createdDate}
                assignedId={complaint.assignedUserId || ""}
                acussedId={String(complaint?.contract?.accusedDepartmentUserId)}
                acusserId={String(complaint?.contract?.accuserDepartmentUserId)}
                type="mainRoomExpert"
                state={complaint?.complaintState?.state}
                refetch={refetch}
                contractNumber={
                  complaint?.contract?.contractNumberByAccuser || ""
                }
                trackingCode={complaint?.complaintCode || ""}
                complaintState={complaint?.complaintState || undefined}
              />
            ))
          : null}

        {type == "juryExpert" &&
          sortedData()?.map((complaint) => (
            <ComplaintCardNew
              key={complaint?.id}
              id={complaint?.id ?? 0}
              acussed={complaint?.assignedUser?.userName ?? ""}
              councilExpert={complaint?.councilExpertIds?.[0]}
              date={complaint?.createdDate}
              contractId={complaint?.contractId}
              isPortal={true}
              createdAt={complaint?.createdDate}
              assignedId={complaint.assignedUserId || ""}
              acussedId={String(complaint?.contract?.accusedDepartmentUserId)}
              acusserId={String(complaint?.contract?.accuserDepartmentUserId)}
              type="juryExpert"
              state={complaint?.complaintState?.state}
              refetch={refetch}
              contractNumber={
                complaint?.contract?.contractNumberByAccuser ?? ""
              }
              complaintState={complaint?.complaintState || undefined}
            />
          ))}

        {type == "juryExpert" && expertsData?.length === 0 && (
          <Typography
            variant="h5"
            component="h2"
            textAlign={"center"}
            gridColumn={"span 4"}
            sx={{
              color: secondary,
              // backgroundColor: primaryGrey,
              // backgroundColor: secondary,
              // background: "rgba(255,255,255,0.3)",
              padding: "0.5rem",
              // borderRadius: 2,
              // textAlign: "center",
              position: "sticky",
            }}
          >
            {"درخواستی برای شما تعیین نشده است"}
          </Typography>
        )}
      </Box>
    </Stack>
  );
};

export default ComplaintsList;
