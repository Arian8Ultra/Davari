/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import React from "react";
import { useForm } from "react-hook-form";
import { DocumentRequest, RegistrarType, TargetType } from "../../gql/graphql";
import FileBox from "../FileBox";
import { UPLOAD_FILE } from "../../api/upload";
import { useUserStore } from "../../Context/UserStore";
import { Button, TextField } from "@mui/material";
import { useUpdateRequestedDocMutation } from "../../../generated-types";
import { useParams } from "react-router-dom";
import { useAlertStore } from "../../Context/AlertStore";
import { DownloadRounded } from "@mui/icons-material";
import { API_FILE_DOWNLOAD } from "../../../config";
interface Props extends DocumentRequest {
  isFilled?: boolean;
  type?: RegistrarType;
  refetch?: () => void;
}
const DocCard = (props: Props) => {
  const { user, token } = useUserStore();
  const { complaintId } = useParams<{ complaintId: string }>();
  const { setAlertMessage, setAlertOpen, setAlertType } = useAlertStore();
  const { setValue, getValues, watch, control, register, reset } = useForm<{
    answer?: string | null;
    fileName?: string | null;
  }>({
    defaultValues: {
      fileName:
        props.type === RegistrarType.Accuser
          ? props.requestedDocumentFileNameAccuser
          : props.requestedDocumentFileNameAccused,
      answer:
        props.type === RegistrarType.Accuser
          ? props.requestedAnswerAccuser
          : props.requestedAnswerAccused,
    },
  });

  const [UpdateDocumentRequest] = useUpdateRequestedDocMutation();
  return (
    <tr
      className={`*:p-2`}
    >
      <td className="px-4">{props.requestedDocumentName} </td>
      <td>
        {props.target === TargetType.Accused &&
          (props.requestedDocumentFileNameAccused ? (
            <Button
              variant="text"
              color="success"
              onClick={() => {
                window.open(
                  API_FILE_DOWNLOAD +
                    (props.requestedDocumentFileNameAccused || ""),
                  "_blank"
                );
              }}
            >
              <DownloadRounded />
              {props.requestedDocumentFileNameAccused}
            </Button>
          ) : (
            <FileBox
              onFileChange={(f) => {
                void UPLOAD_FILE({
                  token: token,
                  file: f,
                  onSuccess(res) {
                    console.log(res);
                    setValue("fileName", res.result?.[0]?.newFileName);
                  },
                  onFail(err) {
                    console.log(err);
                  },
                });
              }}
              // @ts-ignore
              disabled={props.target !== props.type}
              fileUrl={props.requestedDocumentFileNameAccused || ""}
            />
          ))}
        {props.target === TargetType.Accuser &&
          (props.requestedDocumentFileNameAccuser ? (
            <Button
              variant="text"
              color="success"
              onClick={() => {
                window.open(
                  API_FILE_DOWNLOAD +
                    (props.requestedDocumentFileNameAccuser || ""),
                  "_blank"
                );
              }}
            >
              <DownloadRounded />
              {props.requestedDocumentFileNameAccuser}
            </Button>
          ) : (
            <FileBox
              onFileChange={(f) => {
                void UPLOAD_FILE({
                  token: token,
                  file: f,
                  onSuccess(res) {
                    console.log(res);
                    setValue("fileName", res.result?.[0]?.newFileName);
                  },
                  onFail(err) {
                    console.log(err);
                  },
                });
              }}
              // @ts-ignore
              disabled={props.target !== props.type}
              fileUrl={props.requestedDocumentFileNameAccuser || ""}
            />
          ))}
      </td>
      <td>
        <TextField
          value={watch("answer")}
          onChange={(e) => {
            setValue("answer", e.target.value);
          }}
          variant="outlined"
          fullWidth
          disabled={props.target !== props.type}
        />
      </td>
      <td>
        <button
          className="bg-primary-500 w-full font-semibold rounded-full px-5 py-2 text-secondary-500 border-0 outline-0 disabled:opacity-50"
          disabled={props.target !== props.type}
          onClick={() => {
            void UpdateDocumentRequest({
              variables: {
                input: {
                  id: props.id,
                  userId: user.id,
                  complaintId: complaintId ? parseInt(complaintId) : 0,
                  requestedDocumentName: props.requestedDocumentName,
                  requestedAnswerAccused:
                    props.type == RegistrarType.Accused
                      ? watch("answer")
                      : undefined,
                  requestedAnswerAccuser:
                    props.type == RegistrarType.Accuser
                      ? watch("answer")
                      : undefined,
                  requestedDocumentFileNameAccuser:
                    props.type == RegistrarType.Accuser
                      ? watch("fileName")
                      : undefined,
                  requestedDocumentFileNameAccused:
                    props.type == RegistrarType.Accused
                      ? watch("fileName")
                      : undefined,
                },
              },
              onCompleted(data) {
                if (
                  data?.documentRequest_updateDocumentRequest?.status.code === 1
                ) {
                  setAlertMessage("مستند/ سوال ذخیره شد");
                  setAlertType("success");
                  setAlertOpen(true);
                  props.refetch?.();
                }
              },
              onError(error) {
                setAlertMessage(
                  "مستند/ سوال ذخیره نشد" + error.graphQLErrors?.[0].message
                );
                setAlertType("error");
                setAlertOpen(true);
              },
            });
          }}
        >
          ذخیره
        </button>
      </td>
    </tr>
  );
};

export default DocCard;
