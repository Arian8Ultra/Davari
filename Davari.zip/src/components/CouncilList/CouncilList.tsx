/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/ban-ts-comment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-non-null-asserted-optional-chain */
import { useMutation, useQuery } from "@apollo/client";
import {
  Box,
  Button,
  Checkbox,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { green } from "@mui/material/colors";
import React from "react";
import { BsDownload, BsGearFill } from "react-icons/bs";
import { useUserStore } from "../../Context/UserStore";
import { GET_ALL_ORGANIZATION_USERS } from "../../GraphQL/Users/Queries";
import { getComplaintStateWithEnum } from "../../functions/ComplaintStatesFunc";
import {
  ComplaintStateStatus,
  GetComplaintsWithFilterDocument,
  GetUsersDocument,
  SetCouncilListMutationDocument,
  UpdateComplaintDocument,
} from "../../gql/graphql";
import { primary, secondary } from "../../theme/color";
import {
  useSendAddToCouncilListSmsMutation,
  useSendLetterSentToMinistersCouncilSmsMutation,
  useSendMinistersCouncilLetterMutation,
} from "../../../generated-types";
import { API_FILE_DOWNLOAD } from "../../../config";

const CouncilList = () => {
  const [selectedList, setSelectedList] = React.useState<number[]>([]);

  const [files, setFiles] = React.useState<string[]>([]);

  const { data: filteredData } = useQuery(GetComplaintsWithFilterDocument, {
    variables: {
      filter: {
        and: [
          // {
          //   assignedUserId: {
          //     eq: user.id,
          //   },
          // },
          {
            complaintState: {
              state: {
                in: [
                  ComplaintStateStatus.WaitingForComplaintToEnterCouncilList,
                ],
              },
            },
          },
        ],
      },
    },
    onCompleted(data) {
      console.log("filtered data", data);
    },
  });

  const [updateComplaint] = useMutation(UpdateComplaintDocument);
  const [SendAddToCouncilListSMS] = useSendAddToCouncilListSmsMutation();
  const [SendMinistersCouncilLetter] = useSendMinistersCouncilLetterMutation();

  const [departments, setDepartments] = React.useState<
    {
      label: string;
      id: string;
      type: "INDIVIDUAL" | "ORGANIZATION" | "CONTRACTOR_OR_CONSULTANT";
    }[]
  >([]);
  const { data: users } = useQuery(GetUsersDocument, {
    variables: {
      take: 5000,
    },
    onCompleted(data) {
      console.log(data);
    },
    onError(error) {
      console.log(error);
    },
  });

  const [setCouncilList, { data }] = useMutation(
    SetCouncilListMutationDocument,
    {
      variables: {
        ids: selectedList,
      },
    }
  );

  const [sendLetterSentToMinistersCouncilSMS] =
    useSendLetterSentToMinistersCouncilSmsMutation({});
  return (
    <>
      <TableContainer
        sx={{
          gridColumn: "1 / span 12",
          m: 0,
          // outline: "2px solid #000",
          // change the table head background color
          borderRadius: "0.5rem",
          // border:'none',
          "& .MuiTableCell-head": {
            backgroundColor: secondary,
            color: primary,
            outline: `1px solid ${primary}`,
            padding: "0.2rem",
            textAlign: "center",
          },
          // give each cell border
          "& .MuiTableCell-root": {
            border: `1px solid ${secondary}`,
          },
          "& .MuiTableCell-body": {
            fontSize: "1rem",
            padding: "0.2rem",
            textAlign: "center",
          },
        }}
      >
        <Table>
          <TableHead
            sx={{
              fontSize: "1.2rem",
            }}
          >
            <TableCell>
              <Checkbox
                checked={
                  filteredData?.complaint_getComplaints.result?.items
                    ?.length === selectedList.length
                }
                onChange={(e) => {
                  if (e.target.checked) {
                    setSelectedList(
                      filteredData?.complaint_getComplaints.result?.items?.map(
                        (item) => item.id
                      )!
                    );
                  } else {
                    setSelectedList([]);
                  }
                }}
                sx={{
                  color: primary,
                  accentColor: primary,
                  ":checked": {
                    color: primary,
                  },
                }}
              />
            </TableCell>
            <TableCell
              sx={{
                fontSize: "1.1rem",
              }}
            >
              شماره درخواست
            </TableCell>
            <TableCell
              sx={{
                fontSize: "1.1rem",
              }}
            >
              شناسه قرارداد
            </TableCell>
            <TableCell
              sx={{
                fontSize: "1.1rem",
              }}
            >
              خواهان
            </TableCell>
            <TableCell
              sx={{
                fontSize: "1.1rem",
              }}
            >
              خوانده
            </TableCell>
            <TableCell
              sx={{
                fontSize: "1.1rem",
              }}
            >
              کارشناس
            </TableCell>
            {/* <TableCell
              sx={{
                fontSize: "1.1rem",
              }}
            >
              وضعیت
            </TableCell> */}
          </TableHead>
          <TableBody>
            {filteredData?.complaint_getComplaints.result?.items?.map(
              (item) => (
                <TableRow>
                  <TableCell>
                    <Checkbox
                      checked={selectedList.includes(item.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedList([...selectedList, item.id]);
                        } else {
                          setSelectedList(
                            selectedList.filter((id) => id !== item.id)
                          );
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>{item.id}</TableCell>
                  <TableCell>{item.contractId}</TableCell>
                  <TableCell>
                    {
                      users?.user_getUsers?.result?.items?.find(
                        (department) =>
                          department.id ===
                          item.contract?.accuserDepartmentUserId
                      )?.fullName
                    }
                  </TableCell>
                  <TableCell>
                    {
                      users?.user_getUsers?.result?.items?.find(
                        (department) =>
                          department.id ===
                          item.contract?.accusedDepartmentUserId
                      )?.fullName
                    }
                  </TableCell>
                  <TableCell>
                    {
                      users?.user_getUsers?.result?.items?.find(
                        (department) => department.id === item.assignedUserId
                      )?.fullName
                    }
                  </TableCell>
                  {/* <TableCell>{item.complaintState?.persianName}</TableCell> */}
                </TableRow>
              )
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Box display="flex" justifyContent="end" mt={2}>
        <Button
          variant="contained"
          sx={{
            backgroundColor: secondary,
            color: primary,
            paddingX: "3rem",
          }}
          endIcon={<BsGearFill />}
          disabled={selectedList.length === 0}
          onClick={() => {
            void SendMinistersCouncilLetter({
              variables: {
                complaintIds: selectedList,
              },
              onCompleted(data, clientOptions) {
                console.log(data);
              },
              onError(error, clientOptions) {
                console.log(error);
              },
            });
            void SendAddToCouncilListSMS({
              variables: {
                complaintIds: selectedList,
              },
              onCompleted(data, clientOptions) {
                console.log(data);
              },
              onError(error, clientOptions) {
                console.log(error);
              },
            });
            void setCouncilList({
              onCompleted(data) {
                console.log(data);
                if (
                  data.complaint_setInCouncilList.result?.result.some(
                    (item) => item.value == false
                  ) ||
                  data.complaint_setInCouncilList.result?.result.length === 0
                ) {
                  alert("خطا در تولید نامه ها");
                } else {
                  setFiles(data.complaint_setInCouncilList.result?.fileNames!);
                  data.complaint_setInCouncilList.result?.result?.map(
                    (complaint) => {
                      void sendLetterSentToMinistersCouncilSMS({
                        variables: {
                          complaintId: complaint.key,
                        },
                      });
                      void updateComplaint({
                        variables: {
                          id: complaint.key,
                          complaintStateId: getComplaintStateWithEnum(
                            ComplaintStateStatus.WaitingForMinistersCouncilToAnswerLetter
                          ).id,
                        },
                      });
                    }
                  );
                }
              },
            });
          }}
        >
          تولید نامه
        </Button>
      </Box>
      {data?.complaint_setInCouncilList?.result?.result.length !== 0 &&
        data?.complaint_setInCouncilList?.status.code === 1 && (
          <Box sx={{ mt: 2 }}>
            <Box
              display={"flex"}
              flexDirection={"column"}
              gap={2}
              // justifyContent={"space-between"}
              sx={{
                backgroundColor: green[100],
                width: "100%",
                padding: "1rem",
                borderRadius: "0.5rem",
              }}
            >
              <Box>نامه های تولید شده:</Box>
              {files.map((file) =>
                file.includes("Attachment") ? (
                  <Box
                    display={"flex"}
                    gap={2}
                    alignItems={"center"}
                    justifyContent={"space-between"}
                    onClick={() => {
                      window.open(`${API_FILE_DOWNLOAD}${file}`);
                    }}
                    sx={{
                      backgroundColor: green["A100"],
                      boxShadow: "0 0 0.5rem rgba(0,0,0,0.5)",
                      borderRadius: "0.5rem",
                      padding: "0.5rem",
                      cursor: "pointer",
                    }}
                  >
                    فایل پیوست
                    <IconButton>
                      <BsDownload />
                    </IconButton>
                  </Box>
                ) : (
                  <Box
                    display={"flex"}
                    gap={2}
                    alignItems={"center"}
                    justifyContent={"space-between"}
                    onClick={() => {
                      window.open(`${API_FILE_DOWNLOAD}${file}`);
                    }}
                    sx={{
                      backgroundColor: green["A100"],
                      boxShadow: "0 0 0.5rem rgba(0,0,0,0.5)",
                      borderRadius: "0.5rem",
                      padding: "0.5rem",
                      cursor: "pointer",
                    }}
                  >
                    فایل نامه
                    <IconButton>
                      <BsDownload />
                    </IconButton>
                  </Box>
                )
              )}
            </Box>
          </Box>
        )}
    </>
  );
};

export default CouncilList;
