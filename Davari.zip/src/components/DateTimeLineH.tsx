/* eslint-disable @typescript-eslint/no-unsafe-argument */
import React from "react";
import { BsChevronUp } from "react-icons/bs";
import { FaChevronUp } from "react-icons/fa";
import { primary } from "../theme/color";
import { IoTriangle } from "react-icons/io5";

interface Props {
  dates: {
    date: string;
    title: string;
    description: string;
    color?: string;
  }[];
  showClock?: boolean;
  sortType?: "asc" | "desc";
}
const DateTimeLineH = ({ dates, sortType,showClock }: Props) => {
  const sortedDates = dates.sort((a, b) => {
    // return new Date(a.date).getTime() - new Date(b.date || "").getTime();
    // sort by date in descending order
    if (sortType === "desc") {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    }
    // sort by date in ascending order
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });

  return (
    <div className={`flex w-fit gap-0 ${
      sortType === "desc" ? "flex-wrap-reverse" : "flex-wrap"
    }`}>
      {sortedDates
        ?.filter((a) => a.date)
        ?.map((d) => (
          <>
            <TimeLineHItem {...d} sortType={sortType} showClock={showClock} />
          </>
        ))}
    </div>
  );
};

const TimeLineHItem = ({
  date,
  title,
  description,
  color,
  sortType,
  showClock,
}: {
  date: string;
  title: string;
  description: string;
  color?: string;
  sortType?: "asc" | "desc";
  showClock?: boolean;
}) => {
  return (
    <div className="grid grid-rows-[1fr,auto,1fr] relative">
      <DateComponent date={date} sortType={sortType} showClock={showClock} />
      <IoTriangle size={20} className="text-primary-500 mx-auto  -mb-2 mt-2" />
      <div className="flex flex-col gap-2 ms-3 p-5 bg-white-50  rounded h-fit">
        <div className="text-sm text-center">{title}</div>
      </div>
    </div>
  );
};

const DateComponent = ({
  date,
  sortType,
  showClock,
}: {
  date: string;
  sortType?: "asc" | "desc";
  showClock?: boolean;
}) => {
  return (
    <div className="relative mx-1 flex flex-col gap-5">
      <div
        className={`absolute bg-primary-500 ${
          sortType === "desc" ? " left-5 -right-5" : "-left-5 right-5"
        } top-0 bottom-0`}
        style={{
          clipPath:
            sortType === "desc"
              ? "polygon(75% 0%, 100% 50%, 75% 100%, 0% 100%, 25% 50%, 0% 0%)"
              : "polygon(25% 0%, 100% 0%, 75% 50%, 100% 100%, 25% 100%, 0% 50%)",
        }}
      ></div>
      <div
        className="flex flex-col gap-3 bg-white-50 p-10 h-full justify-center"
        style={{
          clipPath:
            sortType === "desc"
              ? "polygon(75% 0%, 100% 50%, 75% 100%, 0% 100%, 25% 50%, 0% 0%)"
              : "polygon(25% 0%, 100% 0%, 75% 50%, 100% 100%, 25% 100%, 0% 50%)",
        }}
      >
        <div className="h3 p-2 rounded-lg col-span-full w-full me-5 text-center">
          {new Date(date || "").toLocaleDateString("fa-IR", {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: showClock ? "numeric" : undefined,
            minute: showClock ? "numeric" : undefined,
          })}
        </div>
      </div>
    </div>
  );
};

export default DateTimeLineH;
