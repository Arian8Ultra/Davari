import { TableCell, TableHead, TableRow } from "@mui/material";
import { secondary } from "../../theme/color";
interface Props {
  state?: number;
}
const ArgumentHeader = (props: Props) => {
  switch (props.state) {
    case -1:
      return (
        <TableHead
          // sx={{
          //   background: white,
          //   borderRadius: "0.5rem",
          //
          // }}
          className="bg-white-100 text-secondary-500 font-bold rounded-lg"
        >
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ خواسته شده ادعا(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              لایحه دفاعیه
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              پاسخ به لایحه دفاعیه
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              فایل پاسخ به لایحه دفاعیه
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",

                textAlign: "center",
              }}
            >
              ...
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 0:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              colSpan={7}
              sx={{
                fontWeight: "bold",

                textAlign: "center",
              }}
            >
              دعاوی قابل رسیدگی
            </TableCell>
          </TableRow>
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              عنوان کلی ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مشروح ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ خواسته شده ادعا(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات و نامه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              عملیات ها
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 1:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ ادعا خواهان(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              لایحه دفاعیه
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات و نامه خوانده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              عملیات ها
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 2:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر کمیته فنی تخصصی به طور مفصل
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات و نامه نظر کارشناسی
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              متن رای پیشنهادی
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید کمیته
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              عملیات ها
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 3:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ خواسته شده ادعا(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              لایحه دفاعیه
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید خوانده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              پاسخ به لایحه دفاعیه
            </TableCell>
            <TableCell
              width={"50px"}
              sx={{
                fontWeight: "bold",
              }}
            >
              ...
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 4:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            {/* <TableCell
            sx={{
              fontWeight: "bold",
             
            }}
          >
            لایحه دفاعیه
          </TableCell> */}
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ خواسته شده ادعا(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات کارشناس پرونده{" "}
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ...
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 5:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            {/* <TableCell
            sx={{
              fontWeight: "bold",
             
            }}
          >
            لایحه دفاعیه
          </TableCell> */}
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ خواسته شده ادعا(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 6:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            {/* <TableCell
            sx={{
              fontWeight: "bold",
             
            }}
          >
            لایحه دفاعیه
          </TableCell> */}
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ خواسته شده ادعا(ریال)
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر شورا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید شورا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ...
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 7:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر کمیته فنی تخصصی به طور مفصل
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات و نامه نظر کارشناسی
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              متن رای پیشنهادی
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید کمیته
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              عملیات ها
            </TableCell>
          </TableRow>
        </TableHead>
      );
    case 8:
      return (
        <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
          <TableRow>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ردیف
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              خلاصه ادعا
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              نظر کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مبلغ مورد تایید کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              پاسخ خواهان به نظر کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات پاسخ خواهان به نظر کارشناس پرونده
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              مستندات
            </TableCell>
            <TableCell
              sx={{
                fontWeight: "bold",
              }}
            >
              ...
            </TableCell>
          </TableRow>
        </TableHead>
      );

      case 9:
        return (
          <TableHead className="bg-white-100 text-secondary-500 font-bold rounded-lg">
            <TableRow>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                ردیف
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                خلاصه ادعا
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                نظر کارشناس پرونده
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                مبلغ مورد تایید کارشناس پرونده
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                پاسخ خوانده به نظر کارشناس پرونده
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                مستندات پاسخ خوانده به نظر کارشناس پرونده
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                مستندات
              </TableCell>
              <TableCell
                sx={{
                  fontWeight: "bold",
                }}
              >
                ...
              </TableCell>
            </TableRow>
          </TableHead>
        );
    }
};

export default ArgumentHeader;
