/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/ban-ts-comment */
import {
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
} from "@mui/material";
import { AiFillFileAdd } from "react-icons/ai";
import {
  convertToPersianDigits,
  convertToPersianDigitsWithComma,
} from "../../functions/Functions";
import { ComplaintArgument } from "../../gql/graphql";
import { Green, GreenLight, background } from "../../theme/color";
import FaTypography from "../FaComponents/FaTypography";
import NewModal from "../Modals";
import { API_FILE_DOWNLOAD } from "../../../config";
import { ToWords } from "to-words";

interface Props {
  open: boolean;
  handleClose: () => void;
  state: number;
  argument?: ComplaintArgument;
  fullArgument?: ComplaintArgument;
}
const ArgumentInfoModal = (props: Props) => {
  const toWords = new ToWords({
    localeCode: "fa-IR",
  });

  switch (props.state) {
    case -2:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا`}
          width={{
            xs: "100%",
            md: "50%",
          }}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.fullArgument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.fullArgument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    <FaTypography>
                      {convertToPersianDigitsWithComma(
                        props.fullArgument?.suggestedAmount
                      )}
                      {toWords.convert(
                        (props.fullArgument?.suggestedAmount as number) || 0
                      )}{" "}
                      {"ریال"}
                    </FaTypography>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>لایحه دفاعیه :</TableCell>
                  <TableCell>{props.fullArgument?.accusedResponse}</TableCell>
                </TableRow>
                {props.fullArgument?.mailRoomExpertOpinionOnArgument && (
                  <TableRow>
                    <TableCell>نظر کمیته فنی تخصصی :</TableCell>
                    <TableCell>
                      {props.fullArgument?.mailRoomExpertOpinionOnArgument}
                    </TableCell>
                  </TableRow>
                )}
                {props.fullArgument?.mailRoomChiefOpinionOnArgument && (
                  <TableRow>
                    <TableCell>نظر شورای عالی فنی :</TableCell>
                    <TableCell>
                      {props.fullArgument?.mailRoomChiefOpinionOnArgument}
                    </TableCell>
                  </TableRow>
                )}
                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="contained"
                        endIcon={<AiFillFileAdd />}
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                        onClick={() => {
                          // download file with url in fileName
                          window.open(
                            API_FILE_DOWNLOAD +
                              (props.fullArgument?.fileName || "")
                          );
                        }}
                        sx={{
                          borderRadius: 2,
                          backgroundColor: Green,
                          fontWeight: 700,
                          fontStyle: "normal",
                          fontSize: "0.7rem",
                          boxShadow: "none",
                          display: props.fullArgument?.fileName
                            ? "flex"
                            : "none",
                          justifyContent: "center",
                          alignItems: "center",
                          "&:hover": {
                            backgroundColor: GreenLight,
                            color: Green,
                          },
                        }}
                      >
                        {props.fullArgument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خوانده :</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      endIcon={<AiFillFileAdd />}
                      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                      onClick={() => {
                        // download file with url in fileName

                        window.open(
                          API_FILE_DOWNLOAD +
                            props.fullArgument?.accusedResponseFileName
                        );
                      }}
                      sx={{
                        borderRadius: 2,
                        backgroundColor: Green,
                        fontWeight: 700,
                        fontStyle: "normal",
                        fontSize: "0.7rem",
                        boxShadow: "none",
                        // display: "flex",
                        display: props.fullArgument?.accusedResponseFileName
                          ? "flex"
                          : "none",
                        justifyContent: "center",
                        alignItems: "center",
                        "&:hover": {
                          backgroundColor: GreenLight,
                          color: Green,
                        },
                      }}
                    >
                      {props.fullArgument?.accusedResponseFileName}
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
    case -1:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا`}
          width={{
            xs: "100%",
            md: "50%",
          }}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.argument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.argument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    <FaTypography>
                      {props.argument?.suggestedAmount}
                    </FaTypography>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>لایحه دفاعیه :</TableCell>
                  <TableCell>{props.argument?.accusedResponse}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خوانده :</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      endIcon={<AiFillFileAdd />}
                      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                      onClick={() => {
                        // download file with url in fileName

                        window.open(
                          API_FILE_DOWNLOAD +
                            props.argument?.accusedResponseFileName
                        );
                      }}
                      sx={{
                        borderRadius: 2,
                        backgroundColor: Green,
                        fontWeight: 700,
                        fontStyle: "normal",
                        fontSize: "0.7rem",
                        boxShadow: "none",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        "&:hover": {
                          backgroundColor: GreenLight,
                          color: Green,
                        },
                      }}
                    >
                      {props.argument?.accusedResponseFileName}
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="contained"
                        endIcon={<AiFillFileAdd />}
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                        onClick={() => {
                          // download file with url in fileName
                          window.open(
                            API_FILE_DOWNLOAD + props.argument?.fileName
                          );
                        }}
                        sx={{
                          borderRadius: 2,
                          backgroundColor: Green,
                          fontWeight: 700,
                          fontStyle: "normal",
                          fontSize: "0.7rem",
                          boxShadow: "none",
                          display: props.argument?.fileName ? "flex" : "none",
                          justifyContent: "center",
                          alignItems: "center",
                          "&:hover": {
                            backgroundColor: GreenLight,
                            color: Green,
                          },
                        }}
                      >
                        {props.argument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
    case 1:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا در مرحله ${props.state}`}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.argument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.argument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    {convertToPersianDigitsWithComma(
                      props.argument?.suggestedAmount
                    )}{" "}
                    ریال{" "}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="contained"
                        endIcon={<AiFillFileAdd />}
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                        onClick={() => {
                          // download file with url in fileName

                          window.open(
                            API_FILE_DOWNLOAD + props.argument?.fileName
                          );
                        }}
                        sx={{
                          borderRadius: 2,
                          backgroundColor: Green,
                          fontWeight: 700,
                          fontStyle: "normal",
                          fontSize: "0.7rem",
                          boxShadow: "none",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                          "&:hover": {
                            backgroundColor: GreenLight,
                            color: Green,
                          },
                        }}
                      >
                        {props.argument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
    case 2:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا`}
          width={{
            xs: "100%",
            md: "50%",
          }}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.argument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.argument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    <FaTypography>
                      {convertToPersianDigitsWithComma(
                        props.argument?.suggestedAmount
                      )}
                    </FaTypography>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>لایحه دفاعیه :</TableCell>
                  <TableCell>{props.argument?.accusedResponse}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>پاسخ به لایحه دفاعیه :</TableCell>
                  <TableCell>
                    {props.argument?.accuserAnswerToAccusedResponse}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خوانده :</TableCell>
                  <TableCell>
                    <Button
                      variant="text"
                      color="success"
                      href={
                        API_FILE_DOWNLOAD +
                        (props.argument?.accusedResponseFileName || "")
                      }
                      target="_blank"
                    >
                      {props.argument?.accusedResponseFileName}
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="text"
                        color="success"
                        href={
                          API_FILE_DOWNLOAD + (props.argument?.fileName || "")
                        }
                        target="_blank"
                      >
                        {props.argument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>نظر کارشناس پرونده :</TableCell>
                  <TableCell>{props.argument?.justiceExpertOpinion}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ مورد تایید کارشناس پرونده :</TableCell>
                  <TableCell>
                    {convertToPersianDigitsWithComma(
                      props.argument?.netJusticeExpertApprovedAmount ||
                        props.argument?.grossJusticeExpertApprovedAmount
                    )}
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>مستند کارشناس پرونده :</TableCell>
                  <TableCell>
                    <Button
                      variant="text"
                      color="success"
                      href={
                        API_FILE_DOWNLOAD +
                        (props.argument?.justiceExpertOpinionFileName || "")
                      }
                      target="_blank"
                    >
                      {props.argument?.justiceExpertOpinionFileName}
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
    case 3:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا`}
          width={{
            xs: "100%",
            md: "50%",
          }}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.argument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.argument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    {convertToPersianDigits(
                      props.argument?.suggestedAmount
                        ?.toString()
                        .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>لایحه دفاعیه :</TableCell>
                  <TableCell>{props.argument?.accusedResponse}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>پاسخ کارشناس :</TableCell>
                  <TableCell>{props.argument?.expertOpinion}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>متن رای پیشنهادی :</TableCell>
                  <TableCell>{props.argument?.expertVerdict}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ مورد تایید کمیته :</TableCell>
                  <TableCell>
                    {convertToPersianDigits(
                      props.argument?.netMailRoomExpertApprovedAmount
                        ?.toString()
                        .replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خوانده :</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      endIcon={<AiFillFileAdd />}
                      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                      onClick={() => {
                        // download file with url in fileName
                        window.open(
                          API_FILE_DOWNLOAD +
                            props.argument?.accusedResponseFileName
                        );
                      }}
                      sx={{
                        borderRadius: 2,
                        backgroundColor: Green,
                        fontWeight: 700,
                        fontStyle: "normal",
                        fontSize: "0.7rem",
                        boxShadow: "none",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        "&:hover": {
                          backgroundColor: GreenLight,
                          color: Green,
                        },
                      }}
                    >
                      {props.argument?.accusedResponseFileName}
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="contained"
                        endIcon={<AiFillFileAdd />}
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                        onClick={() => {
                          // download file with url in fileName
                          window.open(
                            API_FILE_DOWNLOAD + props.argument?.fileName
                          );
                        }}
                        sx={{
                          borderRadius: 2,
                          backgroundColor: Green,
                          fontWeight: 700,
                          fontStyle: "normal",
                          fontSize: "0.7rem",
                          boxShadow: "none",
                          display: props.argument?.fileName ? "flex" : "none",
                          justifyContent: "center",
                          alignItems: "center",
                          "&:hover": {
                            backgroundColor: GreenLight,
                            color: Green,
                          },
                        }}
                      >
                        {props.argument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات کارشناس :</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      endIcon={<AiFillFileAdd />}
                      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                      onClick={() => {
                        // download file with url in fileName
                        window.open(
                          API_FILE_DOWNLOAD +
                            props.argument?.expertOpinionFileName
                        );
                      }}
                      sx={{
                        borderRadius: 2,
                        backgroundColor: Green,
                        fontWeight: 700,
                        fontStyle: "normal",
                        fontSize: "0.7rem",
                        boxShadow: "none",
                        display: props.argument?.expertOpinionFileName
                          ? "flex"
                          : "none",
                        justifyContent: "center",
                        alignItems: "center",
                        "&:hover": {
                          backgroundColor: GreenLight,
                          color: Green,
                        },
                      }}
                    >
                      {props.argument?.expertOpinionFileName}
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
    case 7:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا`}
          width={{
            xs: "100%",
            md: "50%",
          }}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.argument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.argument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    <FaTypography>
                      {convertToPersianDigitsWithComma(
                        props.argument?.suggestedAmount
                      )}
                    </FaTypography>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>لایحه دفاعیه :</TableCell>
                  <TableCell>{props.argument?.accusedResponse}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>پاسخ به لایحه دفاعیه :</TableCell>
                  <TableCell>
                    {props.argument?.accuserAnswerToAccusedResponse}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خوانده :</TableCell>
                  <TableCell>
                    <Button
                      variant="text"
                      color="success"
                      href={
                        API_FILE_DOWNLOAD +
                        (props.argument?.accusedResponseFileName || "")
                      }
                      target="_blank"
                    >
                      {props.argument?.accusedResponseFileName}
                    </Button>
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="text"
                        color="success"
                        href={
                          API_FILE_DOWNLOAD + (props.argument?.fileName || "")
                        }
                        target="_blank"
                      >
                        {props.argument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>نظر کارشناس پرونده :</TableCell>
                  <TableCell>{props.argument?.justiceExpertOpinion}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ مورد تایید کارشناس پرونده :</TableCell>
                  <TableCell>
                    {convertToPersianDigitsWithComma(
                      props.argument?.netJusticeExpertApprovedAmount ||
                        props.argument?.grossJusticeExpertApprovedAmount
                    )}
                  </TableCell>
                </TableRow>

                <TableRow>
                  <TableCell>مستند کارشناس پرونده :</TableCell>
                  <TableCell>
                    <Button
                      variant="text"
                      color="success"
                      href={
                        API_FILE_DOWNLOAD +
                        (props.argument?.justiceExpertOpinionFileName || "")
                      }
                      target="_blank"
                    >
                      {props.argument?.justiceExpertOpinionFileName}
                    </Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
    default:
      return (
        <NewModal
          open={props.open}
          onClose={props.handleClose}
          background={background}
          isCloseable={true}
          title={`مشخصات ادعا`}
          width={{
            xs: "100%",
            md: "50%",
          }}
        >
          <TableContainer
            sx={{
              width: "100%",
            }}
          >
            <Table>
              <TableBody>
                <TableRow>
                  <TableCell>خلاصه ادعا :</TableCell>
                  <TableCell>{props.argument?.summary}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مشروح ادعا :</TableCell>
                  <TableCell>{props.argument?.description}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ خواسته شده ادعا :</TableCell>
                  <TableCell>
                    <FaTypography>
                      {convertToPersianDigitsWithComma(
                        props.argument?.suggestedAmount
                      )}{" "}
                      ریال
                    </FaTypography>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>لایحه دفاعیه :</TableCell>
                  <TableCell>{props.argument?.accusedResponse}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>نظر کمیته فنی تخصصی :</TableCell>
                  <TableCell>
                    {props.argument?.mailRoomExpertOpinionOnArgument}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>نظر شورای عالی فنی :</TableCell>
                  <TableCell>
                    {props.argument?.mailRoomChiefOpinionOnArgument}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>نظر کارشناس پرونده :</TableCell>
                  <TableCell>{props.argument?.justiceExpertOpinion}</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مبلغ موردتایید کارشناس پرونده :</TableCell>
                  <TableCell>
                    {convertToPersianDigitsWithComma(
                      props.argument?.netJusticeExpertApprovedAmount
                    )}{" "}
                    ریال
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خواهان :</TableCell>
                  <TableCell>
                    {props.fullArgument?.fileName && (
                      <Button
                        variant="contained"
                        endIcon={<AiFillFileAdd />}
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                        onClick={() => {
                          // download file with url in fileName
                          window.open(
                            API_FILE_DOWNLOAD + props.argument?.fileName
                          );
                        }}
                        sx={{
                          borderRadius: 2,
                          backgroundColor: Green,
                          fontWeight: 700,
                          fontStyle: "normal",
                          fontSize: "0.7rem",
                          boxShadow: "none",
                          display: props.argument?.fileName ? "flex" : "none",
                          justifyContent: "center",
                          alignItems: "center",
                          "&:hover": {
                            backgroundColor: GreenLight,
                            color: Green,
                          },
                        }}
                      >
                        {props.argument?.fileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>مستندات خوانده :</TableCell>
                  <TableCell>
                    {props.argument?.accusedResponseFileName && (
                      <Button
                        variant="contained"
                        endIcon={<AiFillFileAdd />}
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
                        onClick={() => {
                          // download file with url in fileName

                          window.open(
                            API_FILE_DOWNLOAD +
                              props.argument?.accusedResponseFileName
                          );
                        }}
                        sx={{
                          borderRadius: 2,
                          backgroundColor: Green,
                          fontWeight: 700,
                          fontStyle: "normal",
                          fontSize: "0.7rem",
                          boxShadow: "none",
                          // display: "flex",
                          display: props.argument?.accusedResponseFileName
                            ? "flex"
                            : "none",
                          justifyContent: "center",
                          alignItems: "center",
                          "&:hover": {
                            backgroundColor: GreenLight,
                            color: Green,
                          },
                        }}
                      >
                        {props.argument?.accusedResponseFileName}
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </NewModal>
      );
  }
};

export default ArgumentInfoModal;
