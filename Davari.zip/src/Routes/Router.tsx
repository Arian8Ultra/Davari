/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable react-refresh/only-export-components */
import { lazy } from "react";
import {
  Route,
  createBrowserRouter,
  createRoutesFromElements,
} from "react-router-dom";
import { useUserStore } from "../Context/UserStore";
import "../index.css";
import LoginLayout from "../layout/LoginLayout";
import MainLayout from "../layout/MainLayout";
import Root from "../layout/Root";
import LogPage from "../pages/Admin/Log/LogPage";
import SettingsPage from "../pages/Admin/Settings/SettingsPage";
import StateManagementPage from "../pages/Admin/StateManagment/StateManagementPage";
import UserManagement from "../pages/Admin/UserManager/UserManagement";
import UpdateContractAccuserPage from "../pages/Complaints/AddContract/UpdateContractAccuserPage";
import ComplaintTimeLinePage from "../pages/Complaints/ComplaintTimeLine/ComplaintTimeLinePage";
import ConfirmPage from "../pages/Complaints/Confrm/ConfirmPage";
import NewContractPagesAccused from "../pages/Complaints/Contract/NewContractPagesAccused";
import NewContractPagesAccuser from "../pages/Complaints/Contract/NewContractPagesAccuser";
import CouncilListPage from "../pages/Complaints/CouncilList/CouncilListPage";
import DeterminingCaseExpert from "../pages/Complaints/DeterminingCaseExpert/DeterminingCaseExpert";
import DeterminingCaseList from "../pages/Complaints/DeterminingCaseExpert/DeterminingCaseList";
import FilePage from "../pages/Complaints/Files/FilesPage";
import AddMeetingPage from "../pages/Complaints/Meeting/AddMeetingPage";
import PaymentPage from "../pages/Complaints/Payment/PaymentPage";
import RequestCorrectionPage from "../pages/Complaints/RequestCorrection/RequestCorrectionPage";
import TablesPage from "../pages/Complaints/Tabels/TablesPage";
import VerdictPage from "../pages/Complaints/Verdict/VerdictPage";
import ContractDetailsPage from "../pages/Contracts/ContractDetailsPage";
import Dashboard from "../pages/Dashboard/Dashboard";
import RequestDocs from "../pages/Expert/Docs/RequestDocs";
import UploadDocs from "../pages/Expert/Docs/UploadDocs";
import ExpertPortal from "../pages/Expert/ExpertPortal";
import ReviewCase from "../pages/Expert/ReviewCase";
import LetterPage from "../pages/Letters/LetterPage";
import LettersPage from "../pages/Letters/LettersPage";
import ContractorSignupPage from "../pages/Login/ContractorSignup";
import ForgetPassword from "../pages/Login/ForgetPassword";
import OTPpage from "../pages/Login/OTPpage";
import SignIn from "../pages/Login/SignIn";
import CaseExpertSignUp from "../pages/Login/SignUp/CaseExpertSignUp";
import ConfirmUser from "../pages/Login/SignUp/ConfirmUser";
import PersonInfo from "../pages/Login/SignUp/PersonInfo";
import SignUp from "../pages/Login/SignUp/SignUp";
import MessagePage from "../pages/Messages/MessagePage";
import MessagesPage from "../pages/Messages/MessagesPage";
import ProfilePage from "../pages/Profile/ProfilePage";
import TrackingPage from "../pages/Tracking/TrackingPage";
const Complaints = lazy(() => import("../pages/Complaints/Complaints"));
const Home = lazy(() => import("../pages/Home/Home"));
const Protal = lazy(() => import("../pages/Portal/Protal"));
const Messages = lazy(() => import("../pages/Portal/Messages/Messages"));
const ComplainAnswers = lazy(
  () => import("../pages/Portal/ComplainAnswers/ComplainAnswers")
);

const Test = lazy(() => import("../pages/Admin/Test/Test"));
const Contracts = lazy(() => import("../pages/Contracts/Contracts"));
const AddContract = lazy(
  () => import("../pages/Complaints/AddContract/AddContract")
);
const CreateContractPage = lazy(
  () => import("../pages/Complaints/AddContract/CreateContractPage")
);
const AddComplaint = lazy(
  () => import("../pages/Complaints/AddComplaints/AddComplaints")
);
const AddArgument = lazy(
  () => import("../pages/Complaints/AddArguements/AddArguements")
);
const UpdateContractPage = lazy(
  () => import("../pages/Complaints/AddContract/UpdateContractPage")
);
const user = useUserStore.getState().user;
const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Root />}>
      <Route path="login" element={<LoginLayout />}>
        <Route path="" element={<SignIn />} />
        <Route path="signin" element={<SignIn />} />
        <Route path="contractor_signup" element={<ContractorSignupPage />} />
        <Route path="otp" element={<OTPpage />} />
        <Route path="forgotPassword" element={<ForgetPassword />} />
        <Route path="tracking" element={<TrackingPage />} />
      </Route>
      <Route path="" element={<MainLayout />}>
        <Route path="" element={<Home />} />
        <Route path="home" element={<Home />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="profile" element={<ProfilePage />} />

        <Route path="complaints/addContract" element={<AddContract />} />
        <Route path="signUp" element={<SignUp />}>
          <Route path="" element={<PersonInfo />} />
          <Route path=":userName/:password" element={<ConfirmUser />} />

          <Route
            path="determiningCaseExpert/newUser/:complaintId"
            element={<CaseExpertSignUp />}
          />
        </Route>

        <Route
          path="determiningCaseExpert/:complaintId"
          element={<DeterminingCaseExpert />}
        />
        <Route path="dashboard" element={<Dashboard />} />
        <Route
          path="complaints/createContractPage"
          element={<CreateContractPage />}
        />
        <Route
          path="complaints/:contractId/:complaintId/update/contractPageToFill"
          element={<NewContractPagesAccused />}
        />
        <Route
          path="complaints/:contractId/:type/contractPageToFill"
          element={<NewContractPagesAccuser />}
        />
        <Route
          path="complaints/:type/contractPageToFill"
          element={<NewContractPagesAccuser />}
        />
        <Route
          path="complaints/:contractId/:complaintId/:type/contractPageToFill/:stageNum"
          element={<NewContractPagesAccuser />}
        />
        <Route
          path="complaints/:contractId/:complaintId/:type/contractPageToFill"
          element={<NewContractPagesAccuser />}
        />
        <Route
          path="complaints/:contractId/:type/contractPageToFill/:stageNum"
          element={<NewContractPagesAccuser />}
        />
        <Route
          path="complaints/:type/contractPageToFill/:stageNum"
          element={<NewContractPagesAccuser />}
        />

        <Route
          path="complaints/:contractId/:complaintId/addComplaint"
          element={<AddComplaint />}
        />
        <Route
          path="complaints/:contractId/:complaintId/addArguements/:state"
          element={<AddArgument />}
        />
        <Route
          path="complaints/:contractId/:complaintId/tablesPage"
          element={<TablesPage />}
        />
        <Route
          path="complaints/:contractId/:complaintId/tables"
          element={<TablesPage />}
        />
        <Route path="complaints/:complaintId/files" element={<FilePage />} />
        <Route
          path="complaints/:complaintId/pay/:turn"
          element={<PaymentPage />}
        />
        <Route path="complaints/:complaintId/pay" element={<PaymentPage />} />
        <Route
          path="complaints/:complaintId/setMeeting"
          element={<AddMeetingPage />}
        />
        <Route
          path="complaints/:complaintId/docReq"
          element={<RequestDocs />}
        />
        <Route
          path="complaints/:complaintId/docUpload"
          element={<UploadDocs />}
        />
        <Route
          path="complaints/:complaintId/expertReview"
          element={<ReviewCase />}
        />
        <Route
          path="complaints/:complaintId/verdict"
          element={<VerdictPage />}
        />
        <Route
          path="complaints/:complaintId/timeLine"
          element={<ComplaintTimeLinePage />}
        />

        <Route path="contracts" element={<Contracts />} />
        <Route path="portal" element={<Protal />} />
        <Route path="portal/messages" element={<Messages />} />
        <Route path="portal/employee_management" element={<Protal />} />
        <Route path="portal/council_List" element={<CouncilListPage />} />
        <Route path="portal/complain_answers" element={<ComplainAnswers />} />
        <Route
          path="contract/:contractId/:complaintId"
          element={<ContractDetailsPage />}
        />
        {/* <Route
          path="contract/:contractId/:complaintId/old"
          element={<ContractPage />}
        /> */}
        <Route
          path="contract/:contractId/:complaintId/details"
          element={<ContractDetailsPage />}
        />
        <Route path="admin/usermanagement" element={<UserManagement />} />

        <Route path="expertPortal" element={<ExpertPortal />} />

        <Route path="test" element={<Test />} />
      </Route>
      <Route path="" element={<MainLayout />}>
        <Route path="" element={<Home />} />
        <Route path="home" element={<Home />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="complaints/addContract" element={<AddContract />} />
        <Route path="signUp" element={<SignUp />}>
          <Route path="" element={<PersonInfo />} />
          <Route path=":userName/:password" element={<ConfirmUser />} />

          <Route
            path="determiningCaseExpert/newUser/:complaintId"
            element={<CaseExpertSignUp />}
          />
        </Route>

        <Route
          path="determiningCaseExpert/:complaintId"
          element={<DeterminingCaseExpert />}
        />
        <Route
          path="complaints/createContractPage"
          element={<CreateContractPage />}
        />
        <Route
          path="complaints/:contractId/createContractPage"
          element={<CreateContractPage />}
        />
        <Route
          path="complaints/:contractId/:complaintId/UpdateContractPage"
          element={<UpdateContractPage />}
        />
        <Route
          path="complaints/:contractId/:complaintId/UpdateContractAccuserPage"
          element={<UpdateContractAccuserPage />}
        />
        <Route
          path="complaints/:contractId/:complaintId/addComplaint"
          element={<AddComplaint />}
        />
        <Route
          path="complaints/:contractId/:complaintId/addArguements/:state"
          element={<AddArgument />}
        />
        <Route
          path="complaints/:contractId/:complaintId/tablesPage"
          element={<TablesPage />}
        />
        <Route
          path="complaints/:contractId/:complaintId/tables"
          element={<TablesPage />}
        />
        <Route path="complaints/:complaintId/files" element={<FilePage />} />
        <Route
          path="complaints/:complaintId/pay/:turn"
          element={<PaymentPage />}
        />
        <Route path="complaints/:complaintId/pay" element={<PaymentPage />} />
        <Route
          path="complaints/:complaintId/setMeeting"
          element={<AddMeetingPage />}
        />
        <Route
          path="complaints/:complaintId/docReq"
          element={<RequestDocs />}
        />
        <Route
          path="complaints/:complaintId/docUpload"
          element={<UploadDocs />}
        />
        <Route
          path="complaints/:complaintId/expertReview"
          element={<ReviewCase />}
        />
        <Route
          path="complaints/:complaintId/verdict"
          element={<VerdictPage />}
        />
        <Route
          path="complaints/:complaintId/confirmComplaint"
          element={<ConfirmPage />}
        />
        <Route
          path="complaints/:complaintId/requestCorrection"
          element={<RequestCorrectionPage />}
        />

        <Route path="contracts" element={<Contracts />} />
        <Route path="portal" element={<Protal />} />
        <Route path="portal/messages" element={<Messages />} />
        <Route path="portal/employee_management" element={<Protal />} />
        <Route path="portal/council_List" element={<CouncilListPage />} />
        <Route
          path="portal/determining_List"
          element={<DeterminingCaseList />}
        />
        <Route path="portal/complain_answers" element={<ComplainAnswers />} />
        <Route
          path="contract/:contractId/:complaintId"
          element={<ContractDetailsPage />}
        />
        {/* <Route
          path="contract/:contractId/:complaintId/old"
          element={<ContractPage />}
        /> */}
        <Route
          path="contract/:contractId/:complaintId/details"
          element={<ContractDetailsPage />}
        />
        <Route path="admin/usermanagement" element={<UserManagement />} />
        <Route path="admin/settings" element={<SettingsPage />} />
        <Route path="admin/stateManagement" element={<StateManagementPage />} />
        <Route path="admin/log" element={<LogPage />} />
        <Route path="admin/letters" element={<LettersPage />} />
        <Route path="admin/letters/:letterId" element={<LetterPage />} />

        <Route path="admin/messages" element={<MessagesPage />} />
        <Route path="admin/messages/:letterId" element={<MessagePage />} />

        <Route path="expertPortal" element={<ExpertPortal />} />

        {/* <Route
          path="DastineTest"
          element={<DastineTest />}
        /> */}

        <Route path="test" element={<Test />} />
      </Route>
    </Route>
  ),
  {
    future: {
      v7_normalizeFormMethod: true,
    },
    basename: "/",
  }
);

export default router;
