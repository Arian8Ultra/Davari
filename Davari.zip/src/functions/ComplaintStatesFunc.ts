/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { ComplaintState, ComplaintStateStatus } from "../gql/graphql";

export function getComplaintStateWithEnum(
  state?: ComplaintStateStatus
): ComplaintState {
  if (!state)
    return {
      id: 0,
      englishName: "",
      persianName: "",
      state: ComplaintStateStatus.WaitingForNewOfferorsInfo,
      createdDate: "",
      isDeleted: false,
      priority: 0,
      isBusiness: false,
    };

  const complaintStatesStorage = localStorage.getItem("complaintStates")
    ? (JSON.parse(
        localStorage.getItem("complaintStates") || "['']"
      ) as ComplaintState[])
    : [];
  const complaintStates = complaintStatesStorage;
  return (
    complaintStates.find((c) => c.state === state) || {
      id: 0,
      englishName: "",
      persianName: "",
      state: ComplaintStateStatus.WaitingForNewOfferorsInfo,
      createdDate: "",
      isDeleted: false,
      priority: 0,
      isBusiness: false,
    }
  );
}

export function getComplaintStateWithId(
  id: number
): ComplaintState | undefined {
  const complaintStates = JSON.parse(
    localStorage.getItem("complaintStates") || "[]"
  ) as ComplaintState[];
  return complaintStates.find((c) => c.id === id);
}
