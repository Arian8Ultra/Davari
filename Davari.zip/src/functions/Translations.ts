import MainSettingsJson from "../assets/MainSettingPersian.json";
export type MainSettings = keyof typeof MainSettingsJson;

export function t(key: MainSettings, lang?: "EN" | "FA"): string {
    //  make the first letter of the key uppercase
    key = key.charAt(0).toUpperCase() + key.slice(1) as MainSettings;
  if (lang === "EN") {
    return MainSettingsJson[key].EN || key;
  }
  return MainSettingsJson[key].FA || key;
}
