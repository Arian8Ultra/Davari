export const API_URL = "http://172.16.21.147:7030/api/"
export const GRAPHQL_URL = 'http://172.16.21.147:7030/graphql/'
export const NEW_API_URL = "http://172.16.21.147:7030/api/"
export const API_URL_UPLOAD = 'http://172.16.21.147:7030/api/upload/upload-file/';
export const API_FILE_DOWNLOAD = 'http://172.16.21.147:7030/files/';
export const API_FILE_SHIVENAME = 'http://172.16.21.147:7030/shivename/shivename.pdf';
export const IMAGE_URL = 'http://172.16.21.147:9090/images/';






// export const API_URL = "http://172.17.139.21/api/"
// export const GRAPHQL_URL = 'http://172.17.139.21/graphql/'
// export const NEW_API_URL = "http://172.17.139.21/api/"
// export const API_URL_UPLOAD = 'http://172.17.139.21/api/upload/upload-file/';
// export const API_FILE_DOWNLOAD = 'http://172.17.139.21/files/';
// export const API_FILE_SHIVENAME = 'http://172.17.139.21/shivename/shivename.pdf';
// export const IMAGE_URL = 'http://172.17.139.21/images/';







